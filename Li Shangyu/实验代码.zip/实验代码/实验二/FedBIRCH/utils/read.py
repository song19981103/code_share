import os
import pickle
import random

import numpy as np
from torch.utils.data import Dataset
import torchvision.transforms as transforms
from PIL import Image


# def read_data(train_data_dir, test_data_dir, key=None):
def read_data(filename):
    """Parses data in given train and test data directories
    Assumes:
        1. the data in the input directories are .json files with keys 'users' and 'user_data'
        2. the set of train set users is the same as the set of test set users
    Return:
        train_data: dictionary of train data (ndarray)
        test_data: dictionary of test data (ndarray)
    """

    # clients = []
    # groups = []
    train_data = {}
    test_data = {}
    print('>>> Read data ...')

    # train_files = os.listdir(train_data_dir)
    # train_files = [f for f in train_files if f.endswith('.pkl')]
    # if key is not None:
    #     train_files = list(filter(lambda x: str(key) in x, train_files))

    # for f in train_files:
    #     file_path = os.path.join(train_data_dir, f)
    #     print('    ', file_path)
    #     with open(file_path, 'rb') as inf:
    #         cdata = pickle.load(inf)
    #     clients.extend(cdata['users'])
    #     # if 'hierarchies' in cdata:
    #     #     groups.extend(cdata['hierarchies'])
    #     train_data.update(cdata['user_data'])

    train_data = {}
    test_data = {}
    num_chunks = 5
    prefix = 'train'
    for i in range(num_chunks):
        with open(f'{filename}/{prefix}/{prefix}_chunk_{i}.pkl', 'rb') as f:
            chunk = pickle.load(f)
            train_data.update(chunk)
    prefix = 'test'
    for i in range(num_chunks):
        with open(f'{filename}/{prefix}/{prefix}_chunk_{i}.pkl', 'rb') as f:
            chunk = pickle.load(f)
            for item in chunk:
                test_data.update(item)
            # if isinstance(chunk, dict):
            #     test_data.update(chunk)  # 合并到loaded_dict中
            # else:
            #     print(f"Warning: Chunk {i} is not a dictionary, skipping.")
            # test_data.update(chunk)

    for cid, v in train_data.items():
        # 添加恶意节点
        # if cid == 0 and random.random() <= 0.5:  # 10\4
        #     v['y'] = [(x + 5) % 10 for x in v['y']]
        train_data[cid] = MiniDataset(v['x'], v['y'])

    for cid, v in test_data.items():
        test_data[cid] = MiniDataset(v['x'], v['y'])

    # clients = list(sorted(train_data.keys()))
    return train_data, test_data


class MiniDataset(Dataset):
    def __init__(self, data, labels):
        super(MiniDataset, self).__init__()
        self.data = np.array(data)
        self.labels = np.array(labels).astype("int64")

        if self.data.ndim == 4 and self.data.shape[3] == 3:
            self.data = self.data.astype("uint8")
            self.transform = transforms.Compose(
                [transforms.RandomHorizontalFlip(),
                 transforms.RandomCrop(32, 4),
                 transforms.ToTensor(),
                 transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
                 ]
            )
        elif self.data.ndim == 4 and self.data.shape[3] == 1:
            self.transform = transforms.Compose(
                [transforms.ToTensor(),
                 transforms.Normalize((0.1307,), (0.3081,))
                 ]
            )
        elif self.data.ndim == 3:
            self.data = self.data.reshape(-1, 28, 28, 1).astype("uint8")
            self.transform = transforms.Compose(
                [transforms.ToTensor(),
                 transforms.Normalize((0.1307,), (0.3081,))
                 ]
            )
        else:
            self.data = self.data.astype("float32")
            self.transform = None

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, index):
        data, target = self.data[index], self.labels[index]

        if self.data.ndim == 4 and self.data.shape[3] == 3:
            data = Image.fromarray(data)

        if self.transform is not None:
            data = self.transform(data)

        return data, target
