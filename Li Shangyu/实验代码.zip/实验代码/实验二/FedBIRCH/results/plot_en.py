# import matplotlib
# matplotlib.use('TkAgg')
import random
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np
import pandas as pd
import seaborn as sns

file1 = '../results/result/FedProx_acc.csv'
file2 = '../results/result/FedAvg_acc.csv'
file3 = '../results/result/FedBirch_acc.csv'

file25m1_noTM = '../results/result/FLACC_noTM_acc_mal_25.csv'
file25m1_TM = '../results/result/FLACC_TM_acc_mal_25.csv'
file25m2_noTM = '../results/result/FedBirch_noTM_acc_mal_25.csv'
file25m2_Tm = '../results/result/FedBirch_TM_acc_mal_25.csv'

file10m1_noTM = '../results/result/FLACC_noTM_acc_mal_10.csv'
file10m1_TM = '../results/result/FLACC_TM_acc_mal_10.csv'
file10m2_noTM = '../results/result/FedBirch_noTM_acc_mal_10.csv'
file10m2_Tm = '../results/result/FedBirch_TM_acc_mal_10.csv'

file1t = '../results/result/PPIoV_trust.csv'
file2t = '../results/result/FedBirch_trust.csv'
file10mt1 = '../results/result/PPIoV_trust_mal.csv'
file10mt2 = '../results/result/FedBirch_trust_mal.csv'

# 设置论文风格
# plt.style.use('seaborn-v0_8-paper')  # 类似论文的简洁风格
plt.rcParams.update({
    'font.family': ['Times New Roman', 'SimSun'],
    'font.size': 14,  #10.5,
    # 'font.sans-serif': 'SimHei',  # 中文用黑体
    # 'font.size': 10,  # 基础字号
    'axes.labelsize': 12,  # 坐标轴标签字号
    'axes.titlesize': 12,  # 标题字号
    'xtick.labelsize': 9,  # X轴刻度字号
    'ytick.labelsize': 9,  # Y轴刻度字号
    'legend.fontsize': 8,  # 图例字号
    'figure.dpi': 300,  # 分辨率（适合论文）
    'savefig.dpi': 300,  # 保存分辨率
    'figure.figsize': (4, 3),  # 图形大小（宽，高，单位英寸）
    'lines.linewidth': 1.5,  # 线宽
    'axes.grid': True,  # 显示网格
    'grid.linestyle': '--',  # 虚线网格
    'grid.alpha': 0.3,  # 网格透明度
    'legend.frameon': True,  # 图例边框
    'legend.framealpha': 0.8,
})


# acc loss 两个图
def plot_acc():
    # 读取数据
    df1 = pd.read_csv(file1)
    df2 = pd.read_csv(file2)
    df3 = pd.read_csv(file3)

    # df2['Source'] = 'FedAvg'
    # df1['Source'] = 'FedProx'
    df2['Source'] = 'FedProx'
    df1['Source'] = 'FLACC'
    df3['Source'] = 'FedBIRCH'
    df_combined = pd.concat([df3, df1, df2], ignore_index=True)

    plt.figure()
    sns.lineplot(
        data=df_combined,
        x='Round',
        y='Acc',
        hue='Source',
        style='Source',
        markers=True,
        dashes=False,
        palette='colorblind',
        linewidth=2

    )
    plt.xlabel('Rounds')
    plt.ylabel('Accuracy (%)')
    plt.ylim(0.1, 1)
    # plt.xlim(0, 70)
    ax=plt.gca()
    ax.xaxis.set_major_locator(plt.MultipleLocator(10))
    legend = plt.legend()
    # new_labels = ['正常车辆', '恶意车辆']
    # for text, new_label in zip(legend.get_texts(), new_labels):
    #     text.set_text(new_label)
    # plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
    plt.tight_layout()
    plt.savefig('../fig/zh/acc.pdf', bbox_inches='tight')
    plt.show()

    plt.figure()
    sns.lineplot(
        data=df_combined,
        x='Round',
        y='Loss',
        hue='Source',
        style='Source',
        markers=True,
        dashes=False,
        palette='colorblind',
        linewidth=2
    )
    plt.xlabel('Rounds')
    plt.ylabel('Loss')
    plt.ylim(0, 2.5)
    ax=plt.gca()
    ax.xaxis.set_major_locator(plt.MultipleLocator(10))
    # plt.xticks(np.arange(0, 70, step=10))
    # plt.xlim(-3, 70)
    legend = plt.legend()
    # new_labels = ['正常车辆', '恶意车辆']
    # for text, new_label in zip(legend.get_texts(), new_labels):
    #     text.set_text(new_label)
    # plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
    plt.tight_layout()
    plt.savefig('../fig/zh/loss.pdf', bbox_inches='tight')
    plt.show()


# 无聚类、聚类、不同类型节点的信任变化


def plot_trust():
    # 读取数据
    df1 = pd.read_csv(file1t)
    df2 = pd.read_csv(file2t)
    df1['Source'] = 'PPIoV'
    df2['Source'] = 'FedBIRCH'
    # 12为落后者，0正常
    selected_ids = [0, 4, 12]
    data1 = df1[df1['Uid'] == 12]
    data2 = df2[df2['Uid'] == 12]
    df_combined = pd.concat([data1, data2], ignore_index=True)

    plt.figure()
    sns.lineplot(
        data=df_combined,
        x='Round',
        y='Val',
        hue='Source',
        style='Source',
        markers=True,
        dashes=False,
        palette='colorblind',
        linewidth=2
    )
    plt.xlabel('通信轮次')
    plt.ylabel('信任值')
    legend = plt.legend()
    plt.tight_layout()
    # plt.savefig('../fig/trust_straggler.pdf', bbox_inches='tight')
    # plt.show()

    data1 = df1[df1['Uid'] == 0]
    data2 = df2[df2['Uid'] == 0]
    df_combined = pd.concat([data1, data2], ignore_index=True)
    plt.figure()
    sns.lineplot(
        data=df_combined,
        x='Round',
        y='Val',
        hue='Source',
        style='Source',
        markers=True,
        dashes=False,
        palette='colorblind',
        linewidth=2
    )
    plt.xlabel('Rounds')
    plt.ylabel('Trust Value')
    legend = plt.legend()
    # plt.ylim(0.3, 1)
    plt.tight_layout()
    # plt.savefig('../fig/trust_normal.pdf', bbox_inches='tight')
    # plt.show()

    selected_ids = [0, 4, 12]
    data11 = df1[df1['Uid'] == 0]
    data12 = df1[df1['Uid'] == 12]
    data21 = df2[df2['Uid'] == 0]
    data22 = df2[df2['Uid'] == 12]
    data11['Source'] = 'Normal Vehicle'
    data12['Source'] = 'Straggler Vehicle'
    data21['Source'] = 'Normal Vehicle'
    data22['Source'] = 'Straggler Vehicle'
    df4 = pd.read_csv(file10mt1)
    df5 = pd.read_csv(file10mt2)
    data4 = df4[df4['Uid'] == 0]
    data5 = df5[df5['Uid'] == 0]
    # data4 = df4[df4['Uid'].isin(selected_ids)]
    # data5 = df5[df5['Uid'].isin(selected_ids)]
    # data4['Source'] = 'PPIoV'
    # data5['Source'] = 'FedBIRCH'
    data4['Source'] = 'Malicious Vehicle'
    data5['Source'] = 'Malicious Vehicle'

    df_combined = pd.concat([data21, data22, data5], ignore_index=True)
    file_t = '../fig/zh/trust_M2.pdf'
    plt.figure()
    sns.lineplot(
        data=df_combined,
        x='Round',
        y='Val',
        hue='Source',
        style='Source',
        markers=True,
        dashes=False,
        palette='colorblind',
        linewidth=2
    )
    plt.xlabel('Rounds')
    plt.ylabel('Trust Value')
    legend = plt.legend()
    plt.ylim(0.3, 1)
    ax=plt.gca()
    ax.xaxis.set_major_locator(plt.MultipleLocator(10))
    # plt.ylim(0.3, 0.8)
    # plt.yticks(np.arange(0.3, 0.8, 0.1))
    plt.tight_layout()
    plt.savefig(file_t, bbox_inches='tight')
    plt.show()

    df_combined = pd.concat([data11, data12, data4], ignore_index=True)
    file_t = '../fig/zh/trust_M1.pdf'
    plt.figure()
    sns.lineplot(
        data=df_combined,
        x='Round',
        y='Val',
        hue='Source',
        style='Source',
        markers=True,
        dashes=False,
        palette='colorblind',
        linewidth=2
    )
    plt.xlabel('Rounds')
    plt.ylabel('Trust Value')
    legend = plt.legend()
    plt.ylim(0.3, 1)
    ax=plt.gca()
    ax.xaxis.set_major_locator(plt.MultipleLocator(10))
    # plt.yticks(np.arange(0.3, 0.8, 0.1))
    plt.tight_layout()
    plt.savefig(file_t, bbox_inches='tight')
    plt.show()

# 不同恶意节点占比：两种方案以及是否有保护：Acc变化
def plot_mal_10():
    df1 = pd.read_csv(file10m1_noTM)
    df2 = pd.read_csv(file10m1_TM)
    df3 = pd.read_csv(file10m2_noTM)
    df4 = pd.read_csv(file10m2_Tm)

    # df1['Source'] = 'FedProx-无信任管理'
    # df2['Source'] = 'FedProx-有信任管理'
    df1['Source'] = 'FLACC - without Trust Management'
    df2['Source'] = 'FLACC - With Trust Management'
    df3['Source'] = 'FedBIRCH - Without Trust Management'
    df4['Source'] = 'FedBIRCH - With Trust Management'
    df_combined = pd.concat([df3, df4, df1, df2], ignore_index=True)

    plt.figure()
    sns.lineplot(
        data=df_combined,
        x='Round',
        y='Acc',
        hue='Source',
        style='Source',
        markers=True,
        dashes=False,
        palette='colorblind',
        linewidth=2
    )
    plt.xlabel('Rounds')
    plt.ylabel('Accuracy (%)')
    legend = plt.legend()
    plt.tight_layout()
    plt.ylim(0, 1)
    ax=plt.gca()
    ax.xaxis.set_major_locator(plt.MultipleLocator(10))
    plt.savefig('../fig/zh/mal10_acc.pdf', bbox_inches='tight')
    plt.show()

    plt.figure()
    sns.lineplot(
        data=df_combined,
        x='Round',
        y='Loss',
        hue='Source',
        style='Source',
        markers=True,
        dashes=False,
        palette='colorblind',
        linewidth=2
    )
    plt.xlabel('Rounds')
    plt.ylabel('Loss')
    plt.ylim(0, 2.5)
    ax=plt.gca()
    ax.xaxis.set_major_locator(plt.MultipleLocator(10))
    legend = plt.legend()
    plt.tight_layout()
    plt.savefig('../fig/zh/mal10_loss.pdf', bbox_inches='tight')
    plt.show()


def plot_mal_25():
    df1 = pd.read_csv(file25m1_noTM)
    df2 = pd.read_csv(file25m1_TM)
    df3 = pd.read_csv(file25m2_noTM)
    df4 = pd.read_csv(file25m2_Tm)

    # df1['Source'] = 'FedProx-无信任管理'
    # df2['Source'] = 'FedProx-有信任管理'
    df1['Source'] = 'FLACC - without Trust Management'
    df2['Source'] = 'FLACC - With Trust Management'
    df3['Source'] = 'FedBIRCH - Without Trust Management'
    df4['Source'] = 'FedBIRCH - With Trust Management'
    df_combined = pd.concat([df3, df4, df1, df2], ignore_index=True)

    plt.figure()
    sns.lineplot(
        data=df_combined,
        x='Round',
        y='Acc',
        hue='Source',
        style='Source',
        markers=True,
        dashes=False,
        palette='colorblind',
        linewidth=2
    )
    plt.xlabel('Rounds')
    plt.ylabel('Accuracy (%)')
    legend = plt.legend()
    plt.ylim(0, 1)
    ax=plt.gca()
    ax.xaxis.set_major_locator(plt.MultipleLocator(10))
    plt.tight_layout()
    plt.savefig('../fig/zh/mal25_acc.pdf', bbox_inches='tight')
    plt.show()

    plt.figure()
    sns.lineplot(
        data=df_combined,
        x='Round',
        y='Loss',
        hue='Source',
        style='Source',
        markers=True,
        dashes=False,
        palette='colorblind',
        linewidth=2
    )
    plt.xlabel('Rounds')
    plt.ylabel('Loss')
    plt.ylim(0, 2.5)
    ax=plt.gca()
    ax.xaxis.set_major_locator(plt.MultipleLocator(10))
    legend = plt.legend()
    plt.tight_layout()
    plt.savefig('../fig/zh/mal25_loss.pdf', bbox_inches='tight')
    plt.show()


# plot_acc()
plot_trust()
# plot_mal()
# plot_mal_10()
# plot_mal_25()
