## Dependency

python = 3.9

Pytorch = 2.0.0

numpy = 1.24.3

matplotlib = 3.7.1

tensorboard = 2.12.3

tensorboardX = 2.2

## Quick Start

先运行src/server/server.py，然后运行src/client/client.py