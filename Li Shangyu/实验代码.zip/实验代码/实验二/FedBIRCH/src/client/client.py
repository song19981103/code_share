import csv
import pickle
import struct
import threading
import time
from src.trainer.gd import GD
from torch.utils.data import DataLoader
from src.trainer.worker import LrdWorker
from models.model import choose_model
from communication import COMM
from utils.read import read_data
from utils.torch_utils import set_flat_params_to, get_flat_params_from

# import sys
# sys.path.append('D:/OneDrive/Project/FedBIRCH/models')
# print(torch.cuda.memory_allocated())
# print(torch.cuda.memory_reserved())

CLIENT_NUM = 10
SERVER_HOST = 'localhost'
SERVER_PORT = 9999
lock = threading.Lock()
# train_file = "../../results/server/train_FedProx.csv"
test_file = "../../results/server/test_test.csv"
# test_file = "../../results/server/test_FedProx.csv"
# test_file = "../../results/server/test_FedBIRCH.csv"
# test_file = "../../results/server/test_FedProx_mal_10.csv"
# test_file = "../../results/server/test_FedBIRCH_mal_10.csv"
# test_file = "../../results/server/test_FedProx_mal_25.csv"
# test_file = "../../results/server/test_FedBIRCH_mal_25.csv"

# test_file = "../../results/server/test_FedProx_mal_10_TM.csv"
# test_file = "../../results/server/test_FedBIRCH_mal_10_TM.csv"
# test_file = "../../results/server/test_FedProx_mal_25_TM.csv"
# test_file = "../../results/server/test_FedBIRCH_mal_25_TM.csv"

options = {}
options['model'] = 'lenet'
options['input_shape'] = (1, 28, 28)
options['num_class'] = 10  # 数据标签类别数
options['num_epoch'] = 15
options['batch_size'] = 32
options['lr'] = 0.03
options['gpu'] = True
options['wd'] = 1e-4
# step_rate = 100
decay = 0.999
alpha = 1 * 1e-3
beta = 5 * 1e-4
rho = 2 * 1e-3


class Client:
    def __init__(self, uid, train_data, test_data):
        self.round = 0
        self.uid = uid
        self.gpu = options['gpu']
        print("Init Current User ID: {}".format(self.uid))
        # 初始化模型、optimizer、训练类Worker
        # torch.cuda.set_device(0)
        model = (choose_model(options))
        if self.gpu:
            model = model.cuda()
        # torch.backends.cudnn.enabled = True
        # torch.backends.cudnn.benchmark = False
        # torch.backends.cudnn.deterministic = True
        # optimizer = optim.SGD(model.parameters(), lr=0.01)
        optimizer = GD(model.parameters(), lr=options['lr'], weight_decay=options['wd'])
        self.worker = LrdWorker(model, optimizer, options)

        self.comm = COMM(SERVER_HOST, SERVER_PORT, self.uid)
        # self.comm.send2server('hello')
        # print(self.comm.recvfserver())
        self.train_data = train_data[self.uid]
        self.test_data = test_data[self.uid]
        # threading.Thread(target=self.listen_server, daemon=True).start()
        # 写入CSV文件
        # with open(train_file, mode='w', newline='') as file:
        #     writer = csv.writer(file)
        #     writer.writerow(['Uid', 'Round', 'Acc', 'Loss'])
        with open(test_file, mode='w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(['Uid', 'Round', 'Acc', 'Loss'])

    def receive_global(self):
        while True:
            try:
                header = self.comm.client.recv(4)
                if not header:
                    return False
                size = struct.unpack('i', header)[0]
                recv_data = b''
                while len(recv_data) < size:
                    recv_data += self.comm.client.recv(size - len(recv_data))
                data = pickle.loads(recv_data)
                if data.get("type") == "global_model":
                    print(f"[Client {self.uid}] received global model")
                    global_params = data["params"]
                    # flacc
                    # global_params += get_flat_params_from(self.worker.model)
                    set_flat_params_to(self.worker.model, global_params)
                    return True
            except:
                return False

    def local_train(self):
        # x_train = train_data[self.uid].data  # shape:3771 28 28 1
        # y_train = train_data[self.uid].labels
        # x_test = test_data[self.uid].data
        # y_test = test_data[self.uid].labels
        train_dataloader = DataLoader(self.train_data, batch_size=options['batch_size'], shuffle=True)
        test_dataloader = DataLoader(self.test_data, batch_size=options['batch_size'], shuffle=False)
        # 本地训练前测试
        acc, loss = self.worker.local_test(test_dataloader)
        local_solution, worker_stats, flat_grads = self.worker.local_train(train_dataloader)
        # flat_params = local_solution.cpu().numpy()
        flat_params = local_solution
        data = {
            "type": "client_update",
            "uid": self.uid,
            "params": flat_params,
            "gradients": flat_grads
        }
        self.comm.send2server(self.uid, data)
        print('Client {}, Round: {}, Received Global Model, Test =  acc: {:.3%} / loss: {:.4f}'.format(self.uid,
                                                                                                       self.round, acc,
                                                                                                       loss))
        with open(test_file, mode='a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([self.uid, self.round, acc, loss])
        self.round += 1

    def run(self):
        self.local_train()
        while self.round <= 30:
            # 收到server返回的个性化全局模型
            if self.receive_global():
                self.local_train()
            # if not received:
            #     print(f"[Client {self.uid}] Did not receive global model.")
            time.sleep(2)  # 模拟下一轮等待


def run_clients(n=6):
    # train_path = '../../data/train'
    # test_path = '../../data/test'
    train_data, test_data = read_data('../../data')
    threads = []
    for i in range(n):
        client = Client(uid=i, train_data=train_data, test_data=test_data)
        t = threading.Thread(target=client.run)
        t.start()
        threads.append(t)
        time.sleep(0.2)  # 稍微错开一下发送时间

    for t in threads:
        t.join()


if __name__ == '__main__':
    run_clients(CLIENT_NUM)
