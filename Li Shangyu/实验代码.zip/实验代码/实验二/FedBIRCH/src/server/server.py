import csv
import math
import socketserver
import pickle
import struct
import threading
from collections import defaultdict
from itertools import combinations

import torch
import torch.nn.functional as F
import torch.nn as nn
import numpy as np
from scipy.spatial.distance import cosine
from sklearn.cluster import Birch, KMeans
from torch.utils.data import DataLoader
from models.model import choose_model
from src.trainer.worker import Worker
from utils.read import read_data
from utils.torch_utils import *

# import sys
# sys.path.append('D:/OneDrive/Project/FedBIRCH/models')

gpu = True
flatten = False  # 根据训练模型确定
CLIENT_NUM = 10
batch_size = 16
criterion = nn.CrossEntropyLoss()
HOST, PORT = "0.0.0.0", 9999
client_model_pool = {}
gradients_pool = {}
last_acc = defaultdict(float)
global_trust = defaultdict(float)
curr_uids = set()
lock = threading.Lock()  # 创建一个锁
# cnt = {}  # local update times
cnt = defaultdict(int)
block_time = defaultdict(int)  # 阻塞时间
pos_cnt = defaultdict(int)
blacklist = set()
trust_file = "../../results/server/trust_test.csv"
# fig1 acc&loss
# trust_file = "../../results/server/trust_FedProx.csv"
# trust_file = "../../results/server/trust_FedBIRCH.csv"
# fig3 acc&loss
# trust_file = "../../results/server/trust_FLACC_mal_10.csv"
# trust_file = "../../results/server/trust_FedBIRCH_mal_10.csv"
# trust_file = "../../results/server/trust_FLACC_mal_25.csv"
# trust_file = "../../results/server/trust_FedBIRCH_mal_25.csv"
# trust_file = "../../results/server/trust_FLACC_mal_10_TM.csv"
# trust_file = "../../results/server/trust_FedBIRCH_mal_10_TM.csv"
# trust_file = "../../results/server/trust_FLACC_mal_25_TM.csv"
# trust_file = "../../results/server/trust_FedBIRCH_mal_25_TM.csv"

options = {'model': 'lenet', 'input_shape': (1, 28, 28), 'num_class': 10}
origin_model = choose_model(options)
orgin_flat_model = get_flat_params_from(origin_model)
l_model = choose_model(options)
g_model = choose_model(options)
train_data, test_data = read_data('../../data')


class MyTCPHandler(socketserver.BaseRequestHandler):
    def handle(self):
        print(f"[+] Connection from {self.client_address}")
        try:
            while True:
                # 接收 header，4 字节表示后续数据长度
                header = self.request.recv(4)
                if not header:
                    break
                size = struct.unpack('i', header)[0]
                # 接收数据主体
                recv_data = b""
                while len(recv_data) < size:
                    recv_data += self.request.recv(size - len(recv_data))
                data = pickle.loads(recv_data)
                if data.get("type") == "client_update":
                    uid = data["uid"]
                    if uid in blacklist:
                        continue
                    params = data["params"]
                    gradients = data["gradients"]
                    if params is None:
                        print(f"Error: No parameters received from client {uid}")
                    print(f"[Server] Received local model from client {uid}")
                    # flat_params = torch.tensor(params, dtype=torch.float32)
                    # model = choose_model(options)
                    # set_flat_params_to(model, params)
                    # 存储本地模型参数
                    if block_time[uid] <= 0:
                        block_time[uid] = 0
                    with lock:
                        client_model_pool[uid] = (params, self.request)
                        gradients_pool[uid] = (gradients, self.request)
                        cnt[uid] += 1
                        # curr_uids.add(uid)
                        # fedbirch
                        self.birch_cluster_and_send_back()
                        # flacc
                        # self.flacc_aggregate_and_send_back()
                        # fedprox
                        # self.aggregate_and_send_back()
                        # todo detect
                        # if global_trust[uid] < 0.45:
                        #     blacklist.add(uid)
                        # print('blacklist: {}'.format(blacklist))
        # except Exception as e:
        #     print(f"[!] Error with client {self.client_address}: {e}")
        finally:
            print(f"[-] Closing connection with {self.client_address}")
            self.request.close()

    def kmeans_cluster_and_send_back(self):
        uids = list(client_model_pool.keys())
        fc1_start = 2572  # 156 + 2416
        fc1_end = fc1_start + 30840  # 30,840 是 fc1 参数长度
        X = [client_model_pool[uid][0][fc1_start:fc1_end] for uid in uids]
        num_clusters = 2
        kmeans = KMeans(n_clusters=num_clusters, random_state=0).fit(X)
        labels = kmeans.labels_
        for cluster_id in range(num_clusters):
            # 获取cluster_id集群的模型索引
            indices = [i for i, l in enumerate(labels) if l == cluster_id]
            uids_c = [uids[i] for i in indices]
            if len(indices) > 5:
                if gpu:
                    flat = orgin_flat_model.cuda()
                else:
                    flat = orgin_flat_model
                aggregated = torch.zeros_like(flat)
                for i in indices:
                    aggregated += client_model_pool[uids[i]][0]
                aggregated /= len(indices)
                self.cal_trust(uids_c, aggregated)
                for i in indices:
                    uid = uids[i]
                    block_time[uid] = 0
                    conn = client_model_pool[uid][1]
                    self.send_global_model(conn, aggregated)
                    del client_model_pool[uid]

    def birch_cluster_and_send_back(self):
        if len(client_model_pool) < 9:
            return
        agg_threshold = 3
        threshold = 6.5  # 聚类节点半径阈值
        num_clusters = 3
        uids = list(client_model_pool.keys())
        fc1_start = 2572  # 156 + 2416
        fc1_end = fc1_start + 30840  # 30,840 是 fc1 参数长度
        # X = [client_model_pool[uid][0].cpu()[fc1_start:fc1_end].numpy() for uid in uids]
        X = [client_model_pool[uid][0].cpu().numpy() for uid in uids]
        X_matrix = np.stack(X)
        # 聚类
        clusters = Birch(threshold=0.1, n_clusters=4)
        # clusters = Birch(threshold=0.1)
        # clusters = Birch(threshold=1, n_clusters=None)
        # clusters = Birch(n_clusters=num_clusters)
        labels = clusters.fit_predict(X_matrix)
        label_to_indices = {}
        label_to_uids = {}
        # todo 三轮、再收到k个后不聚合的原路返回
        for idx, label in enumerate(labels):
            label_to_indices.setdefault(label, []).append(idx)
            label_to_uids.setdefault(label, []).append(uids[idx])
        for label, indices in label_to_indices.items():
            if len(indices) >= agg_threshold:
                for i in block_time.keys():
                    block_time[i] += 1
                uids_c = [uids[i] for i in indices]
                if gpu:
                    flat = orgin_flat_model.cuda()
                else:
                    flat = orgin_flat_model
                aggregated = torch.zeros_like(flat)
                for i in indices:
                    aggregated += client_model_pool[uids[i]][0]
                aggregated /= len(indices)
                self.cal_trust(uids_c, aggregated)
                for i in indices:
                    uid = uids[i]
                    block_time[uid] = 0
                    conn = client_model_pool[uid][1]
                    self.send_global_model(conn, aggregated)
                    del client_model_pool[uid]
        # 返回block的本地更新
        for uid in block_time.keys():
            if block_time[uid] >= 3:
                conn = client_model_pool[uid][1]
                self.send_global_model(conn, client_model_pool[uid][0])
                del client_model_pool[uid]
                block_time[uid] = 0

    def aggregate_and_send_back(self):
        if len(client_model_pool) < CLIENT_NUM:
            return
        uids = list(client_model_pool.keys())
        # aggregated = np.mean(X, axis=0)
        if gpu:
            flat = orgin_flat_model.cuda()
        else:
            flat = orgin_flat_model
        aggregated = torch.zeros_like(flat)
        # aggregated = torch.zeros_like(orgin_flat_model)
        for uid in uids:
            aggregated += client_model_pool[uid][0]
        aggregated /= len(uids)
        self.cal_trust(list(range(len(uids))), aggregated)
        for uid in uids:
            conn = client_model_pool[uid][1]
            self.send_global_model(conn, aggregated)
            del client_model_pool[uid]
            print("[Server] Aggregate client {}, cnt= {} And Send Back".format(uid, cnt[uid]))

    def flacc_aggregate_and_send_back(self, alpha0=0.0, max_clusters=None):
        # 暂时用同步
        if len(gradients_pool) < CLIENT_NUM:
            return
        gradients = [val[0] for val in gradients_pool.values()]
        # uids为index->uid
        uids = list(client_model_pool.keys())
        similarity_matrix = self.cosine_similarity_matrix(gradients)
        # clusters = {uid: [uid] for uid in gradients_pool.keys()}
        clusters = {i: [i] for i in range(len(uids))}
        # 提前定义，确保变量总是存在
        within_max_matrix = defaultdict(lambda: defaultdict(float))
        within_min_matrix = defaultdict(lambda: defaultdict(float))
        cross_max_matrix = defaultdict(lambda: defaultdict(float))
        cross_min_matrix = defaultdict(lambda: defaultdict(float))
        first_iteration = True  # 标志变量：控制是否首次构建全部矩阵
        # 终止条件，不再变化
        merge = True
        while len(clusters) > 1 and (max_clusters is None or len(clusters) > max_clusters) and merge:
            merge = False
            # 计算所有聚类对之间的相似度值，matrix的索引对应cluster索引；
            if first_iteration:
                for (id1, cluster1), (id2, cluster2) in combinations(clusters.items(), 2):
                    w_min, w_max = self.within_similarity(similarity_matrix, cluster1, cluster2)
                    c_min, c_max = self.cross_similarity(similarity_matrix, cluster1, cluster2)
                    within_max_matrix[id1][id2] = within_max_matrix[id2][id1] = w_max
                    within_min_matrix[id1][id2] = within_min_matrix[id2][id1] = w_min
                    cross_max_matrix[id1][id2] = cross_max_matrix[id2][id1] = c_max
                    cross_min_matrix[id1][id2] = cross_min_matrix[id2][id1] = c_min
                first_iteration = False
            # 最小交叉相似度中最大的
            max_val = float('-inf')
            max_i = max_j = None
            for i in cross_min_matrix:
                for j in cross_min_matrix[i]:
                    if i == j:
                        continue  # 可选：跳过对角线
                    val = cross_min_matrix[i][j]
                    if val > max_val:
                        max_val = val
                        max_i, max_j = i, j
            # 检查是否满足合并条件
            if cross_max_matrix[max_i][max_j] - within_min_matrix[max_i][max_j] > 0 and cross_min_matrix[max_i][
                max_j] > 0:
                merge = True
                clusters[max_i].extend(clusters[max_j])
                del clusters[max_j]
                # 更新矩阵，仅更新与 max_i 相关的部分
                self.update_similarity_matrices(similarity_matrix, clusters, max_i, max_j,
                                                within_max_matrix, within_min_matrix,
                                                cross_max_matrix, cross_min_matrix)
        # 模型聚合
        for cluster in clusters.values():
            cluster_id = [uids[id] for id in cluster]
            if gpu:
                flat = orgin_flat_model.cuda()
            else:
                flat = orgin_flat_model
            aggregated = torch.zeros_like(flat)
            for uid in cluster_id:
                aggregated += client_model_pool[uid][0]
            aggregated /= len(cluster_id)
            self.cal_trust(cluster_id, aggregated)
            # print("[Server] Aggregate cluster {}, len = {} And Send Back".format(cluster, len(cluster)))
            for uid in cluster_id:
                conn = client_model_pool[uid][1]
                self.send_global_model(conn, aggregated)
                del gradients_pool[uid]
                del client_model_pool[uid]
                print("[Server] Aggregate client {}, cnt = {} And Send Back".format(uid, cnt[uid]))

    # def compute_cosine_similarity(self, grad1, grad2):
    #     """计算两个梯度更新之间的余弦相似度"""
    #     return 1 - cosine(grad1, grad2)

    def cosine_similarity_matrix(self, gradients):
        """
        输入: gradients - List[torch.Tensor] (每个为 1D 扁平梯度向量)
        输出: 相似度矩阵 (tensor)，大小 NxN，N 是客户端数量
        """
        grads = torch.stack(gradients)  # shape: (N, D)
        grads = F.normalize(grads, p=2, dim=1)  # L2归一化，每个向量变成单位向量
        similarity_matrix = grads @ grads.T  # 计算点积，相当于余弦相似度
        return similarity_matrix

    def cross_similarity(self, similarity_matrix, cluster1, cluster2):
        min_sim = 1
        max_sim = -1
        for i in cluster1:
            for j in cluster2:
                sim = similarity_matrix[i][j]
                min_sim = min(min_sim, sim)
                max_sim = max(max_sim, sim)
        return min_sim, max_sim

    def within_similarity(self, similarity_matrix, cluster1, cluster2):
        def compute_min_max(cluster, similarity_matrix):
            min_sim = 1
            max_sim = -1
            for i, j in combinations(cluster, 2):  # 自动排除 i==j，且只遍历一次每对
                sim = similarity_matrix[i][j]
                min_sim = min(min_sim, sim)
                max_sim = max(max_sim, sim)
            return min_sim, max_sim

        min1, max1 = compute_min_max(cluster1, similarity_matrix)
        min2, max2 = compute_min_max(cluster2, similarity_matrix)
        # 两个集群都只有一个节点？？
        if len(cluster2) == 1 and len(cluster1) == 1:
            min1 = min2 = -1
        return min(min1, min2), max(max1, max2)

    def update_similarity_matrices(self, similarity_matrix, clusters, target_id, old_id,
                                   within_max_matrix, within_min_matrix,
                                   cross_max_matrix, cross_min_matrix):
        for other_id in clusters:
            if other_id not in [target_id, old_id]:
                # 更新与新 cluster 的相似度
                w_min, w_max = self.within_similarity(similarity_matrix, clusters[target_id], clusters[other_id])
                c_min, c_max = self.cross_similarity(similarity_matrix, clusters[target_id], clusters[other_id])
                within_max_matrix[target_id][other_id] = within_max_matrix[other_id][target_id] = w_max
                within_min_matrix[target_id][other_id] = within_min_matrix[other_id][target_id] = w_min
                cross_max_matrix[target_id][other_id] = cross_max_matrix[other_id][target_id] = c_max
                cross_min_matrix[target_id][other_id] = cross_min_matrix[other_id][target_id] = c_min
            # 删除与 old_id 相关的旧值
            for mat in [within_max_matrix, within_min_matrix, cross_max_matrix, cross_min_matrix]:
                mat[old_id].pop(other_id, None)
                mat[other_id].pop(old_id, None)
        # 删除合并掉的行列
        for mat in [within_max_matrix, within_min_matrix, cross_max_matrix, cross_min_matrix]:
            mat.pop(old_id, None)

    def send_global_model(self, conn, flat_params):
        response = {"type": "global_model", "params": flat_params}
        raw = pickle.dumps(response)
        header = struct.pack('i', len(raw))
        conn.sendall(header + raw)

    def cal_trust_ppiov(self, indices, avg_model):
        uids = list(client_model_pool.keys())
        uids = [uids[i] for i in indices]
        flat_models = [client_model_pool[uid][0] for uid in uids]
        set_flat_params_to(g_model, avg_model)
        if gpu:
            g_model_1 = g_model.cuda()
        else:
            g_model_1 = g_model
        acc_g, loss_g = self.local_test(g_model_1)
        acc_pp = []
        loss_pp = []
        for i, flat_model in enumerate(flat_models):
            uid = uids[i]
            flat_temp = (avg_model * len(uids) - flat_model) / (len(uids) - 1)
            set_flat_params_to(g_model, flat_temp)
            if gpu:
                g_model_1 = g_model.cuda()
            else:
                g_model_1 = g_model
            acc_before, loss_before = self.local_test(g_model_1)
            if loss_before > loss_g:
                pos_cnt[uid] += 1
            contribute = math.log(1 + (loss_before - loss_g) / loss_before) / math.log(2)
            if contribute > 0:
                global_trust[uid] += pos_cnt[uid] / cnt[uid] * contribute
            else:
                global_trust[uid] += (1 - pos_cnt[uid] / cnt[uid]) * contribute
            # save to file
            with open(trust_file, mode='a', newline='') as file:
                writer = csv.writer(file)
                writer.writerow([uid, cnt[uid], global_trust[uid]])

    # 根据偏差、acc贡献、性能（频率）
    def cal_trust(self, uids, avg_model):
        if len(uids) == 1:
            return
        flat_models = [client_model_pool[uid][0] for uid in uids]
        set_flat_params_to(g_model, avg_model)
        if gpu:
            g_model_1 = g_model.cuda()
        else:
            g_model_1 = g_model
        acc_g, loss_g = self.local_test(g_model_1)
        # TM in FedBirch
        dis = []
        acc = []
        loss = []
        for i, flat_model in enumerate(flat_models):
            l1_distance = torch.sum(torch.abs(flat_model - avg_model))
            l2_distance = torch.sqrt(torch.sum((flat_model - avg_model) ** 2))
            dis.append(l2_distance.item())
            set_flat_params_to(l_model, flat_model)
            if gpu:
                l_model_1 = l_model.cuda()
            else:
                l_model_1 = l_model
            acc_l, loss_l = self.local_test(l_model_1)  # 训练集
            acc.append(acc_l)
            loss.append(loss_l)
        total = sum(acc)
        avg_acc = total / len(acc)
        for i, flat_model in enumerate(flat_models):
            uid = uids[i]
            # 计算公式
            trust_dis = 1 - (dis[i] - min(dis)) / (max(dis) - min(dis) + 1e-2)
            trust_dis = 0.3 * trust_dis + 0.7
            set_flat_params_to(l_model, flat_model)
            # 计算公式；global-last_global+acc_i-avg
            trust_acc = acc_g - last_acc[uid] + 2 * (acc[i] - last_acc[uid]) + acc[i] - avg_acc
            last_acc[uid] = acc_g
            # trust_acc *= 2
            if trust_acc < -0.3:
                trust_acc = -0.3
            if trust_acc > 0:
                trust_acc += 0.1
            if trust_acc > 0.3:
                trust_acc = 0.3
            # 频率
            perf = cnt[uid] / (max(cnt.values()) + 1e-2)
            if perf < 0.6:
                perf = 0.6
            trust = (trust_dis + trust_acc) * perf
            if trust < 0.3:
                trust = 0.3
            if trust > 1:
                trust = 1
            if cnt[uid] > 1:
                global_trust[uid] = trust * 0.3 + global_trust[uid] * 0.7
            else:
                global_trust[uid] = trust * 0.3 + 0.7 * 0.4  # 0.4
            # save to file
            with open(trust_file, mode='a', newline='') as file:
                writer = csv.writer(file)
                writer.writerow([uid, cnt[uid], global_trust[uid]])

    def local_test(self, model):
        model.eval()
        total_loss = correct = total = 0.
        with torch.no_grad():
            for data in test_data.values():
                test_dataloader = DataLoader(data, batch_size=batch_size, shuffle=False)
                for x, y in test_dataloader:
                    if flatten:
                        x = x.view(x.size(0), -1)
                    if gpu:
                        x, y = x.cuda(), y.cuda()
                    outputs = model(x)
                    loss = criterion(outputs, y)
                    _, predicted = torch.max(outputs, 1)
                    cor = predicted.eq(y).sum()
                    correct += cor.item()
                    total += y.size(0)
                    total_loss += loss.item() * y.size(0)
        accuracy = correct / total
        # avg_loss = total_loss / total
        return accuracy, total_loss


def run_server():
    with open(trust_file, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['Uid', 'Round', 'Trust'])
    server = socketserver.ThreadingTCPServer((HOST, PORT), MyTCPHandler)
    print("[Server] Running on port 9999...")
    # 设置计时器，在5分钟后关闭服务器
    timer = threading.Timer(600, server.shutdown)
    timer.start()
    server.serve_forever()


if __name__ == "__main__":
    run_server()
