import csv

import numpy as np
import torch

from models.model import choose_model
from src.trainer.worker import LrdWorker
from src.trainer.base import BaseTrainer
from src.trainer.gd import GD

criterion = torch.nn.CrossEntropyLoss()


class FedAvgTrainer(BaseTrainer):
    """
    Scheme I and Scheme II, based on the flag of self.simple_average
    """

    def __init__(self, options, dataset):
        model = choose_model(options)
        self.move_model_to_gpu(model, options)
        self.optimizer = GD(model.parameters(), lr=options['lr'], weight_decay=options['wd'])
        self.num_epoch = options['num_epoch']
        worker = LrdWorker(model, self.optimizer, options)
        super(FedAvgTrainer, self).__init__(options, dataset, worker=worker)
        self.prob = self.compute_prob()
        # self.clients_per_round = options['clients_per_round']

        # todo 信任初始值， round: id:val
        self.trust = [[0.4] * self.clients_per_round]

    def train(self):
        print('>>> Select {} clients per round \n'.format(self.clients_per_round))

        # Fetch latest flat model parameter
        self.latest_model = self.worker.get_flat_model_params().detach()

        for round_i in range(self.num_round):
            # Test latest model on train data
            self.test_latest_model_on_traindata(round_i)
            self.test_latest_model_on_evaldata(round_i)

            # Choose K clients prop to data size
            # self.simple_average = False
            # if self.simple_average:
            #     selected_clients, repeated_times = self.select_clients_with_prob(seed=round_i)
            # else:
            #     selected_clients = self.select_clients(seed=round_i)
            #     repeated_times = None
            selected_clients = self.select_clients(seed=round_i)
            repeated_times = [1] * self.clients_per_round
            # Solve minimization locally; solutions and costs
            solns, stats = self.local_train(round_i, selected_clients)

            # Track communication cost
            self.metrics.extend_commu_stats(round_i, stats)

            # Update latest model
            self.latest_model = self.aggregate(solns, repeated_times=repeated_times, round_i=round_i)
            # self.latest_model = self.aggregate(solns)
            self.optimizer.inverse_prop_decay_learning_rate(round_i)

            # todo 加信任管理、信任更新
            self.cal_trust(solns, stats, round_i)

        # Test final model on train data
        self.test_latest_model_on_traindata(self.num_round)
        self.test_latest_model_on_evaldata(self.num_round)

        # ----------------------写入文件-------------------------------------
        # 将数据组合成元组的列表
        rows = zip(list(np.arange(self.num_round)), self.metrics.acc_on_eval_data, self.metrics.loss_on_eval_data)
        rows = zip(list(np.arange(self.num_round)), self.metrics.acc_on_train_data, self.metrics.loss_on_train_data)
        # csv_file = "./results/tempAcc/logistic_clients0_19.csv"  # fedAvg
        # csv_file = "./results/tempAcc/logistic_clients0_19_prox.csv"
        csv_file = "./results/tempAcc/logistic_clients_test.csv"
        # csv_file = "./results/tempAcc/logistic_clients7_12.csv"
        # csv_file = "./results/tempAcc/logistic_clients13_19.csv"
        # csv_file = "./results/tempAcc/logistic_clients_mal2.csv"
        # csv_file = "./results/tempAcc/logistic_clients_mal25.csv"
        # 写入CSV文件
        with open(csv_file, mode='w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(['Round', 'Acc', 'Loss'])
            for row in rows:
                writer.writerow(row)
        # csv_file = "./results/tempTrust/logistic_clients0_19.csv"
        # csv_file = "./results/tempTrust/logistic_clients0_19_prox.csv"
        csv_file = "./results/tempTrust/logistic_clients_test.csv"
        # csv_file = "./results/tempTrust/logistic_clients7_12.csv"
        # csv_file = "./results/tempTrust/logistic_clients13_19.csv"
        # csv_file = "./results/tempTrust/logistic_clients_mal2.csv"
        # csv_file = "./results/tempTrust/logistic_clients_mal_protect.csv"
        # csv_file = "./results/tempTrust/logistic_clients_mal25.csv"
        with open(csv_file, mode='w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(['Round', 'Uid', 'Val'])
            for i, data in enumerate(self.trust):
                for j, val in enumerate(data):
                    writer.writerow([i, j, val])

        # Save tracked information
        self.metrics.write()

    # 根据数据量算权重
    def compute_prob(self):
        probs = []
        for c in self.clients:
            probs.append(len(c.train_data))
        return np.array(probs) / sum(probs)

    def select_clients_with_prob(self, seed=1):
        num_clients = min(self.clients_per_round, len(self.clients))
        np.random.seed(seed)
        index = np.random.choice(len(self.clients), num_clients, p=self.prob)
        index = sorted(index.tolist())

        select_clients = []
        select_index = []
        repeated_times = []
        for i in index:
            if i not in select_index:
                select_clients.append(self.clients[i])
                select_index.append(i)
                repeated_times.append(1)
            else:
                repeated_times[-1] += 1
        return select_clients, repeated_times

    def cal_trust(self, solns, stats, round_i):
        # solns:客户端的list[tuple(size,params)]    stats:list[dict,‘acc’]   metrics:dict
        self.trust.append([0] * self.clients_per_round)
        dis = []
        for i, (num_sample, local_solution) in enumerate(solns):
            # 计算 L1 距离
            l1_distance = torch.sum(torch.abs(local_solution - self.latest_model))
            # 计算 L2 距离
            l2_distance = torch.sqrt(torch.sum((local_solution - self.latest_model) ** 2))
            dis.append(l2_distance.item())
        acc = []
        for c in self.clients:
            tot_correct, num_sample, loss = c.local_test(use_eval_data=False)  # 训练集
            # tot_corrects.append(tot_correct)
            # num_samples.append(num_sample)
            # losses.append(loss)
            acc.append(tot_correct / num_sample)

        for i, (num_sample, local_solution) in enumerate(solns):
            trust_raw = 1 - (dis[i] - min(dis)) / (max(dis) - min(dis) + 1e-2)
            # self.trust[round_i + 1][i] = sigmoid_compress(trust_raw)
            self.trust[round_i + 1][i] = 0.6 + 0.3 * trust_raw
            # self.trust[round_i + 1][i] = 1 - (1/dis[i]) / (max(dis) - min(dis) + 1e-2)
            lastAcc = self.metrics.acc_on_eval_data[round_i]
            # self.trust[round_i + 1][i] += stats[i]['acc'] - lastAcc
            val = acc[i] - lastAcc
            if val < -0.3:
                val = -0.3
            if val > 0.3:
                val = 0.3
            self.trust[round_i + 1][i] += val
            if self.trust[round_i + 1][i] < 0.2:
                self.trust[round_i + 1][i] = 0.2
            self.trust[round_i + 1][i] = 0.8 * self.trust[round_i][i] + 0.2 * self.trust[round_i + 1][i]
            if self.trust[round_i + 1][i] > 1:
                self.trust[round_i + 1][i] = 1


def sigmoid_compress(x, scale=5, shift=0.5):
    return 1 / (1 + np.exp(-scale * (x - shift)))


def aggregate(self, solns, **kwargs):
    averaged_solution = torch.zeros_like(self.latest_model)
    # averaged_solution = np.zeros(self.latest_model.shape)
    # 均值或者按本地数据量加权平均
    if self.simple_average:
        repeated_times = kwargs['repeated_times']
        round_i = kwargs['round_i']
        assert len(solns) == len(repeated_times)
        cnt = 0
        for i, (num_sample, local_solution) in enumerate(solns):
            # 是否保护
            # if self.trust[round_i][i] < sum(self.trust[round_i]) / len(self.trust[round_i]) - 0.15:
            #     continue
            averaged_solution += local_solution * repeated_times[i]
            cnt += 1
        averaged_solution /= cnt
    else:
        for num_sample, local_solution in solns:
            averaged_solution += num_sample * local_solution
        averaged_solution /= self.all_train_data_num
        averaged_solution *= (100 / self.clients_per_round)

    # averaged_solution = from_numpy(averaged_solution, self.gpu)
    return averaged_solution.detach()
