import numpy as np
import pandas as pd
from PIL import Image
# from haversine import haversine, Unit


def convert():
    # 读取彩色图像
    img = Image.open('D:/Downloads/Edge/network1.png')

    # 将彩色图像转换为灰度图像
    gray_img = img.convert('L')

    # 保存灰度图像
    gray_img.save('D:/Downloads/Edge/network_gray.png')


# 初始化参数
n = 10  # 设备数量
epsilon1 = 1e-1
epsilon2 = 0.8
epsilon3 = 1e-2
DR = np.ones(n)  # * 0.5  # 设备可靠性初始值为1


# 计算第i个设备的全局信任值
def calculate_truth(DT, i):
    # 初始化权重
    w = np.zeros(n)
    for j in range(n):
        # if j != i:
        w[j] = DR[i] / np.sum([DR[k] for k in range(n) if k != i])

    # 迭代计算全局信任值，直到收敛
    Tru_i = 0
    cnt = 0
    while True:
        cnt += 1
        new_Tru_i = np.sum([w[j] * DT[j][i] for j in range(n)])
        if abs(new_Tru_i - Tru_i) < epsilon1:
            break
        Tru_i = new_Tru_i
        # 更新权重
        dis = np.array([np.linalg.norm(Tru_i - DT[j][i]) ** 2 for j in range(n)])
        for j in range(n):
            if j != i:
                w[j] = 1 / (dis[j] + epsilon3)
        w = w / np.sum(w)  # 归一化权重
    print(cnt)
    return Tru_i, w


def fun1():
    for j in range(5):
        DT = np.random.rand(n, n)  # 设备间的信任度矩阵，示例中随机初始化
        # 选择两行，并将它们的值设置为 0.4 到 0.7
        # rows_to_modify = np.random.choice(n, 2, replace=False)
        rows_to_modify = [3, 7]
        DT[rows_to_modify] = np.random.uniform(0.4, 0.7, (2, n))

        # 将其他行的值设置为 0.7 到 0.9
        other_rows = np.setdiff1d(np.arange(n), rows_to_modify)
        DT[other_rows] = np.random.uniform(0.7, 0.9, (len(other_rows), n))
        total_w = np.zeros(n)
        # 主循环，计算每个设备的全局信任值并更新设备可靠性
        for i in range(n):
            Tru_i, w = calculate_truth(DT, i)
            total_w += w
            # 更新设备可靠性
        print("w", total_w)
        for j in range(n):
            mean = np.mean(total_w)
            temp = 1 if total_w[j] / mean > 1 else total_w[j] / mean
            # DR[j] = epsilon2 * DR[j] + (1 - epsilon2) * temp
            DR[j] = epsilon2 * DR[j] + (1 - epsilon2) * (total_w[j] / np.max(total_w))

        # 输出结果
        print("设备可靠性：", DR)


def cal_rate_mean():
    # file = 'results/GTV_values_R0.csv'
    file = 'results/Rate_R1.csv'
    df = pd.read_csv(file)
    recall_mean = df['recall'].mean()
    recall_mean = "{:.6f}".format(recall_mean)
    spe_mean = df['specificity'].mean()
    fpr = "{:.6f}".format(1 - spe_mean)
    print(recall_mean, ",", fpr)


# def f():
#     # 经纬度坐标
#     lat1, lon1 = 22.58513, 113.92728
#     lat2, lon2 = 22.56942, 113.95202
#
#     # 计算长和宽
#     width = haversine((lat1, lon1), (lat1, lon2), unit=Unit.METERS)
#     height = haversine((lat1, lon1), (lat2, lon1), unit=Unit.METERS)
#
#     # 计算面积
#     area = width * height
#
#     print("宽度 (米):", width)
#     print("长度 (米):", height)
#     print("面积 (平方米):", area)

# fun1()
# convert()
# cal_rate_mean()
