import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np
import pandas as pd
import seaborn as sns

# file11 = 'results/GTV_values_noDR.csv'
# file12 = 'results/Rate_noDR.csv'

# file11 = 'results/GTV_values_1.csv'
# file12 = 'results/Rate_1.csv'


file11 = 'results/GTV_values_2.csv'
file12 = 'results/Rate_2.csv'
# selected_ids = [16, 24, 30, 60]

a = 10
b = 11


# 定义车辆分类函数
def classify_vehicle(vehicle_id):
    if vehicle_id % a == 0 and vehicle_id % b != 0:
        return "MalA"  # 错误消息攻击
    elif vehicle_id % b == 0 and vehicle_id % a != 0:
        return "MalB"  # 诋毁攻击
    elif vehicle_id % 17 == 0:
        return "MalC"  # 开关攻击
    # elif vehicle_id == 37 or vehicle_id == 38:
    #     return "MalD"  # 懒惰、搭便车攻击
    else:
        return "Normal"


# GT和DR两个图，四种车辆四条线
def plot_gtv_sea():
    # 读取数据
    data = pd.read_csv(file11)
    # 筛选 vehicleId = 2, 10, 12 的数据
    # filtered_data = data[data['vehicleId'].isin(selected_ids)]
    # 添加分类列
    data['VehicleType'] = data['vehicleId'].apply(classify_vehicle)
    # 计算每类车辆在每个时间点的GT均值
    data_mean_GT = data.groupby(['simTime', 'VehicleType'])['GT'].mean().reset_index()
    data_mean_DR = data.groupby(['simTime', 'VehicleType'])['DR'].mean().reset_index()

    # 计算类型A的GT均值
    df_typeA = data[data['VehicleType'] == "MalB"]
    mean_typeA = df_typeA.groupby('simTime')['DR'].mean().reset_index()
    mean_typeA['VehicleType'] = "MalB"
    # 计算其他类型的合并GT均值
    df_other = data[data['VehicleType'] != "MalB"]
    mean_other = df_other.groupby('simTime')['DR'].mean().reset_index()
    mean_other['VehicleType'] = "Normal"
    # 合并数据
    df_plot = pd.concat([mean_other, mean_typeA])

    # 设置论文风格
    # plt.style.use('seaborn-v0_8-paper')  # 类似论文的简洁风格
    plt.rcParams.update({
        'font.family': 'serif',  # 使用衬线字体（如 Times New Roman）
        # 'font.family': 'Times New Roman',
        'font.size': 10,  # 基础字号
        'axes.labelsize': 10,  # 坐标轴标签字号
        'axes.titlesize': 12,  # 标题字号
        'xtick.labelsize': 8,  # X轴刻度字号
        'ytick.labelsize': 8,  # Y轴刻度字号
        'legend.fontsize': 8,  # 图例字号
        'figure.dpi': 300,  # 分辨率（适合论文）
        'savefig.dpi': 300,  # 保存分辨率
        'figure.figsize': (4, 3),  # 图形大小（宽，高，单位英寸）
        'lines.linewidth': 1.5,  # 线宽
        'axes.grid': True,  # 显示网格
        'grid.linestyle': '--',  # 虚线网格
        'grid.alpha': 0.3,  # 网格透明度
        'legend.frameon': True,  # 图例边框
        'legend.framealpha': 0.8,
    })
    # 第一个图：GT ~ simTime
    # plt.figure()
    # sns.lineplot(
    #     # data=filtered_data,
    #     data=data_mean_GT,
    #     x='simTime',
    #     y='GT',
    #     # hue='vehicleId',
    #     # style='vehicleId',
    #     hue='VehicleType',
    #     style='VehicleType',
    #     markers=True,  # 可选：是否显示标记点
    #     dashes=False,  # 可选：是否用不同虚线样式
    #     palette='colorblind',  # 颜色友好的调色板
    # )
    # plt.xlabel('Time (s)')  # 替换为你的X轴标签
    # plt.ylabel('GT')  # 替换为你的Y轴单位和名称
    # plt.legend(title='Vehicle Type', bbox_to_anchor=(1.05, 1), loc='upper left')  # 图例放外侧
    # plt.tight_layout()  # 避免标签被裁剪
    # plt.ylim(0.55, 0.85)
    # plt.savefig('plots/gt.pdf', bbox_inches='tight')  # 保存为PDF（矢量图，适合论文）
    # plt.show()

    # 再四个单图
    plt.figure()
    sns.lineplot(
        data=data_mean_GT[data_mean_GT['VehicleType'].isin(["Normal", "MalA"])],
        x='simTime',
        y='GT',
        hue='VehicleType',
        style='VehicleType',
        markers=True,
        dashes=False,
        palette='colorblind',
        linewidth=2
    )
    plt.xlabel('Time (s)')
    plt.ylabel('GT')
    legend = plt.legend()
    new_labels = ['Normal', 'Malicious']
    for text, new_label in zip(legend.get_texts(), new_labels):
        text.set_text(new_label)
    # plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
    plt.tight_layout()
    plt.savefig('plots/gt1.pdf', bbox_inches='tight')
    plt.show()

    plt.figure()
    sns.lineplot(
        data=data_mean_DR[data_mean_DR['VehicleType'].isin(["Normal", "MalB"])],
        # data=df_plot,
        x='simTime',
        y='DR',
        hue='VehicleType',
        style='VehicleType',
        markers=True,
        dashes=False,
        palette='colorblind',
        linewidth=2
    )
    plt.xlabel('Time (s)')
    plt.ylabel('DR')
    legend = plt.legend()
    new_labels = ['Normal', 'Malicious']
    for text, new_label in zip(legend.get_texts(), new_labels):
        text.set_text(new_label)
    plt.tight_layout()
    plt.savefig('plots/dr2.pdf', bbox_inches='tight')
    plt.show()

    plt.figure()
    sns.lineplot(
        data=data_mean_GT[data_mean_GT['VehicleType'].isin(["Normal", "MalC"])],
        x='simTime',
        y='GT',
        hue='VehicleType',
        style='VehicleType',
        markers=True,
        dashes=False,
        palette='colorblind',
        linewidth=2
    )
    plt.xlabel('Time (s)')
    plt.ylabel('GT')
    legend = plt.legend()
    new_labels = ['Normal', 'Malicious']
    for text, new_label in zip(legend.get_texts(), new_labels):
        text.set_text(new_label)
    plt.tight_layout()
    plt.savefig('plots/gt3.pdf', bbox_inches='tight')
    plt.show()

    plt.figure()
    sns.lineplot(
        data=data_mean_GT[data_mean_GT['VehicleType'].isin(["Normal", "MalD"])],
        x='simTime',
        y='GT',
        hue='VehicleType',
        style='VehicleType',
        markers=True,
        dashes=False,
        palette='colorblind',
        linewidth=2
    )
    plt.xlabel('Time (s)')
    plt.ylabel('GT')
    legend = plt.legend()
    new_labels = ['Normal', 'Malicious']
    for text, new_label in zip(legend.get_texts(), new_labels):
        text.set_text(new_label)
    plt.tight_layout()
    formatter = ticker.FuncFormatter(lambda x, _: '{:.2f}'.format(x))
    plt.gca().yaxis.set_major_formatter(formatter)
    plt.savefig('plots/gt4.pdf', bbox_inches='tight')
    plt.show()


# recall和pre两个图，noDR DR 两种其他方案四条线
def plot_rate_t_sea():
    # file1 = 'results/Rate_1_95.csv'
    file1 = 'results/Rate_1_85.csv'  # noDR和GT参数相同最后值也基本一致；85比95高一些
    file2 = 'results/Rate_2_1011.csv'  # 1011值更大，收敛到1;85和onceDR类似
    file3 = 'results/Rate_3_85.csv'  # GT做权重的9 5，两类恶意车辆重合低，图像和noDR一样，85更低一点，可以
    # file4 = 'results/Rate_4_95.csv'  # 95合适
    file4 = 'results/Rate_4_85.csv'  # 85
    df1 = pd.read_csv(file1)
    df2 = pd.read_csv(file2)
    df3 = pd.read_csv(file3)
    df4 = pd.read_csv(file4)

    df1['recall'] = 100 * df1['recall']
    df2['recall'] = 100 * df2['recall']
    df3['recall'] = 100 * df3['recall']
    df4['recall'] = 100 * df4['recall']
    df1['specificity'] = 100 * (1 - df1['specificity'])
    df2['specificity'] = 100 * (1 - df2['specificity'])
    df3['specificity'] = 100 * (1 - df3['specificity'])
    df4['specificity'] = 100 * (1 - df4['specificity'])

    df1['Source'] = 'HDRS'  # no DR
    df2['Source'] = 'Our scheme'
    df3['Source'] = 'Zhao\'s scheme'  # 'w=GT' 对应HDRS，但是rep值有点小，当做no DR
    df4['Source'] = 'Li\'s scheme'  # 'Our scheme without historical DR'
    df_combined = pd.concat([df2, df4, df1, df3], ignore_index=True)
    plt.rcParams.update({
        'font.family': 'serif',  # 使用衬线字体（如 Times New Roman）
        # 'font.family': 'Times New Roman',
        'font.size': 10,  # 基础字号
        'axes.labelsize': 10,  # 坐标轴标签字号
        'axes.titlesize': 12,  # 标题字号
        'xtick.labelsize': 8,  # X轴刻度字号
        'ytick.labelsize': 8,  # Y轴刻度字号
        'legend.fontsize': 8,  # 图例字号
        'figure.dpi': 300,  # 分辨率（适合论文）
        'savefig.dpi': 300,  # 保存分辨率
        'figure.figsize': (4, 3),  # 图形大小（宽，高，单位英寸）
        'lines.linewidth': 1.5,  # 线宽
        'axes.grid': True,  # 显示网格
        'grid.linestyle': '--',  # 虚线网格
        'grid.alpha': 0.3,  # 网格透明度
        'legend.frameon': True,  # 图例边框
        'legend.framealpha': 0.8,
    })
    # recall
    plt.figure()
    sns.lineplot(
        data=df_combined,
        x='simTime',
        y='recall',
        hue='Source',  # 颜色区分
        style='Source',  # 线型区分
        markers=True,
        dashes=False,
        palette='colorblind',
    )
    plt.xlabel('Time (s)')
    plt.ylabel('Detection Rate (%)')
    legend = plt.legend()
    # new_labels = ['Our scheme', 'Our scheme without DR']
    # for text, new_label in zip(legend.get_texts(), new_labels):
    #     text.set_text(new_label)
    # plt.tight_layout()
    plt.savefig('plots/recall.pdf', bbox_inches='tight')
    plt.show()

    # recall
    plt.figure()
    sns.lineplot(
        data=df_combined,
        x='simTime',
        y='specificity',
        hue='Source',  # 颜色区分
        style='Source',  # 线型区分
        markers=True,
        dashes=False,
        palette='colorblind',
    )
    plt.xlabel('Time (s)')
    plt.ylabel('False Positive Rate (%)')  # 替换为你的Y轴单位和名称
    plt.tight_layout()
    legend = plt.legend()
    # new_labels = ['Our scheme', 'Our scheme without DR']
    # for text, new_label in zip(legend.get_texts(), new_labels):
    #     text.set_text(new_label)
    plt.savefig('plots/specificity.pdf', bbox_inches='tight')
    plt.show()


def plot_rate_per_sea():
    # file1 = 'results/plot3/Rate_v45_1.csv'
    # file2 = 'results/plot3/Rate_v45_2.csv'
    # file3 = 'results/plot3/Rate_v45_3.csv'
    # file4 = 'results/plot3/Rate_v45_4.csv'
    # output1 = 'plots/recall_R.pdf'
    # output2 = 'plots/fpr_R.pdf'

    file1 = 'results/plot3/Rate_v80_1.csv'
    file2 = 'results/plot3/Rate_v80_2.csv'
    file3 = 'results/plot3/Rate_v80_3.csv'
    file4 = 'results/plot3/Rate_v80_4.csv'
    output1 = 'plots/recall_R_v80.pdf'
    output2 = 'plots/fpr_R_v80.pdf'

    df1 = pd.read_csv(file1)
    df2 = pd.read_csv(file2)
    df3 = pd.read_csv(file3)
    df4 = pd.read_csv(file4)

    df1['recall'] = 100 * df1['recall']
    df2['recall'] = 100 * df2['recall']
    df3['recall'] = 100 * df3['recall']
    df4['recall'] = 100 * df4['recall']
    df1['specificity'] = 100 * df1['specificity']
    df2['specificity'] = 100 * df2['specificity']
    df3['specificity'] = 100 * df3['specificity']
    df4['specificity'] = 100 * df4['specificity']
    df1['Source'] = 'Our scheme'
    df2['Source'] = 'Li\'s scheme'
    df3['Source'] = 'HDRS'
    df4['Source'] = 'Zhao\'s scheme'  # no DR
    df_combined = pd.concat([df1, df2, df4, df3], ignore_index=True)
    plt.rcParams.update({
        'font.family': 'serif',  # 使用衬线字体（如 Times New Roman）
        # 'font.family': 'Times New Roman',
        'font.size': 10,  # 基础字号
        'axes.labelsize': 10,  # 坐标轴标签字号
        'axes.titlesize': 12,  # 标题字号
        'xtick.labelsize': 8,  # X轴刻度字号
        'ytick.labelsize': 8,  # Y轴刻度字号
        'legend.fontsize': 8,  # 图例字号
        'figure.dpi': 300,  # 分辨率（适合论文）
        'savefig.dpi': 300,  # 保存分辨率
        'figure.figsize': (4, 3),  # 图形大小（宽，高，单位英寸）
        'lines.linewidth': 1.5,  # 线宽
        'axes.grid': True,  # 显示网格
        'grid.linestyle': '--',  # 虚线网格
        'grid.alpha': 0.3,  # 网格透明度
        'legend.frameon': True,  # 图例边框
        'legend.framealpha': 0.8,
    })
    # recall
    plt.figure()
    sns.lineplot(
        data=df_combined,
        x='malRate',
        y='recall',
        hue='Source',  # 颜色区分
        style='Source',  # 线型区分
        markers=True,
        dashes=False,
        palette='colorblind',
    )
    plt.xlabel('Percentage of Malicious Vehicles (%)')
    plt.ylabel('Detection Rate (%)')
    legend = plt.legend()
    # new_labels = ['Our scheme', 'Our scheme without DR']
    # for text, new_label in zip(legend.get_texts(), new_labels):
    #     text.set_text(new_label)
    # plt.tight_layout()
    plt.ylim(0, 100)
    plt.savefig(output1, bbox_inches='tight')
    plt.show()

    # fpr
    plt.figure()
    sns.lineplot(
        data=df_combined,
        x='malRate',
        y='specificity',
        hue='Source',  # 颜色区分
        style='Source',  # 线型区分
        markers=True,
        dashes=False,
        palette='colorblind',
    )
    plt.xlabel('Percentage of Malicious Vehicles (%)')
    plt.ylabel('False Positive Rate (%)')
    plt.ylim(0, 10)
    legend = plt.legend()
    # new_labels = ['Our scheme', 'Our scheme without DR']
    # for text, new_label in zip(legend.get_texts(), new_labels):
    #     text.set_text(new_label)
    # plt.tight_layout()
    plt.savefig(output2, bbox_inches='tight')
    plt.show()


# test()
# plot_gtv()
# plot_gtv_sea()
# plot_rate_t_sea()
plot_rate_per_sea()
