[TOC]

### 仿真实验——图

说明车辆按照自己的行驶路线会在仿真过程中加入或驶离仿真区域

车辆设置：三种恶意车辆，诋毁车辆有一定概率进行诋毁；普通恶意车辆一定概率发送错误的路况信息

起个名字？还是ABCD

可以合并

0. 轨迹图：Fig. 3 shows trace points of the 200 taxis during a month（Toward Secure Blockchain-Enabled Internet of Vehicles: Optimizing Consensus Management Using Reputation and Contract Theory）

<img src="D:\Onedrive\md文件-研究生阶段\pic\map.png" alt="map" style="zoom: 33%;" />

##### 文件记录

0：lazy+noDR

后续no lazy

1：无DR；2：有DR；3：全局信任作权重；4：一轮简单计算偏移度；

R：做不同恶意车辆占比，R0 no DR, R1 有DR

rate_95指恶意节点选取，A每9选，B每5选

##### 可用性分析——信任值变化

1. 不同恶意节点

GT和DR图，错误消息、开关、搭便车、（诋毁+合谋），4个图——不同类型设备GT或DR随时间变化

前三个是GT，第四个是DR

说明对恶意车辆的抵御效果：错误消息、诋毁、开关、搭便车（懒惰）

说明只进行诋毁的车辆因为路况信息是正确的，所以信任值也是正常的，但是DR是小的

##### 抗攻击能力

（增加诋毁车辆占比）

检测率、特异性两个一组：恶意车辆检测率（recall TP）特异性Specificity（1-误报率，TNR）

四条线：自己方案、noDR、两个对比方案

1. 随时间变化

不同速度？不行就改参数，例如周期长度等，再等比放大？

2. 不同恶意车辆占比

说明是：avg(rate)

v=50\v=80两组，四个图

速度大，检测率高还是低，其他文章是低，我这里高？？？速度快，更快达到收敛，avg高

数量100，速度越大，HDRS中检测率越低

占比:DR noDR 对比方案1 对比方案二

* 5-50

对比方案：（无权重、基于信任、一轮简单计算离散度）

1. Blockchain-Based Trust Management Model for Vehicular Ad Hoc Networks 2023

无推荐权重

2. HDRS: A Hybrid Reputation System With Dynamic Update Interval for Detecting Malicious Vehicles in VANETs 2021

推荐信任权重：到邻居的距离和邻居的信任值

（Trust in Vehicles: Toward Context-Aware Trust and Attack Resistance for the Internet of Vehicles

和该邻居的成功交互次数占所有邻居成功交互次数的占比，类似DT作为推荐权重）

3. Trust Management Strategy for Digital Twins in Vehicular Ad Hoc Networks

推荐信任过滤，基于推荐信任的相似度聚类、等



<img src="D:\Onedrive\md文件-研究生阶段\pic\image-20250225180219073.png" alt="image-20250225180219073" style="zoom:50%;" />

* 区块链node:时延latency

### 工具：

OpenStreeMap导出想要仿真的路段

https://www.openstreetmap.org/

veins-4.7.1+omnetpp-5.4.1+sumo-0.30.0

- ***\*OMNeT++ 5.6.2\****
- ***\*Veins 5.2\****
- ***\*SUMO 1.10.0\****
- ***\*INET 4.2.5\****

1. omnet++ 6.1：公开源码的网络仿真框架
2. sumo 1.21.0：开源的交通仿真软件，用于模拟城市的车辆流动，分析不同交通策略和管理措施的效果
3. veins 5.2：允许OMNeT++和SUMO之间进行联合仿真的框架，使得OMNeT++模拟的通信网络和SUMO模拟的移动车辆能够实时交互

> Java 和 MATLAB 进行，前者用于设计基于 IoV 的模拟器，而后者用于仔细分析模拟结果
>
> C++&Matlab
>

#### 流程

1. 导入veins和inet

2. 连接sumo和OMNeT++；必须要连一次，否则会连不上traci
   D:/Project/VANETs-TM/veins-veins-5.2/sumo-launchd.py -vv -c D:/Project/VANETs-TM/sumo-1.17.0/bin/sumo.exe
   ![image-20250209111227987](D:\Onedrive\md文件-研究生阶段\pic\image-20250209111227987.png)

3. 使用SUMO创建道路网络和车辆轨迹（可以修改.rou.xml？？），并导出到OMNeT++中

   * 截取：22.515-22.56（5.01km）；113.9-113.96（6.15km）；30.86 km^2^

   * 路网文件：netconvert --osm-files map.osm -o map.net.xml

   * 车辆流：python D:/ProgramData/STools/sumo-1.17.0/tools/randomTrips.py -n map.net.xml -r map.rou.xml -e 200 -p 2 --fringe-factor 10 // 不加-l; --fringe-factor 10 为从边缘出发的偏向度；去掉  --speed 15  后就随机出发地了；-e时间，-p生成频率，2s一辆

     ```
     先快速随机生成50辆
     python D:/ProgramData/STools/sumo-1.17.0/tools/randomTrips.py -n map.net.xml -r map.rou.xml -e 25 -p 0.5 --fringe-factor 5 
     再从边缘来50辆
     python D:/ProgramData/STools/sumo-1.17.0/tools/randomTrips.py -n map.net.xml -r map_2.rou.xml -e 125 -p 2 --fringe-factor 20
     其他
     python D:/ProgramData/STools/sumo-1.17.0/tools/randomTrips.py -n map.net.xml -r map.rou.xml -e 150 -p 1.5 --fringe-factor 10
     ```

     

   * 地形文件：polyconvert --net-file map.net.xml --osm-files map.osm -o map.poly.xml // --skip-errors

4. OMNeT++中使用VEINS通过socket和SUMO连接，借助VEINS实现的TRACI接口来设置车辆相关的行为和场景

5. 在OMNET++中结合VEINS、SUMO运行联合仿真实验

#### veins中实现代码逻辑

// 当前直接生成sat，后续可以改为几个地点发生事件，车辆广播事件信息（可以是二元信息）

设置：car和RSU都有stage，从0开始，周期0记录本周期最后计算得到的值

车辆发送消息加一个是否恶意的标记，方便计算检测率

1. 参数设置、改rou文件（车辆流10s出现，后续行驶）

2. 新建msg文件；周期？

   * msg0—inforMsg: 发送者ID，满意度

   * msg1—reportMsgD：发送者ID，一组：车辆ID&直接信任值
   * msg2—reportMsgL：一组：车辆ID&本地信任值
   * msg3—RSUBroadcast：车辆ID、DR、（黑名单）

3. RSU设置——功能代码；只设置一个RSU，相当于区块链

   * 接收DT，计算DR、GP
   * 接收LT，更新GT、检测率

4. 车辆功能代码
   * 2s交互：广播一个数，收到的车辆自己计算距离是否在范围内，在则作为一次交互（路况信息发送），生成一个直接信任
   * 4s广播DT
   * 4s计算RT、LT（定期从RSU获取全局参数，更新参数），LT发给RSU

5. 图1：不同类型设备信任值变化（每一类取均值）？？？画图如何获取所有车辆的值来求均值等？还是取某几个车辆来画图

6. 图2：不同速度、不同车辆数量的信任值变化？正常车辆的信任值？表现收敛速率？

7. 图3：检测率

#### 其他

* 根据osm文件生成对应道路文件：project-draft-map.py
* sumo查看地图：对应文件夹下：sumo-gui -c map.sumo.cfg

#### 代码运行流程

1. omnetpp读取 `omnetpp.ini` 文件中的配置
2. 根据ned文件定义的网络拓扑，初始化车辆和RSU
3. 通过 `*.manager.command` 参数启动SUMO，并传递SUMO配置文件路径
4. OMNeT++和SUMO通过TraCI（Traffic Control Interface）协议进行同步，omnet通过该协议控制sumo中的车辆和RSU
5. `omnetpp.ini` 文件中配置的消息发送间隔和物理发送范围，车辆和RSU发送和接收消息
6. 可以通过OMNeT++的图形界面或日志文件查看仿真结果

#### 数据

<img src="D:\Onedrive\md文件-研究生阶段\pic\image-20250326154636503.png" alt="image-20250326154636503" style="zoom:50%;" />

指标：

<img src="D:\Onedrive\md文件-研究生阶段\pic\image-20250326155513897.png" alt="image-20250326155513897" style="zoom:50%;" />

#### 指标

##### 参考

* 动态阈值和静态阈值分别使车辆被检测所用的时间
* 动态阈值和静态阈值下集群的吞吐量变化，即合法数据包与数据包总数的比率，动态阈值更早达到最大值，说明伪造数据包更早清除



#### 补充

* 当前只有DR的图，新增有DR和无DR，进行信任欺骗攻击车辆的信任值变化，以及被诋毁的正常车辆的信任值变化

* 恶意车辆占比——到多少会导致信任系统失效

* ？不同参数选取对检测率或者一些指标的影响？

* 计算激励参数和不计算激励参数，检测到的时间不同

  

### 算法

#### DR

* 评价时间是否影响
* 正向激励之类的参数是否可以作为信任计算的权重，而非最终的权重
* 是否考虑车辆资源，例如可用带宽、剩余功率（不选簇头不需要这些指标）

#### 检测阈值

* 在黑名单超过一定时间就剔除网络；在黑名单的车辆有惩罚，应该就不用这一机制
* 自适应阈值，对每个车辆阈值可能不同，例如信任下降阈值升高；有下降惩罚



### 其他部分

* hybrid不够，加上scalable？
* 在网络的依据
* 动态阈值算法是否优化，是否算一个点。目前不太算

### 最后

对于大量属性，我们应用机器学习模型。然而，贝叶斯模型适用于二进制数据。

obstacle设置很重要！设置了房屋、树木等设施造成的信号衰减，导致物理层收到消息但不传给mac执行onWSM

范围设置：车辆9~10距离为560m，设置为500m以内可以接受sat、生成DT

<img src="D:\Onedrive\md文件-研究生阶段\pic\image-20250224225947801.png" alt="image-20250224225947801" style="zoom:67%;" />

#### 问题1

广播消息，部分车辆能调mac、onWSM进行处理，其他的只是物理层收到，不调mac处理。

可能是得在一条路上且不太远？

发送sat消息：mac层处理、物理层封装、发送完成（366-369）

** Event #663  t=21.190901046016  myScenario.node[5].nic.mac1609_4 (Mac1609_4, id=49)  on satMsg (veins::inforMsg, id=28421)

** Event #356  t=19.014967213293  myScenario.node[5].nic.phy80211p (PhyLayer80211p, id=48)  on satMsg (veins::Mac80211Pkt, id=443)

** Event #366  t=19.015199213293  myScenario.node[5].nic.phy80211p (PhyLayer80211p, id=48)  on selfmsg transmission over (omnetpp::cMessage, id=196)

** Event #367  t=19.015199213293  myScenario.node[5].nic.mac1609_4 (Mac1609_4, id=49)  on Transmission over (omnetpp::cMessage, id=457)

** Event #368  t=19.015199213293  myScenario.node[5].nic.mac1609_4 (Mac1609_4, id=49)  on ChannelStatus (omnetpp::cMessage, id=458)

** Event #369  t=19.015199213293  myScenario.node[5].nic.mac1609_4 (Mac1609_4, id=49)  on Radio switching over (omnetpp::cMessage, id=459)

接收消息：物理层接收、mac层处理

** Event #357  t=19.014967445935  myScenario.node[8].nic.phy80211p (PhyLayer80211p, id=66)  on satMsg (veins::AirFrame11p, id=454)

** Event #358  t=19.014967445935  myScenario.node[8].nic.mac1609_4 (Mac1609_4, id=67)  on ChannelStatus (omnetpp::cMessage, id=456)



** Event #666  t=21.190915023513  myScenario.node[5].nic.phy80211p (PhyLayer80211p, id=48)  on satMsg (veins::Mac80211Pkt, id=28424)

** Event #667  t=21.190915310566  myScenario.node[8].nic.phy80211p (PhyLayer80211p, id=66)  on satMsg (veins::AirFrame11p, id=28435)

接收消息：

** Event #667  t=21.190915310566  myScenario.node[8].nic.phy80211p (PhyLayer80211p, id=66)  on satMsg (veins::AirFrame11p, id=28435)

** Event #668  t=21.190915310566  myScenario.node[8].nic.mac1609_4 (Mac1609_4, id=67)  on ChannelStatus (omnetpp::cMessage, id=28438)

#### 问题2

RSU广播消息约2/3无法处理，日志如下：

** Event #34928  t=28.109591313137  node[26].nic.phy80211p on selfmsg (AirFrame11p, id=29396)  
** Event #34929  t=28.109591313137  node[26].nic.mac1609_4 on Error (cMessage, id=29536)  
** Event #34930  t=28.109591313137  node[26].nic.mac1609_4 on ChannelStatus (cMessage, id=29537)  

