#pragma once

#include "veins/modules/application/ieee80211p/DemoBaseApplLayer.h"
#include "veins/modules/application/traci/common.h"
#include "veins/modules/application/traci/RSUBroadcast_m.h"
#include <fstream> // �����ļ���֧��
#include <iostream>

namespace veins {

/**
 * Small RSU Demo using 11p
 */
class VEINS_API MyVeinsAppRSU: public DemoBaseApplLayer {
public:
    void initialize(int stage) override;
    void finish() override;

protected:
    void onWSM(BaseFrame1609_4 *wsm) override;
    void onWSA(DemoServiceAdvertisment *wsa) override;
    void handleSelfMsg(cMessage *msg) override;

//    void handlePositionUpdate(cObject *obj) override;
//    void ingestReport(int reporterId, int reporteeId, int msgId,
//            bool foundValid);
//    void addVehicletoCurrentBasket(int vehId);
//    void initVehicleStats(int vehId);

    void stageShift(int stage);
    void broadcastResults(int stage);
    void updateDR(int stage);
    void updateGT(int stage);
    void updateGP(int stage);
    void updateBL(int stage);
//    void calDetectionRate();

    std::ofstream outputFileG; // �ļ������
    std::ofstream outputFileR;
    std::ofstream logFile;
    bool isFileOpen = false;
    simtime_t stageShiftInterval;
//    cMessage *stageShiftEvt;
    int rsuStage;
//    int broadcastsSent;

    uint32_t timeIndex;
    int malAper = 5;
    int malBper = 11;
    double initGT = 0.6;
    double initDR = 0.7;
    std::set<int> allVehs;
    std::set<int> malVehs;
    std::set<int> drVehs;
    std::set<int> BL;
//    std::map<int, std::map<int, int>> interactionNum; // A...��BCD��ʱ�������ڽ�������
    std::map<int, int> interactionNum; // RSU �յ��Ľ�������
    std::map<int, std::map<int, double>> allDT; //�洢����A...: ��������������DT
    std::map<int, double> detectionRate;
    std::map<int, std::map<int, TrustData>> GTV; // ���ڣ�GTV
//    std::map<int, double> currDR;
};

}
