#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "veins/modules/application/traci/common.h"

#define MAX_ITER 10
#define DIM 2

double distance(Point a, Point b) {
    double dist = 0.0;
    for (int i = 0; i < DIM; i++) {
        dist += (a.x[i] - b.x[i]) * (a.x[i] - b.x[i]);
    }
    return sqrt(dist);
}

void kmeans(Point *data, int n_points, int K) {
    Point centers[K];
    int changed = 1, iter = 0;
    int counts[K];
    // ��ʼ�����ĵ㣨���ȡǰK���㣩
    for (int i = 0; i < K; i++) {
        centers[i] = data[i];
    }

    while (changed && iter < MAX_ITER) {
        changed = 0;
        // ����ÿ���㵽���������
        for (int i = 0; i < n_points; i++) {
            double min_dist = 1e9;
            int label = 0;
            for (int j = 0; j < K; j++) {
                double dist = distance(data[i], centers[j]);
                if (dist < min_dist) {
                    min_dist = dist;
                    label = j;
                }
            }
            if (data[i].label != label) {
                data[i].label = label;
                changed = 1;
            }
        }

        // ��������
        for (int j = 0; j < K; j++) {
            for (int d = 0; d < DIM; d++) centers[j].x[d] = 0;
            counts[j] = 0;
        }

        for (int i = 0; i < n_points; i++) {
            for (int d = 0; d < DIM; d++) {
                centers[data[i].label].x[d] += data[i].x[d];
            }
            counts[data[i].label]++;
        }

        for (int j = 0; j < K; j++) {
            if (counts[j] > 0) {
                for (int d = 0; d < DIM; d++) {
                    centers[j].x[d] /= counts[j];
                }
            }
        }

        iter++;
    }

    printf("KMeans finished in %d iterations.\n", iter);
    for (int i = 0; i < K; i++) {
        printf("Center %d: (%.2f, %.2f)\n", i, centers[i].x[0], centers[i].x[1]);
    }
}
