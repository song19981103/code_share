//
// Generated file, do not edit! Created by nedtool 5.6 from veins/modules/application/traci/reportMsgL.msg.
//

// Disable warnings about unused variables, empty switch stmts, etc:
#ifdef _MSC_VER
#  pragma warning(disable:4101)
#  pragma warning(disable:4065)
#endif

#if defined(__clang__)
#  pragma clang diagnostic ignored "-Wshadow"
#  pragma clang diagnostic ignored "-Wconversion"
#  pragma clang diagnostic ignored "-Wunused-parameter"
#  pragma clang diagnostic ignored "-Wc++98-compat"
#  pragma clang diagnostic ignored "-Wunreachable-code-break"
#  pragma clang diagnostic ignored "-Wold-style-cast"
#elif defined(__GNUC__)
#  pragma GCC diagnostic ignored "-Wshadow"
#  pragma GCC diagnostic ignored "-Wconversion"
#  pragma GCC diagnostic ignored "-Wunused-parameter"
#  pragma GCC diagnostic ignored "-Wold-style-cast"
#  pragma GCC diagnostic ignored "-Wsuggest-attribute=noreturn"
#  pragma GCC diagnostic ignored "-Wfloat-conversion"
#endif

#include <iostream>
#include <sstream>
#include <memory>
#include "reportMsgL_m.h"

namespace omnetpp {

// Template pack/unpack rules. They are declared *after* a1l type-specific pack functions for multiple reasons.
// They are in the omnetpp namespace, to allow them to be found by argument-dependent lookup via the cCommBuffer argument

// Packing/unpacking an std::vector
template<typename T, typename A>
void doParsimPacking(omnetpp::cCommBuffer *buffer, const std::vector<T,A>& v)
{
    int n = v.size();
    doParsimPacking(buffer, n);
    for (int i = 0; i < n; i++)
        doParsimPacking(buffer, v[i]);
}

template<typename T, typename A>
void doParsimUnpacking(omnetpp::cCommBuffer *buffer, std::vector<T,A>& v)
{
    int n;
    doParsimUnpacking(buffer, n);
    v.resize(n);
    for (int i = 0; i < n; i++)
        doParsimUnpacking(buffer, v[i]);
}

// Packing/unpacking an std::list
template<typename T, typename A>
void doParsimPacking(omnetpp::cCommBuffer *buffer, const std::list<T,A>& l)
{
    doParsimPacking(buffer, (int)l.size());
    for (typename std::list<T,A>::const_iterator it = l.begin(); it != l.end(); ++it)
        doParsimPacking(buffer, (T&)*it);
}

template<typename T, typename A>
void doParsimUnpacking(omnetpp::cCommBuffer *buffer, std::list<T,A>& l)
{
    int n;
    doParsimUnpacking(buffer, n);
    for (int i = 0; i < n; i++) {
        l.push_back(T());
        doParsimUnpacking(buffer, l.back());
    }
}

// Packing/unpacking an std::set
template<typename T, typename Tr, typename A>
void doParsimPacking(omnetpp::cCommBuffer *buffer, const std::set<T,Tr,A>& s)
{
    doParsimPacking(buffer, (int)s.size());
    for (typename std::set<T,Tr,A>::const_iterator it = s.begin(); it != s.end(); ++it)
        doParsimPacking(buffer, *it);
}

template<typename T, typename Tr, typename A>
void doParsimUnpacking(omnetpp::cCommBuffer *buffer, std::set<T,Tr,A>& s)
{
    int n;
    doParsimUnpacking(buffer, n);
    for (int i = 0; i < n; i++) {
        T x;
        doParsimUnpacking(buffer, x);
        s.insert(x);
    }
}

// Packing/unpacking an std::map
template<typename K, typename V, typename Tr, typename A>
void doParsimPacking(omnetpp::cCommBuffer *buffer, const std::map<K,V,Tr,A>& m)
{
    doParsimPacking(buffer, (int)m.size());
    for (typename std::map<K,V,Tr,A>::const_iterator it = m.begin(); it != m.end(); ++it) {
        doParsimPacking(buffer, it->first);
        doParsimPacking(buffer, it->second);
    }
}

template<typename K, typename V, typename Tr, typename A>
void doParsimUnpacking(omnetpp::cCommBuffer *buffer, std::map<K,V,Tr,A>& m)
{
    int n;
    doParsimUnpacking(buffer, n);
    for (int i = 0; i < n; i++) {
        K k; V v;
        doParsimUnpacking(buffer, k);
        doParsimUnpacking(buffer, v);
        m[k] = v;
    }
}

// Default pack/unpack function for arrays
template<typename T>
void doParsimArrayPacking(omnetpp::cCommBuffer *b, const T *t, int n)
{
    for (int i = 0; i < n; i++)
        doParsimPacking(b, t[i]);
}

template<typename T>
void doParsimArrayUnpacking(omnetpp::cCommBuffer *b, T *t, int n)
{
    for (int i = 0; i < n; i++)
        doParsimUnpacking(b, t[i]);
}

// Default rule to prevent compiler from choosing base class' doParsimPacking() function
template<typename T>
void doParsimPacking(omnetpp::cCommBuffer *, const T& t)
{
    throw omnetpp::cRuntimeError("Parsim error: No doParsimPacking() function for type %s", omnetpp::opp_typename(typeid(t)));
}

template<typename T>
void doParsimUnpacking(omnetpp::cCommBuffer *, T& t)
{
    throw omnetpp::cRuntimeError("Parsim error: No doParsimUnpacking() function for type %s", omnetpp::opp_typename(typeid(t)));
}

}  // namespace omnetpp

namespace {
template <class T> inline
typename std::enable_if<std::is_polymorphic<T>::value && std::is_base_of<omnetpp::cObject,T>::value, void *>::type
toVoidPtr(T* t)
{
    return (void *)(static_cast<const omnetpp::cObject *>(t));
}

template <class T> inline
typename std::enable_if<std::is_polymorphic<T>::value && !std::is_base_of<omnetpp::cObject,T>::value, void *>::type
toVoidPtr(T* t)
{
    return (void *)dynamic_cast<const void *>(t);
}

template <class T> inline
typename std::enable_if<!std::is_polymorphic<T>::value, void *>::type
toVoidPtr(T* t)
{
    return (void *)static_cast<const void *>(t);
}

}

namespace veins {

// forward
template<typename T, typename A>
std::ostream& operator<<(std::ostream& out, const std::vector<T,A>& vec);

// Template rule to generate operator<< for shared_ptr<T>
template<typename T>
inline std::ostream& operator<<(std::ostream& out,const std::shared_ptr<T>& t) { return out << t.get(); }

// Template rule which fires if a struct or class doesn't have operator<<
template<typename T>
inline std::ostream& operator<<(std::ostream& out,const T&) {return out;}

// operator<< for std::vector<T>
template<typename T, typename A>
inline std::ostream& operator<<(std::ostream& out, const std::vector<T,A>& vec)
{
    out.put('{');
    for(typename std::vector<T,A>::const_iterator it = vec.begin(); it != vec.end(); ++it)
    {
        if (it != vec.begin()) {
            out.put(','); out.put(' ');
        }
        out << *it;
    }
    out.put('}');

    char buf[32];
    sprintf(buf, " (size=%u)", (unsigned int)vec.size());
    out.write(buf, strlen(buf));
    return out;
}

LocalTrust::LocalTrust()
{
    this->vehicleId = 0;
    this->LT = 0;
}

void __doPacking(omnetpp::cCommBuffer *b, const LocalTrust& a)
{
    doParsimPacking(b,a.vehicleId);
    doParsimPacking(b,a.LT);
}

void __doUnpacking(omnetpp::cCommBuffer *b, LocalTrust& a)
{
    doParsimUnpacking(b,a.vehicleId);
    doParsimUnpacking(b,a.LT);
}

class LocalTrustDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertynames;
    enum FieldConstants {
        FIELD_vehicleId,
        FIELD_LT,
    };
  public:
    LocalTrustDescriptor();
    virtual ~LocalTrustDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyname) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyname) const override;
    virtual int getFieldArraySize(void *object, int field) const override;

    virtual const char *getFieldDynamicTypeString(void *object, int field, int i) const override;
    virtual std::string getFieldValueAsString(void *object, int field, int i) const override;
    virtual bool setFieldValueAsString(void *object, int field, int i, const char *value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual void *getFieldStructValuePointer(void *object, int field, int i) const override;
};

Register_ClassDescriptor(LocalTrustDescriptor)

LocalTrustDescriptor::LocalTrustDescriptor() : omnetpp::cClassDescriptor(omnetpp::opp_typename(typeid(veins::LocalTrust)), "")
{
    propertynames = nullptr;
}

LocalTrustDescriptor::~LocalTrustDescriptor()
{
    delete[] propertynames;
}

bool LocalTrustDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<LocalTrust *>(obj)!=nullptr;
}

const char **LocalTrustDescriptor::getPropertyNames() const
{
    if (!propertynames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
        const char **basenames = basedesc ? basedesc->getPropertyNames() : nullptr;
        propertynames = mergeLists(basenames, names);
    }
    return propertynames;
}

const char *LocalTrustDescriptor::getProperty(const char *propertyname) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : nullptr;
}

int LocalTrustDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 2+basedesc->getFieldCount() : 2;
}

unsigned int LocalTrustDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldTypeFlags(field);
        field -= basedesc->getFieldCount();
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,    // FIELD_vehicleId
        FD_ISEDITABLE,    // FIELD_LT
    };
    return (field >= 0 && field < 2) ? fieldTypeFlags[field] : 0;
}

const char *LocalTrustDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldName(field);
        field -= basedesc->getFieldCount();
    }
    static const char *fieldNames[] = {
        "vehicleId",
        "LT",
    };
    return (field >= 0 && field < 2) ? fieldNames[field] : nullptr;
}

int LocalTrustDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount() : 0;
    if (fieldName[0] == 'v' && strcmp(fieldName, "vehicleId") == 0) return base+0;
    if (fieldName[0] == 'L' && strcmp(fieldName, "LT") == 0) return base+1;
    return basedesc ? basedesc->findField(fieldName) : -1;
}

const char *LocalTrustDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldTypeString(field);
        field -= basedesc->getFieldCount();
    }
    static const char *fieldTypeStrings[] = {
        "int",    // FIELD_vehicleId
        "double",    // FIELD_LT
    };
    return (field >= 0 && field < 2) ? fieldTypeStrings[field] : nullptr;
}

const char **LocalTrustDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldPropertyNames(field);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

const char *LocalTrustDescriptor::getFieldProperty(int field, const char *propertyname) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldProperty(field, propertyname);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

int LocalTrustDescriptor::getFieldArraySize(void *object, int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldArraySize(object, field);
        field -= basedesc->getFieldCount();
    }
    LocalTrust *pp = (LocalTrust *)object; (void)pp;
    switch (field) {
        default: return 0;
    }
}

const char *LocalTrustDescriptor::getFieldDynamicTypeString(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldDynamicTypeString(object,field,i);
        field -= basedesc->getFieldCount();
    }
    LocalTrust *pp = (LocalTrust *)object; (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string LocalTrustDescriptor::getFieldValueAsString(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldValueAsString(object,field,i);
        field -= basedesc->getFieldCount();
    }
    LocalTrust *pp = (LocalTrust *)object; (void)pp;
    switch (field) {
        case FIELD_vehicleId: return long2string(pp->vehicleId);
        case FIELD_LT: return double2string(pp->LT);
        default: return "";
    }
}

bool LocalTrustDescriptor::setFieldValueAsString(void *object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->setFieldValueAsString(object,field,i,value);
        field -= basedesc->getFieldCount();
    }
    LocalTrust *pp = (LocalTrust *)object; (void)pp;
    switch (field) {
        case FIELD_vehicleId: pp->vehicleId = string2long(value); return true;
        case FIELD_LT: pp->LT = string2double(value); return true;
        default: return false;
    }
}

const char *LocalTrustDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldStructName(field);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    };
}

void *LocalTrustDescriptor::getFieldStructValuePointer(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldStructValuePointer(object, field, i);
        field -= basedesc->getFieldCount();
    }
    LocalTrust *pp = (LocalTrust *)object; (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

Register_Class(reportMsgL)

reportMsgL::reportMsgL(const char *name, short kind) : ::veins::BaseFrame1609_4(name, kind)
{
}

reportMsgL::reportMsgL(const reportMsgL& other) : ::veins::BaseFrame1609_4(other)
{
    copy(other);
}

reportMsgL::~reportMsgL()
{
    delete [] this->LT;
}

reportMsgL& reportMsgL::operator=(const reportMsgL& other)
{
    if (this == &other) return *this;
    ::veins::BaseFrame1609_4::operator=(other);
    copy(other);
    return *this;
}

void reportMsgL::copy(const reportMsgL& other)
{
    this->reporterAddress = other.reporterAddress;
    this->reporteeAddress = other.reporteeAddress;
    this->reporterPos = other.reporterPos;
    this->reporterId = other.reporterId;
    delete [] this->LT;
    this->LT = (other.LT_arraysize==0) ? nullptr : new LocalTrust[other.LT_arraysize];
    LT_arraysize = other.LT_arraysize;
    for (size_t i = 0; i < LT_arraysize; i++) {
        this->LT[i] = other.LT[i];
    }
}

void reportMsgL::parsimPack(omnetpp::cCommBuffer *b) const
{
    ::veins::BaseFrame1609_4::parsimPack(b);
    doParsimPacking(b,this->reporterAddress);
    doParsimPacking(b,this->reporteeAddress);
    doParsimPacking(b,this->reporterPos);
    doParsimPacking(b,this->reporterId);
    b->pack(LT_arraysize);
    doParsimArrayPacking(b,this->LT,LT_arraysize);
}

void reportMsgL::parsimUnpack(omnetpp::cCommBuffer *b)
{
    ::veins::BaseFrame1609_4::parsimUnpack(b);
    doParsimUnpacking(b,this->reporterAddress);
    doParsimUnpacking(b,this->reporteeAddress);
    doParsimUnpacking(b,this->reporterPos);
    doParsimUnpacking(b,this->reporterId);
    delete [] this->LT;
    b->unpack(LT_arraysize);
    if (LT_arraysize == 0) {
        this->LT = nullptr;
    } else {
        this->LT = new LocalTrust[LT_arraysize];
        doParsimArrayUnpacking(b,this->LT,LT_arraysize);
    }
}

const LAddress::L2Type& reportMsgL::getReporterAddress() const
{
    return this->reporterAddress;
}

void reportMsgL::setReporterAddress(const LAddress::L2Type& reporterAddress)
{
    this->reporterAddress = reporterAddress;
}

const LAddress::L2Type& reportMsgL::getReporteeAddress() const
{
    return this->reporteeAddress;
}

void reportMsgL::setReporteeAddress(const LAddress::L2Type& reporteeAddress)
{
    this->reporteeAddress = reporteeAddress;
}

const Coord& reportMsgL::getReporterPos() const
{
    return this->reporterPos;
}

void reportMsgL::setReporterPos(const Coord& reporterPos)
{
    this->reporterPos = reporterPos;
}

int reportMsgL::getReporterId() const
{
    return this->reporterId;
}

void reportMsgL::setReporterId(int reporterId)
{
    this->reporterId = reporterId;
}

size_t reportMsgL::getLTArraySize() const
{
    return LT_arraysize;
}

const LocalTrust& reportMsgL::getLT(size_t k) const
{
    if (k >= LT_arraysize) throw omnetpp::cRuntimeError("Array of size LT_arraysize indexed by %lu", (unsigned long)k);
    return this->LT[k];
}

void reportMsgL::setLTArraySize(size_t newSize)
{
    LocalTrust *LT2 = (newSize==0) ? nullptr : new LocalTrust[newSize];
    size_t minSize = LT_arraysize < newSize ? LT_arraysize : newSize;
    for (size_t i = 0; i < minSize; i++)
        LT2[i] = this->LT[i];
    delete [] this->LT;
    this->LT = LT2;
    LT_arraysize = newSize;
}

void reportMsgL::setLT(size_t k, const LocalTrust& LT)
{
    if (k >= LT_arraysize) throw omnetpp::cRuntimeError("Array of size  indexed by %lu", (unsigned long)k);
    this->LT[k] = LT;
}

void reportMsgL::insertLT(size_t k, const LocalTrust& LT)
{
    if (k > LT_arraysize) throw omnetpp::cRuntimeError("Array of size  indexed by %lu", (unsigned long)k);
    size_t newSize = LT_arraysize + 1;
    LocalTrust *LT2 = new LocalTrust[newSize];
    size_t i;
    for (i = 0; i < k; i++)
        LT2[i] = this->LT[i];
    LT2[k] = LT;
    for (i = k + 1; i < newSize; i++)
        LT2[i] = this->LT[i-1];
    delete [] this->LT;
    this->LT = LT2;
    LT_arraysize = newSize;
}

void reportMsgL::insertLT(const LocalTrust& LT)
{
    insertLT(LT_arraysize, LT);
}

void reportMsgL::eraseLT(size_t k)
{
    if (k >= LT_arraysize) throw omnetpp::cRuntimeError("Array of size  indexed by %lu", (unsigned long)k);
    size_t newSize = LT_arraysize - 1;
    LocalTrust *LT2 = (newSize == 0) ? nullptr : new LocalTrust[newSize];
    size_t i;
    for (i = 0; i < k; i++)
        LT2[i] = this->LT[i];
    for (i = k; i < newSize; i++)
        LT2[i] = this->LT[i+1];
    delete [] this->LT;
    this->LT = LT2;
    LT_arraysize = newSize;
}

class reportMsgLDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertynames;
    enum FieldConstants {
        FIELD_reporterAddress,
        FIELD_reporteeAddress,
        FIELD_reporterPos,
        FIELD_reporterId,
        FIELD_LT,
    };
  public:
    reportMsgLDescriptor();
    virtual ~reportMsgLDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyname) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyname) const override;
    virtual int getFieldArraySize(void *object, int field) const override;

    virtual const char *getFieldDynamicTypeString(void *object, int field, int i) const override;
    virtual std::string getFieldValueAsString(void *object, int field, int i) const override;
    virtual bool setFieldValueAsString(void *object, int field, int i, const char *value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual void *getFieldStructValuePointer(void *object, int field, int i) const override;
};

Register_ClassDescriptor(reportMsgLDescriptor)

reportMsgLDescriptor::reportMsgLDescriptor() : omnetpp::cClassDescriptor(omnetpp::opp_typename(typeid(veins::reportMsgL)), "veins::BaseFrame1609_4")
{
    propertynames = nullptr;
}

reportMsgLDescriptor::~reportMsgLDescriptor()
{
    delete[] propertynames;
}

bool reportMsgLDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<reportMsgL *>(obj)!=nullptr;
}

const char **reportMsgLDescriptor::getPropertyNames() const
{
    if (!propertynames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
        const char **basenames = basedesc ? basedesc->getPropertyNames() : nullptr;
        propertynames = mergeLists(basenames, names);
    }
    return propertynames;
}

const char *reportMsgLDescriptor::getProperty(const char *propertyname) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : nullptr;
}

int reportMsgLDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 5+basedesc->getFieldCount() : 5;
}

unsigned int reportMsgLDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldTypeFlags(field);
        field -= basedesc->getFieldCount();
    }
    static unsigned int fieldTypeFlags[] = {
        0,    // FIELD_reporterAddress
        0,    // FIELD_reporteeAddress
        0,    // FIELD_reporterPos
        FD_ISEDITABLE,    // FIELD_reporterId
        FD_ISARRAY | FD_ISCOMPOUND,    // FIELD_LT
    };
    return (field >= 0 && field < 5) ? fieldTypeFlags[field] : 0;
}

const char *reportMsgLDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldName(field);
        field -= basedesc->getFieldCount();
    }
    static const char *fieldNames[] = {
        "reporterAddress",
        "reporteeAddress",
        "reporterPos",
        "reporterId",
        "LT",
    };
    return (field >= 0 && field < 5) ? fieldNames[field] : nullptr;
}

int reportMsgLDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount() : 0;
    if (fieldName[0] == 'r' && strcmp(fieldName, "reporterAddress") == 0) return base+0;
    if (fieldName[0] == 'r' && strcmp(fieldName, "reporteeAddress") == 0) return base+1;
    if (fieldName[0] == 'r' && strcmp(fieldName, "reporterPos") == 0) return base+2;
    if (fieldName[0] == 'r' && strcmp(fieldName, "reporterId") == 0) return base+3;
    if (fieldName[0] == 'L' && strcmp(fieldName, "LT") == 0) return base+4;
    return basedesc ? basedesc->findField(fieldName) : -1;
}

const char *reportMsgLDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldTypeString(field);
        field -= basedesc->getFieldCount();
    }
    static const char *fieldTypeStrings[] = {
        "veins::LAddress::L2Type",    // FIELD_reporterAddress
        "veins::LAddress::L2Type",    // FIELD_reporteeAddress
        "veins::Coord",    // FIELD_reporterPos
        "int",    // FIELD_reporterId
        "veins::LocalTrust",    // FIELD_LT
    };
    return (field >= 0 && field < 5) ? fieldTypeStrings[field] : nullptr;
}

const char **reportMsgLDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldPropertyNames(field);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

const char *reportMsgLDescriptor::getFieldProperty(int field, const char *propertyname) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldProperty(field, propertyname);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

int reportMsgLDescriptor::getFieldArraySize(void *object, int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldArraySize(object, field);
        field -= basedesc->getFieldCount();
    }
    reportMsgL *pp = (reportMsgL *)object; (void)pp;
    switch (field) {
        case FIELD_LT: return pp->getLTArraySize();
        default: return 0;
    }
}

const char *reportMsgLDescriptor::getFieldDynamicTypeString(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldDynamicTypeString(object,field,i);
        field -= basedesc->getFieldCount();
    }
    reportMsgL *pp = (reportMsgL *)object; (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string reportMsgLDescriptor::getFieldValueAsString(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldValueAsString(object,field,i);
        field -= basedesc->getFieldCount();
    }
    reportMsgL *pp = (reportMsgL *)object; (void)pp;
    switch (field) {
        case FIELD_reporterAddress: {std::stringstream out; out << pp->getReporterAddress(); return out.str();}
        case FIELD_reporteeAddress: {std::stringstream out; out << pp->getReporteeAddress(); return out.str();}
        case FIELD_reporterPos: {std::stringstream out; out << pp->getReporterPos(); return out.str();}
        case FIELD_reporterId: return long2string(pp->getReporterId());
        case FIELD_LT: {std::stringstream out; out << pp->getLT(i); return out.str();}
        default: return "";
    }
}

bool reportMsgLDescriptor::setFieldValueAsString(void *object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->setFieldValueAsString(object,field,i,value);
        field -= basedesc->getFieldCount();
    }
    reportMsgL *pp = (reportMsgL *)object; (void)pp;
    switch (field) {
        case FIELD_reporterId: pp->setReporterId(string2long(value)); return true;
        default: return false;
    }
}

const char *reportMsgLDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldStructName(field);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        case FIELD_LT: return omnetpp::opp_typename(typeid(LocalTrust));
        default: return nullptr;
    };
}

void *reportMsgLDescriptor::getFieldStructValuePointer(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldStructValuePointer(object, field, i);
        field -= basedesc->getFieldCount();
    }
    reportMsgL *pp = (reportMsgL *)object; (void)pp;
    switch (field) {
        case FIELD_reporterAddress: return toVoidPtr(&pp->getReporterAddress()); break;
        case FIELD_reporteeAddress: return toVoidPtr(&pp->getReporteeAddress()); break;
        case FIELD_reporterPos: return toVoidPtr(&pp->getReporterPos()); break;
        case FIELD_LT: return toVoidPtr(&pp->getLT(i)); break;
        default: return nullptr;
    }
}

} // namespace veins

