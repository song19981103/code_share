#include "veins/modules/application/traci/MyVeinsAppCar.h"
#include "veins/modules/application/traci/RSUBroadcast_m.h"
#include "veins/modules/application/traci/reportMsgD_m.h"
#include "veins/modules/application/traci/reportMsgL_m.h"
#include "veins/modules/application/traci/inforMsg_m.h"
#include "veins/modules/application/traci/common.h"
#include <random>
#include <stdlib.h>
#include <math.h>

using namespace veins;

Define_Module(veins::MyVeinsAppCar);

// stage0:��ʼ����ǰ����ʱ��sim_time; stage1:������Ҫ��������ģ���ʼ���Ĳ������綨ʱ�����ȣ�
void MyVeinsAppCar::initialize(int stage) {
    DemoBaseApplLayer::initialize(stage);
    if (stage == 0) {
        // ��ȡ TraCI �ƶ�ģ��
        TraCIMobility *mobility = TraCIMobilityAccess().get(getParentModule());
        // ��ȡ SUMO ���� ID������ rou.xml �� id��
        std::string sumoId = mobility->getExternalId();
        nodeId = std::stoi(sumoId);
        isMal = false;
        // 10����Ϊ���⳵������Ϣ��
        if (nodeId % malAper == 0) {
            isMal = true;
        }
        RSUAddr = -1; // ��ʼΪ�㲥��ַ
        myStage = 0;
        rsuStage = -1; // ��û�洢
        messageInterval = par("messageInterval").doubleValue();
        satMessageInterval = par("satMessageInterval").doubleValue();
//        variance = par("messageIntervalVarianceLimit").doubleValue();
        EV_INFO << "Vehicle initializing, OMNeT++ ID: " << getId()
                       << ", SUMO NODE ID: " << nodeId << " , is malicious: "
                       << isMal << endl;
    } else if (stage == 1) {
        // �㲥�����
        scheduleAt(simTime() + satMessageInterval + uniform(0, 1),
                new cMessage("sendSatMsg", SAT_INFOMSG));
        // �㲥DT
        scheduleAt(simTime() + messageInterval + uniform(0, 0.1),
                new cMessage("sendDTMsg", DT_INFOMSG));
//        // �㲥LT
//        scheduleAt(simTime() + messageInterval + variance * uniform(0, 1),
//                new cMessage("sendLTMsg"));
    }
}

void MyVeinsAppCar::finish() {
//    recordScalar("#sent", sent);
//    // ... ��������
//    if (outputFile.is_open()) {
//        outputFile.close();
//    }
//    // ִ�� Python �ű�
//    system("python plot_trust.py");
}

//void MyVeinsAppCar::onWSA(DemoServiceAdvertisment *wsa) {
//
//}

// �������յ�����Ϣ
void MyVeinsAppCar::onWSM(BaseFrame1609_4 *frame) {
    EV << "onWSM::Vehicle " << nodeId << " received frame type: "
              << frame->getClassName() << endl;
    // �յ�������Ϣ������DT
    if (inforMsg *wsm = dynamic_cast<inforMsg*>(frame)) {
        Coord pos = wsm->getReporterPos();
        int reporterId = wsm->getReporterId();
        double s = wsm->getSatisfaction();
        simtime_t reportTime = wsm->getReportTime();
        simtime_t currTime = simTime();
        // �������ó�������·����Ϣ����ȷ��
        double sat = normal(s, 0.15);
        if (s >= 0.7) {
            if (sat >= 1) {
                sat = 1;
            } else if (sat <= 0.5) {
                sat = 0.5;
            }
        } else {
            if (sat >= 0.7) {
                sat = 0.7;
            } else if (sat <= 0) {
                sat = 0;
            }
        }

        double distance = curPosition.distance(pos);
        if (distance <= RANGE) {
            findHost()->getDisplayString().setTagArg("i", 1, "green");
            allVehs.insert(reporterId);
            EV << "onWSM::Vehicle " << nodeId << " received sat message from: "
                      << reporterId << ", distance: " << distance << endl;
            // TODO ��DT��Ӧ��¼���������ֵ���˴��򵥴�����
            // HDRS
//            double delta_t = currTime.dbl() - reportTime.dbl();
//            double w = pow(exp(delta_t), log(0.5) / 10.0);
//            sat = sat * w;
            DT[reporterId] = sat;
//            if (DT.find(reporterId) == DT.end()) {
//                DT[reporterId] = sat;  // ���reporterId�����ڣ��������ֵ
//            } else {
//                DT[reporterId] = (sat + DT[reporterId]) / 2; // ���reporterId�Ѵ��ڣ����ۼ�ֵ
//            }
        }
    }
    // �յ����洢DT��Ϣ
    else if (reportMsgD *wsm = dynamic_cast<reportMsgD*>(frame)) {
        Coord pos = wsm->getReporterPos();
        int senderIp = wsm->getReporterAddress();
        int senderId = wsm->getReporterId();
        double distance = curPosition.distance(pos);
        double RANGE = 500;
        if (distance <= RANGE) {
            findHost()->getDisplayString().setTagArg("i", 1, "orange");
            EV << "onWSM::Vehicle " << nodeId << " received DT message from "
                      << senderId << endl;
            int size = wsm->getDTArraySize();
            for (int i = 0; i < size; ++i) {
                DirectTrust data = wsm->getDT(i);
                allDT[data.vehicleId][senderId] = data.DT;
            }
        }
    }
    // �յ�RSU��Ϣ������ȫ�����β���
    else if (RSUBroadcast *wsm = dynamic_cast<RSUBroadcast*>(frame)) {
        EV << "onWSM::Vehicle " << nodeId
                  << " received RSU message, RSU stage: " << wsm->getStage()
                  << endl;
        findHost()->getDisplayString().setTagArg("i", 1, "red");
        int stage = wsm->getStage();
        RSUAddr = wsm->getReporterAddress();
        if (stage > rsuStage) {
            int size = wsm->getTrustDataArraySize();
            for (int i = 0; i < size; ++i) {
                TrustData data = wsm->getTrustData(i);
                GTV[stage][data.vehicleId] = data;
            }
            size = wsm->getBlacklistArraySize();
            BL.clear();
            for (int i = 0; i < size; i++) {
                BL.insert(wsm->getBlacklist(i));
            }
        }
        rsuStage = stage;
    } else {
        EV_INFO << "Frame is not an normal, it's a " << frame->getClassName()
                       << endl;
    }
}

// ��������λ�ñ仯����֤����λ�õĸ���
void MyVeinsAppCar::handlePositionUpdate(cObject *obj) {
    DemoBaseApplLayer::handlePositionUpdate(obj);
}

// ����ģ���ڲ�����Ϣ����WSA��WSM����Ϣ
void MyVeinsAppCar::handleSelfMsg(cMessage *msg) {
    EV << "HandleSelfMsg::Vehicle " << nodeId << " handle message, type = "
              << msg->getName() << endl;
//    if (msg->getName() == std::string("sendSatMsg")) {
    if (msg->getKind() == SAT_INFOMSG) {
        sendSatToNearbyVehicles();
        scheduleAt(simTime() + satMessageInterval + uniform(0, 1), msg);
    }
//    else if (msg->getName() == std::string("sendDTMsg")) {
    else if (msg->getKind() == DT_INFOMSG) {
        // ��鸽���ĳ�����������Ϣ
        sendDTToNearbyVehicles();
        scheduleAt(simTime() + messageInterval + uniform(0, 0.1), msg);
        // ִ�м��㡢������һ����
        calRT(myStage);
        calLT(myStage);
        DT.clear();
        allDT.clear();
        RT.clear();
        // ���ڽ���
        EV << "Vehicle " << nodeId << " stage " << myStage
                  << " end, neighbor num: " << allVehs.size() << endl;
        myStage++;
    } else {
        DemoBaseApplLayer::handleSelfMsg(msg);
    }
//    else if (msg->getName() == std::string("sendLTMsg")) {
//        calRT(myStage);
//        calLT(myStage);
//        // TODO ��¼����������Ϣ
////        writeInFile();
//        // ����Ҫ�㲥LT
////        reportMsgL *msg = new reportMsgL();
////        msg->setReporterAddress(myId);
////        msg->setReporteeAddress(RSUAddr); // ����Ϣ���͸� RSU
////        msg->setReporterId(nodeId);
////        int i = 0;
////        for (auto entry = LT[myStage].begin(); entry != LT[myStage].end();
////                ++entry) {
////            LocalTrust lt;
////            lt.vehicleId = entry->first;
////            lt.LT = entry->second;
////            msg->setLT(i++, lt);
////        }
////        sendDown(msg);
//        // ���DT\allDT\RT
//        DT.clear();
//        allDT.clear();
//        RT.clear();
//        scheduleAt(simTime() + messageInterval, msg);
//        // ���ڽ���
//        EV << "Vehicle " << nodeId << " stage " << myStage
//                  << " end, neighbor num: " << allVehs.size() << endl;
//        myStage++;
//    }
}

void MyVeinsAppCar::writeInFile() {
    // TODO stage=0�Ķ��Ӹ��жϣ�������stage��stage-1����
//    for (const auto entry : LT[stage]) {
//        int vehicleId = entry.first;
//        double trustValue = entry.second;
//        // д�뵱ǰʱ�䡢����ID������ֵ
//        if (outputFile.is_open()) {
//            outputFile << simTime() << "," << vehicleId << "," << trustValue
//                    << "\n";
//        }
//    }
}

// �㲥sat
void MyVeinsAppCar::sendSatToNearbyVehicles() {
    inforMsg *msg = new inforMsg("satMsg");
    msg->setReporterAddress(myId);
//    msg->setReporteeAddress(); // ��д��ַ�����㲥
    msg->setReporterPos(curPosition);
    msg->setReporterId(nodeId);
    // TODO �����޸ķֲ�����
    double s = uniform(0.7, 1);
    double rand = uniform(0, 1.0);
//    double rand = 0;
    // nodeId��myId
    if (nodeId % malAper == 0 && rand <= 0.9) { // һ���ĸ�������
        s = uniform(0.2, 0.7);
    }
    simtime_t t = simTime();
    msg->setReportTime(t);
    // ���ع���
//    if (nodeId % 17 == 0 && rand <= 0.8
//            && (t >= 100 && t <= 150 || t >= 200 && t <= 250)) {
//        s = uniform(0.3, 0.7);
//    }
    msg->setSatisfaction(s);
    msg->setKind(SAT_INFOMSG);
    populateWSM(msg);
//    sendDelayedDown(msg->dup(), uniform(0, 0.03)); // ����΢С����ӳ�
    sendDown(msg);
    EV_INFO << "Vehicle " << nodeId << " broadcasting sat message, Sat = " << s
                   << endl;
}

// �㲥DT
void MyVeinsAppCar::sendDTToNearbyVehicles() {
    if (DT.empty()) {
        EV_WARN << "DT is empty, vehicle " << nodeId << ", stage " << myStage
                       << endl;
        return;
    }
    reportMsgD *msg = new reportMsgD();
    msg->setReporterAddress(myId);
//    msg->setReporteeAddress(); // �㲥
    msg->setReporterPos(curPosition);
    msg->setReporterId(nodeId);
    msg->setIsMal(isMal);
    int i = 0, num = DT.size();
    msg->setDTArraySize(num);
    // TODO array 0 ����
    for (const auto &entry : DT) {
        DirectTrust dt;
        dt.vehicleId = entry.first;
        dt.DT = entry.second;
        // ڮ��
        double rand = uniform(0, 1);
//        double rand = 0;
        // һ�����ڮ����������
        if (rand < 0.9 && nodeId % malBper == 0) {
            if (dt.vehicleId % malAper != 0) {
//                dt.DT /= 3;
                dt.DT = uniform(0, 0.2);
            } else {
                dt.DT = uniform(0.8, 1);
//                dt.DT *= 2;
//                if (dt.DT > 0.9) {
//                    dt.DT = 0.9;
//                }
            }
        }
        msg->setDT(i++, dt);
    }
//    msg->setKind(DT_INFOMSG);
    populateWSM(msg);
    EV_INFO << "Vehicle " << nodeId << " broadcasting DT message" << endl;
    sendDelayedDown(msg->dup(), uniform(0.03, 0.05));
}

// DR��ΪȨ�أ���DT��Ȩ���
void MyVeinsAppCar::calRT(int stage) {
    double w = 0.8; // DRĬ��ֵ
    for (int veh : allVehs) {
        // �����veh��RT
        double wSum = 0;
        double rt = 1;
        for (const auto map : allDT[veh]) {
            int vehB = map.first;
            // ���ں�����
            if (BL.find(vehB) == BL.end()) {
//                if (stage != GTV.size() - 1) {
//                    EV << "Error rsuStage in calRT" << endl;
//                }
                if (stage > 0) {
                    rt += map.second * GTV[stage - 1][vehB].DR;
                    wSum += GTV[stage - 1][vehB].DR;
                } else {
                    rt += map.second * w;
                    wSum += w;
                }
            }
        }
        // TODO û���Ƽ�Ĭ��0.5����
        if (wSum == 0) {
            wSum = 2;
        }
        rt /= wSum;
        RT[veh] = rt;
    }
}

void MyVeinsAppCar::calLT(int stage) {
    double w1 = 0.7, w2 = 0.5; // ��ʷȨ�ء�DTȨ��
    if (stage != LT.size() - 1) {
        stage = LT.size() - 1;
//        return;
    }
    for (int veh : allVehs) {
        double dt = 0.7, rt = 0.7;
        if (DT.find(veh) != DT.end()) {
            dt = DT[veh];
        }
        if (RT.find(veh) != RT.end()) {
            rt = RT[veh];
        }
        dt = dt * w2 + rt * (1 - w2);
        if (stage > 0 && LT[stage - 1][veh] > 0) {
            LT[stage][veh] = LT[stage - 1][veh] * w1 + dt * (1 - w1);
        } else {
            LT[stage][veh] = dt;
        }
        // ��������ʱ��������GP
    }
}

// ������ʱ��Ϣ��Ϊ�˱�����Ϣ��ͻ������ʹ���������Ϊÿ����Ϣ���������ʱ��
//sendDelayedDown(cMessage *msg, simtime_t delay);
