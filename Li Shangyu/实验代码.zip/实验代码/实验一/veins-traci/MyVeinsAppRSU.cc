#include "veins/modules/application/traci/MyVeinsAppRSU.h"
#include "veins/modules/application/traci/RSUBroadcast_m.h"
#include "veins/modules/application/traci/reportMsgD_m.h"
#include "veins/modules/application/traci/reportMsgL_m.h"
#include "veins/modules/application/traci/common.h"

#include <math.h>
#include <random>
#include <stdlib.h>
#include <fstream> // �����ļ���֧��
#include <iostream>

using namespace veins;

Define_Module(veins::MyVeinsAppRSU);

// ������ʼ������Դ����
void MyVeinsAppRSU::initialize(int stage) {
//    EV << "TEST RSU initializing" << std::endl;
    DemoBaseApplLayer::initialize(stage);
    if (stage == 0) {
        EV << "RSU initializing stage 0" << std::endl;
        std::string filename1 = "results/GTV_values_R1.csv";
        std::string filename2 = "results/Rate_R1.csv";
        outputFileG.open(filename1, std::ios::out);
        outputFileR.open(filename2, std::ios::out);
        logFile.open("results/log1.csv", std::ios::out);
        if (!outputFileG.is_open() || !outputFileR.is_open()) {
            EV_ERROR << "can not open file" << endl;
            throw std::runtime_error("�޷����ļ�");
        }
//        isFileOpen = true;
        // д��CSV��ͷ
        outputFileG << "simTime,vehicleId,GP,DR,GT\n";
        outputFileR << "simTime,recall,specificity,TP,FP,TN,FN\n"; // TPR-recall����������ʣ�TNR�����������
        outputFileG.flush(); // ����д�����
        outputFileR.flush(); // ����д�����
        EV_INFO << "file created: " << filename1 << " and " << filename2
                       << endl;
    } else if (stage == 1) {
        EV << "RSU initializing stage 1" << std::endl;
        rsuStage = 0;
        stageShiftInterval = par("stageShiftInterval");
        scheduleAt(simTime() + stageShiftInterval, new cMessage("stageShift")); // + uniform(-0.1, 0.1)
    }
}

// �ͷ���Դ�����ͳ������
void MyVeinsAppRSU::finish() {
    DemoBaseApplLayer::finish();
    if (outputFileG.is_open()) {
        outputFileG.flush();
        outputFileG.close();
        EV_INFO << "G file closed" << endl;
    }
    if (outputFileR.is_open()) {
        outputFileR.flush();
        outputFileR.close();
        EV_INFO << "R file closed" << endl;
    }
    logFile.flush();
    logFile.close();

// ִ�� Python �ű�
//    system("python plot_trust.py");
}

void MyVeinsAppRSU::onWSA(DemoServiceAdvertisment *wsa) {

}

// �����յ�����Ϣ
void MyVeinsAppRSU::onWSM(BaseFrame1609_4 *frame) {
    EV_INFO << "RSU received frame type: " << frame->getClassName() << endl;
// �յ�������Ϣ���洢DT���ظ�A��B��DT������ʱ���ֵ��
    if (reportMsgD *wsm = dynamic_cast<reportMsgD*>(frame)) {
        findHost()->getDisplayString().setTagArg("i", 1, "green");
        // �洢DT������interactionNum
        int senderIp = wsm->getReporterAddress();
        int senderId = wsm->getReporterId();
        EV_INFO << "RSU received DT message from: " << senderId << endl;
        int size = wsm->getDTArraySize();
        allVehs.insert(senderId);
//        if (wsm->isMal() && senderId % malAper != 0) {
//            EV_WARN << "RSU: vehicle malicious condition error" << endl;
//            return;
//        }
//        if (wsm->isMal()) {
//            malVehs.insert(senderId);
//        }
        for (int i = 0; i < size; ++i) {
            DirectTrust data = wsm->getDT(i);
            allVehs.insert(data.vehicleId);
            allDT[data.vehicleId][senderId] = data.DT;
            interactionNum[data.vehicleId]++;
            interactionNum[senderId]++;
        }
    }
// ��������������Ϣ
//    else if (reportDumpMsg *wsm = dynamic_cast<reportDumpMsg*>(frame)) {
//        int reporteeId = wsm->getReporteeAddress();
//        int senderId = wsm->getSenderAddress();
//        intSet trueMsgs = csvToIntSet(std::string(wsm->getTrueMsgs()));
//        intSet falseMsgs = csvToIntSet(std::string(wsm->getTrueMsgs()));
//        for (auto msgId : trueMsgs)
//            ingestReport(senderId, reporteeId, msgId, true);
//        for (auto msgId : trueMsgs)
//            ingestReport(senderId, reporteeId, msgId, false);
//    }
// RSU���й㲥
//    if (rsuStage < stageCounter) {
// todo
//        std::lock_guard<std::mutex> lock(staticMemberAccessLock);
//        RSUBroadcast *rsucast = new RSUBroadcast();
//        populateWSM(rsucast);
//        rsucast->setName("RSU Broadcast");
//        rsucast->setVehIdAndScoresCSV(broadcastDataCSV.c_str());
//        rsucast->setBlacklistCSV(blacklistCSV.c_str());
//        rsucast->setBroadcastId(stageCounter);
//        sendDown(rsucast);
//        broadcastsSentVector.record(++broadcastsSent);
//    }
}

// ��ʱ������ִ������
void MyVeinsAppRSU::handleSelfMsg(cMessage *msg) {
    EV << "RSU handle message, type = " << msg->getName() << std::endl;
    if (msg->getName() == std::string("stageShift")) {
        // ���ݱ������յ������ݸ������Ρ��㲥
        stageShift(rsuStage);
        rsuStage++;
//        scheduleAt(simTime() + stageShiftInterval, msg);
    }
}

// ִ�м������񣬸������β�����������һ������
void MyVeinsAppRSU::stageShift(int stage) {
    EV << "RSU stage shifting to " << stage + 1 << ", current vehicle num is "
              << allVehs.size() << std::endl;
    for (int veh : allVehs) {
        if (GTV[stage - 1][veh].GT == 0) {
            GTV[stage - 1][veh].GT = initGT;
        }
        if (GTV[stage - 1][veh].DR == 0) {
            GTV[stage - 1][veh].DR = initDR;
        }
    }
    // ����ɿ���DR
    updateDR(stage);
    for (int veh : allVehs) {
        if (GTV[stage][veh].DR == 0) {
            GTV[stage][veh].DR = GTV[stage - 1][veh].DR;
        }
    }
    // ����GT
    updateGT(stage);
    //�����0ֵ��Ϊ������ֵ
    for (int veh : allVehs) {
        if (GTV[stage][veh].GT == 0) {
            GTV[stage][veh].GT = GTV[stage - 1][veh].GT;
        }
    }
    // ����GP���漰��GT�仯
    updateGP(stage);
    // ��GT��GP����BL
    malVehs.clear();
    updateBL(stage);

// ÿ�θ��º��¼��������ֵ
    EV << "RSU save global params to file, vehicle num is " << GTV[stage].size()
              << std::endl;
    for (const auto &entry : GTV[stage]) {
        int vehicleId = entry.first;
        TrustData td = entry.second;
        // д�뵱ǰʱ�䡢����ID������ֵ
        if (outputFileG.is_open()) {
            simtime_t t = simTime();
            outputFileG << t.str() << "," << vehicleId << "," << td.GP << ","
                    << td.DR << "," << td.GT << "\n";
            outputFileG.flush();
        }
    }
    broadcastResults(stage);
    // Log ��¼RSU�յ������г��������⳵������ǰ���ڶԸ���������DT���۵ļ���
    if (logFile.is_open()) {
        logFile << "\n stage " << stage << "\n";
        logFile << "allVehicles, size: " << allVehs.size() << ": ";
        for (int veh : allVehs) {
            logFile << veh << " ";
        }
        logFile << "\nMalicious Vehicles, size: " << malVehs.size() << ": ";
        for (int veh : malVehs) {
            logFile << veh << " ";
        }
        logFile << "\nDT size: " << allDT.size() << ": ";
        for (const auto &e : allDT) {
            logFile << e.first << ":" << e.second.size() << " ";
        }
//        if (stage == 5) {
//            for (const auto &e : allDT) {
//                logFile << "\n" << e.first << ": ";
//                for (const auto &e1 : e.second) {
//                    logFile << e1.first << ":" << e1.second << " ";
//                }
//            }
//        }
        logFile.flush();
    }
    // ���DT\interactionNum
    allDT.clear();
    interactionNum.clear();
}

// �㲥ȫ�����β���
void MyVeinsAppRSU::broadcastResults(int stage) {
    if (GTV.empty()) {
        EV_WARN << "RSU: GTV is empty in stage " << stage << endl;
        return;
    }
    if (GTV.size() != stage + 1) {
        EV_WARN << "RSU: GTV size: " << GTV.size() << ", stage: " << stage
                       << endl;
        return;
    }
    EV << "RSU broadcast global trust info in stage " << stage
              << ", vehicle num: " << GTV[stage].size() << std::endl;
    RSUBroadcast *msg = new RSUBroadcast();
    msg->setTrustDataArraySize(GTV[stage].size());
    msg->setReporterAddress(myId);
    msg->setStage(stage);
//    msg->setReporteeAddress(); // ��д��ַ�����㲥
    int i = 0;
    // TODO array 0 ����
    for (const auto &entry : GTV[stage]) {
        msg->setTrustData(i, entry.second);
        i++;
    }
    populateWSM(msg);
    sendDelayedDown(msg->dup(), uniform(0, 0.05));
    scheduleAt(simTime() + stageShiftInterval + uniform(-0.1, 0.1),
            new cMessage("stageShift"));
}

// ���ӳ���ID
//void MyVeinsAppRSU::addVehicletoCurrentBasket(int vehId) {
//
//}

// ͨ��allDT�����豸�ɿ��� DR
void MyVeinsAppRSU::updateDR(int stage) {
    EV << "update DR " << endl;
    if (allDT.empty()) {
        EV_WARN << "RSU: allDT is empty in stage " << stage << endl;
        return;
    }
    // �ʼ��������0��DR����ʼ������-1��DRΪ1
    std::map<int, TrustData> GTV_curr = GTV[stage - 1];
    double e1 = 0.1, e2 = 0.6, e3 = 0.01; // e1��������Χ��e2����һ��DRȨ�أ�e3�Ǽ���w�Ĳ���
    std::map<int, double> W;
    // ��������i
    for (const auto &entry : allDT) {
        int i = entry.first;
        std::map<int, double> DT = entry.second;
        // !!С�ڵ����������̫�󣬲���
        if (DT.size() < 3) {
            continue;
        }
        std::map<int, double> w;
        // ��ʼ��w
        double Tru_i = 0.0, sum_DR = 0.0;
//        for (const auto &e : DT) {
//            int k = e.first;
//            if (drVehs.find(k) == drVehs.end()) {
//                GTV_curr[k].DR = initDR;
//                drVehs.insert(k);
//            }
//            // kһ��!=i���Ͳ��ж���
//            sum_DR += GTV_curr[k].DR;
//        }
//        if (sum_DR == 0) {
//            EV_WARN
//                           << "Warning: sum_DR is zero, which may cause division errors!"
//                           << endl;
//            sum_DR = 1.0;
//            continue;
//        }
        for (const auto &e : DT) {
            int k = e.first;
//            w[k] = GTV_curr[k].DR / sum_DR;
            w[k] = 1.0 / DT.size(); // ! 1.0
//            EV << k << " " << w[k] << endl;
        }
        // ѭ������w��cntԽС����Ȩ�ز���ԽС
        int cnt = 0;
        while (cnt < 3) {
            cnt++;
            double previous_Tru_i = Tru_i;
            Tru_i = 0.0; // !
            for (const auto &e : DT) {
                int k = e.first;
                double val = e.second;
                Tru_i += w[k] * val;
            }
            // Check for convergence
            if (std::abs(Tru_i - previous_Tru_i) < e1) {
                break;
            }
            // Calculate distances
            std::map<int, double> dis;
            for (const auto &e : DT) {
                int k = e.first;
                double val = e.second;
                dis[k] = pow(Tru_i - val, 2);
            }
            // Update weights
            double sum_inverse_dis = 0.0;
            for (const auto &e : DT) {
                int k = e.first;
                double val = e.second;
                sum_inverse_dis += 1.0 / (dis[k] + e3);
            }
            for (const auto &e : DT) {
                int k = e.first;
                double val = e.second;
                w[k] = (1.0 / (dis[k] + e3)) / sum_inverse_dis;
            }
            // curr DR���ǵø������DTsize����Լ��
//            if (cnt == 0) {
//                for (const auto &e : w) {
//                    currDR[e.first] += e.second;
//                }
//            }
        }
        for (const auto &e : w) {
            W[e.first] += e.second;
        }
    }
    int j;
    double w_max = 0.0;
    for (const auto &e : W) {
        if (e.second > w_max) {
            w_max = e.second;
        }
    }
    simtime_t t = simTime();
    for (auto &e : W) {
        int k = e.first;
        double update = e.second / w_max;
//        EV << k << " " << e.second << " " << update << endl;
        // ����ֵ��С
        if (update < 0.2) {
            update = 0.2;
        }
        // R
//        if (t < 50 && k % 9 == 0) {
//            update += 0.3;
//        }
//        if (update < 0.6 && k % 9 != 0) {
//            update += 0.1;
//            if (t < 130) {
//                update += 0.1;
//            }
//        }
        GTV[stage][k].DR = GTV[stage - 1][k].DR * e2 + update * (1 - e2);
    }
}

// ����ȫ������ GT
void MyVeinsAppRSU::updateGT(int stage) {
    EV << "update GT " << endl;
    double w = 0.8;
    for (const auto &e : allDT) {
        int veh = e.first;
        std::map<int, double> DT = e.second;
        if (DT.empty()) {
            continue;
        }
        double gt = 0, p = 0;
        // DR
        for (const auto &e1 : DT) {
            int k = e1.first;
            p += GTV[stage][k].DR;
            gt += GTV[stage][k].DR * e1.second;
        }
        // no DR (Zhao)-------------------------
//        for (const auto &e1 : DT) {
//            p++;
//            gt += e1.second;
//        }
        // GT��Ȩ�� (HDRS)------------------------
//        for (const auto &e1 : DT) {
//            int k = e1.first;
//            p += GTV[stage - 1][k].GT;
//            gt += GTV[stage - 1][k].GT * e1.second;
//        }
        // curr DR һ��DR������ʷ��Ϣ (Li)-----------
//        double sum = 0;
//        for (const auto &e : DT) {
//            sum += e.second;
//        }
//        sum /= DT.size();
//        for (const auto &e : DT) {
//            double val = e.second;
//            double dis = pow(sum - val, 2);
//            p += 1.0 / (dis + 0.01);
//            gt += 1.0 / (dis + 0.01) * val;
//        }
//        int len = DT.size();
//        Point data[len];
//        int i = 0;
//        for (const auto &e : DT) {
//            data[i].label = -1;
//            // i��k����ֵ��k��j����ֵ
//            data[i].x = new double[] { e1.second, GTV[stage - 1][k].GT };
//            i++;
//        }
//        int n = sizeof(data) / sizeof(data[0]);
//        int K = 2;
//        kmeans(data, n, K);
//        // ѡ���һά��ֵ���ľ���
//        double p1 = 0, p2 = 0;
//        for (i = 0; i < len; i++) {
//            if (data[i].label == 0) {
//                p1 += data[i].x[0];
//            } else {
//                p2 += data[i].x[0];
//            }
//        }
//        int label = 0;
//        if (p1 < p2) {
//            label = 1;
//        }
//        for (i = 0; i < len; i++) {
//            if (data[i].label == label) {
//                p += data[i].x[0];
//                gt += data[i].x[0] * data[i].x[1];
//            }
//        }
        // ----------
        if (p == 0) {
            EV_WARN << "GT w sum = 0!" << endl;
            gt = initGT;
            p = 1;
        }
        gt /= p;
        GTV[stage][veh].GT = GTV[stage - 1][veh].GT * w + gt * (1 - w);
        // lazy
//        if ((veh == 37 || veh == 38) && stage >= 19) {
//            double rand = uniform(0.93, 0.98);
//            GTV[stage][veh].GT *= rand;
//        }
    }
}

// ����ȫ�ֲ���
void MyVeinsAppRSU::updateGP(int stage) {
    EV << "update GP " << std::endl;
// coop
    int max = 0;
    for (const auto &veh : allVehs) {
        if (max < interactionNum[veh]) {
            max = interactionNum[veh];
        }
    }
    for (const auto &veh : allVehs) {
        double coop = 2
                / (1 + pow(exp(2 / max), interactionNum[veh] - max / 3));
        if (coop > 0) {
            GTV[stage][veh].GP += coop;
        } else {
            GTV[stage][veh].GP *= coop + 1;
        }

    }
// degradation
}

// ���º�����,��������
void MyVeinsAppRSU::updateBL(int stage) {
    EV << "update BL " << std::endl;
    double gp = 0.8, gt = 0.5, dr = 1; // default value ???
    double degree = 1; // ʹ��1����׼����Ϊ�ж��쳣����ֵ
    std::map<int, double> T;
    for (const auto &veh : allVehs) {
        if (GTV[stage][veh].GP != 0) {
            gp = 2 - 2 / (GTV[stage][veh].GP + 1);
        }
        if (GTV[stage][veh].GT != 0) {
            gt = GTV[stage][veh].GT;
        }
        if (GTV[stage][veh].DR != 0) {
            dr = GTV[stage][veh].DR;
        }
        // TODO ����DR�ˣ����ĸ�һ�£�GP�ӻ���GT���㹫ʽ�ӣ����Ȳ����ˣ���Ϊֻڮ����ʵ������⳵����DR�Ѿ�������Ӱ���ˣ�����
//        T[veh] = gt * gp; // * dr;
        T[veh] = gt;
    }

//    std::vector<std::pair<int, double>> sortedPairs(T.begin(), T.end());
//    // ��ֵ�� pair ��������
//    std::sort(sortedPairs.begin(), sortedPairs.end(),
//            [](const std::pair<int, double> &a,
//                    const std::pair<int, double> &b) {
//                return a.second < b.second;
//            });
//    // ����ֵ��С�� 1/6 �� key;����ѡ��
//    double threshold = sortedPairs[sortedPairs.size() / 6].second;

    //    std::vector<double> scaled_vals;
    //    std::sort(vals.begin(), vals.end());

    double mean = 0.0, variance = 0.0, stddev = 0.0;
    for (const auto &entry : T) {  // ���� map �ļ�ֵ��
        mean += entry.second;  // entry.second �� T ��ֵ
    }
    mean /= T.size();
    for (const auto &entry : T) {
        double val = entry.second;
        variance += pow(val - mean, 2);
    }
    variance /= T.size();
    stddev = sqrt(variance);
    for (const auto &entry : T) {
        double val = entry.second;
        // std::cout << "test " << val << " " << mean << " " << stddev << std::endl;
        if (std::abs(val - mean) > degree * stddev + 0.01 && val < mean) {
            malVehs.insert(entry.first);
        }
    }
// TODO �ķ�λ�ࣨIQR��,��ʱ����
//    std::vector<double> sorted;
//    for (const auto &entry : T) {
//        sorted.push_back(entry.second);
//    }
//    std::sort(sorted.begin(), sorted.end());
// ���յ�ǰ����ϵ�ĳ����㣻���ǰ���100�����㣬�����еĳ���û������
    int TP = 0, TN = 0, FP = 0, FN = 0;
    simtime_t t = simTime();
//    int intPart = (int) simTime().dbl();
    int k = simTime().dbl() / 1.5;
    if (k > 100) {
        k = 100;
    }
    //    for (int veh : allVehs) {
    for (int veh = 0; veh < k; veh++) {
        // Ŀǰ����ڮ�ٳ�����ֻ�������Ϣ����
        if (veh % malAper == 0) {
//                || veh % 17 == 0
//                        && (t >= 100 && t <= 150 || t >= 200 && t <= 250)) {
            // ���⳵����Ԥ��Ϊ��������
            if (malVehs.find(veh) == malVehs.end()) {
                FN++;
            } else {
                TP++;
            }
        } else {
            if (malVehs.find(veh) == malVehs.end()) {
                TN++;
            } else {
                FP++;
            }
        }
    }
    double ac = 0, tp = 0, fp = 0, tn = 0, fn = 0;
    EV << "AC params in stage " << stage << ": TP,FP,TN,FN: " << TP << " " << FP
              << " " << TN << " " << FN << endl;
    if (TP + TN + FP + FN != 0) {
//        ac = (double) (TP + TN) / (TP + TN + FP + FN);
    }
    if (TP + FN != 0) {
        tp = (double) (TP) / (TP + FN);
    }
    if (TN + FP != 0) {
        // �����ԣ�Specificity������������ʶ���ʣ����������
        tn = (double) (TN) / (TN + FP);
    }

    if (outputFileR.is_open()) {
        simtime_t t = simTime();
        outputFileR << t.str() << "," << tp << "," << tn << "," << TP << ","
                << FP << "," << TN << "," << FN << "\n";
        outputFileR.flush();
    }
//    if (!allVehs.empty()) {
//        detectionRate[stage] = static_cast<double>(TP + TN) / allVehs.size();
//    } else {
//        detectionRate[stage] = 0.0;  // ����Ϊ��Чֵ
//    }
}
