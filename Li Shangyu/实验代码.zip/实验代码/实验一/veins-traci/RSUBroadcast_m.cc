//
// Generated file, do not edit! Created by nedtool 5.6 from veins/modules/application/traci/RSUBroadcast.msg.
//

// Disable warnings about unused variables, empty switch stmts, etc:
#ifdef _MSC_VER
#  pragma warning(disable:4101)
#  pragma warning(disable:4065)
#endif

#if defined(__clang__)
#  pragma clang diagnostic ignored "-Wshadow"
#  pragma clang diagnostic ignored "-Wconversion"
#  pragma clang diagnostic ignored "-Wunused-parameter"
#  pragma clang diagnostic ignored "-Wc++98-compat"
#  pragma clang diagnostic ignored "-Wunreachable-code-break"
#  pragma clang diagnostic ignored "-Wold-style-cast"
#elif defined(__GNUC__)
#  pragma GCC diagnostic ignored "-Wshadow"
#  pragma GCC diagnostic ignored "-Wconversion"
#  pragma GCC diagnostic ignored "-Wunused-parameter"
#  pragma GCC diagnostic ignored "-Wold-style-cast"
#  pragma GCC diagnostic ignored "-Wsuggest-attribute=noreturn"
#  pragma GCC diagnostic ignored "-Wfloat-conversion"
#endif

#include <iostream>
#include <sstream>
#include <memory>
#include "RSUBroadcast_m.h"

namespace omnetpp {

// Template pack/unpack rules. They are declared *after* a1l type-specific pack functions for multiple reasons.
// They are in the omnetpp namespace, to allow them to be found by argument-dependent lookup via the cCommBuffer argument

// Packing/unpacking an std::vector
template<typename T, typename A>
void doParsimPacking(omnetpp::cCommBuffer *buffer, const std::vector<T,A>& v)
{
    int n = v.size();
    doParsimPacking(buffer, n);
    for (int i = 0; i < n; i++)
        doParsimPacking(buffer, v[i]);
}

template<typename T, typename A>
void doParsimUnpacking(omnetpp::cCommBuffer *buffer, std::vector<T,A>& v)
{
    int n;
    doParsimUnpacking(buffer, n);
    v.resize(n);
    for (int i = 0; i < n; i++)
        doParsimUnpacking(buffer, v[i]);
}

// Packing/unpacking an std::list
template<typename T, typename A>
void doParsimPacking(omnetpp::cCommBuffer *buffer, const std::list<T,A>& l)
{
    doParsimPacking(buffer, (int)l.size());
    for (typename std::list<T,A>::const_iterator it = l.begin(); it != l.end(); ++it)
        doParsimPacking(buffer, (T&)*it);
}

template<typename T, typename A>
void doParsimUnpacking(omnetpp::cCommBuffer *buffer, std::list<T,A>& l)
{
    int n;
    doParsimUnpacking(buffer, n);
    for (int i = 0; i < n; i++) {
        l.push_back(T());
        doParsimUnpacking(buffer, l.back());
    }
}

// Packing/unpacking an std::set
template<typename T, typename Tr, typename A>
void doParsimPacking(omnetpp::cCommBuffer *buffer, const std::set<T,Tr,A>& s)
{
    doParsimPacking(buffer, (int)s.size());
    for (typename std::set<T,Tr,A>::const_iterator it = s.begin(); it != s.end(); ++it)
        doParsimPacking(buffer, *it);
}

template<typename T, typename Tr, typename A>
void doParsimUnpacking(omnetpp::cCommBuffer *buffer, std::set<T,Tr,A>& s)
{
    int n;
    doParsimUnpacking(buffer, n);
    for (int i = 0; i < n; i++) {
        T x;
        doParsimUnpacking(buffer, x);
        s.insert(x);
    }
}

// Packing/unpacking an std::map
template<typename K, typename V, typename Tr, typename A>
void doParsimPacking(omnetpp::cCommBuffer *buffer, const std::map<K,V,Tr,A>& m)
{
    doParsimPacking(buffer, (int)m.size());
    for (typename std::map<K,V,Tr,A>::const_iterator it = m.begin(); it != m.end(); ++it) {
        doParsimPacking(buffer, it->first);
        doParsimPacking(buffer, it->second);
    }
}

template<typename K, typename V, typename Tr, typename A>
void doParsimUnpacking(omnetpp::cCommBuffer *buffer, std::map<K,V,Tr,A>& m)
{
    int n;
    doParsimUnpacking(buffer, n);
    for (int i = 0; i < n; i++) {
        K k; V v;
        doParsimUnpacking(buffer, k);
        doParsimUnpacking(buffer, v);
        m[k] = v;
    }
}

// Default pack/unpack function for arrays
template<typename T>
void doParsimArrayPacking(omnetpp::cCommBuffer *b, const T *t, int n)
{
    for (int i = 0; i < n; i++)
        doParsimPacking(b, t[i]);
}

template<typename T>
void doParsimArrayUnpacking(omnetpp::cCommBuffer *b, T *t, int n)
{
    for (int i = 0; i < n; i++)
        doParsimUnpacking(b, t[i]);
}

// Default rule to prevent compiler from choosing base class' doParsimPacking() function
template<typename T>
void doParsimPacking(omnetpp::cCommBuffer *, const T& t)
{
    throw omnetpp::cRuntimeError("Parsim error: No doParsimPacking() function for type %s", omnetpp::opp_typename(typeid(t)));
}

template<typename T>
void doParsimUnpacking(omnetpp::cCommBuffer *, T& t)
{
    throw omnetpp::cRuntimeError("Parsim error: No doParsimUnpacking() function for type %s", omnetpp::opp_typename(typeid(t)));
}

}  // namespace omnetpp

namespace {
template <class T> inline
typename std::enable_if<std::is_polymorphic<T>::value && std::is_base_of<omnetpp::cObject,T>::value, void *>::type
toVoidPtr(T* t)
{
    return (void *)(static_cast<const omnetpp::cObject *>(t));
}

template <class T> inline
typename std::enable_if<std::is_polymorphic<T>::value && !std::is_base_of<omnetpp::cObject,T>::value, void *>::type
toVoidPtr(T* t)
{
    return (void *)dynamic_cast<const void *>(t);
}

template <class T> inline
typename std::enable_if<!std::is_polymorphic<T>::value, void *>::type
toVoidPtr(T* t)
{
    return (void *)static_cast<const void *>(t);
}

}

namespace veins {

// forward
template<typename T, typename A>
std::ostream& operator<<(std::ostream& out, const std::vector<T,A>& vec);

// Template rule to generate operator<< for shared_ptr<T>
template<typename T>
inline std::ostream& operator<<(std::ostream& out,const std::shared_ptr<T>& t) { return out << t.get(); }

// Template rule which fires if a struct or class doesn't have operator<<
template<typename T>
inline std::ostream& operator<<(std::ostream& out,const T&) {return out;}

// operator<< for std::vector<T>
template<typename T, typename A>
inline std::ostream& operator<<(std::ostream& out, const std::vector<T,A>& vec)
{
    out.put('{');
    for(typename std::vector<T,A>::const_iterator it = vec.begin(); it != vec.end(); ++it)
    {
        if (it != vec.begin()) {
            out.put(','); out.put(' ');
        }
        out << *it;
    }
    out.put('}');

    char buf[32];
    sprintf(buf, " (size=%u)", (unsigned int)vec.size());
    out.write(buf, strlen(buf));
    return out;
}

TrustData::TrustData()
{
    this->vehicleId = 0;
    this->DR = 0;
    this->GT = 0;
    this->GP = 0;
}

void __doPacking(omnetpp::cCommBuffer *b, const TrustData& a)
{
    doParsimPacking(b,a.vehicleId);
    doParsimPacking(b,a.DR);
    doParsimPacking(b,a.GT);
    doParsimPacking(b,a.GP);
}

void __doUnpacking(omnetpp::cCommBuffer *b, TrustData& a)
{
    doParsimUnpacking(b,a.vehicleId);
    doParsimUnpacking(b,a.DR);
    doParsimUnpacking(b,a.GT);
    doParsimUnpacking(b,a.GP);
}

class TrustDataDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertynames;
    enum FieldConstants {
        FIELD_vehicleId,
        FIELD_DR,
        FIELD_GT,
        FIELD_GP,
    };
  public:
    TrustDataDescriptor();
    virtual ~TrustDataDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyname) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyname) const override;
    virtual int getFieldArraySize(void *object, int field) const override;

    virtual const char *getFieldDynamicTypeString(void *object, int field, int i) const override;
    virtual std::string getFieldValueAsString(void *object, int field, int i) const override;
    virtual bool setFieldValueAsString(void *object, int field, int i, const char *value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual void *getFieldStructValuePointer(void *object, int field, int i) const override;
};

Register_ClassDescriptor(TrustDataDescriptor)

TrustDataDescriptor::TrustDataDescriptor() : omnetpp::cClassDescriptor(omnetpp::opp_typename(typeid(veins::TrustData)), "")
{
    propertynames = nullptr;
}

TrustDataDescriptor::~TrustDataDescriptor()
{
    delete[] propertynames;
}

bool TrustDataDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<TrustData *>(obj)!=nullptr;
}

const char **TrustDataDescriptor::getPropertyNames() const
{
    if (!propertynames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
        const char **basenames = basedesc ? basedesc->getPropertyNames() : nullptr;
        propertynames = mergeLists(basenames, names);
    }
    return propertynames;
}

const char *TrustDataDescriptor::getProperty(const char *propertyname) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : nullptr;
}

int TrustDataDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 4+basedesc->getFieldCount() : 4;
}

unsigned int TrustDataDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldTypeFlags(field);
        field -= basedesc->getFieldCount();
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,    // FIELD_vehicleId
        FD_ISEDITABLE,    // FIELD_DR
        FD_ISEDITABLE,    // FIELD_GT
        FD_ISEDITABLE,    // FIELD_GP
    };
    return (field >= 0 && field < 4) ? fieldTypeFlags[field] : 0;
}

const char *TrustDataDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldName(field);
        field -= basedesc->getFieldCount();
    }
    static const char *fieldNames[] = {
        "vehicleId",
        "DR",
        "GT",
        "GP",
    };
    return (field >= 0 && field < 4) ? fieldNames[field] : nullptr;
}

int TrustDataDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount() : 0;
    if (fieldName[0] == 'v' && strcmp(fieldName, "vehicleId") == 0) return base+0;
    if (fieldName[0] == 'D' && strcmp(fieldName, "DR") == 0) return base+1;
    if (fieldName[0] == 'G' && strcmp(fieldName, "GT") == 0) return base+2;
    if (fieldName[0] == 'G' && strcmp(fieldName, "GP") == 0) return base+3;
    return basedesc ? basedesc->findField(fieldName) : -1;
}

const char *TrustDataDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldTypeString(field);
        field -= basedesc->getFieldCount();
    }
    static const char *fieldTypeStrings[] = {
        "int",    // FIELD_vehicleId
        "double",    // FIELD_DR
        "double",    // FIELD_GT
        "double",    // FIELD_GP
    };
    return (field >= 0 && field < 4) ? fieldTypeStrings[field] : nullptr;
}

const char **TrustDataDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldPropertyNames(field);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

const char *TrustDataDescriptor::getFieldProperty(int field, const char *propertyname) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldProperty(field, propertyname);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

int TrustDataDescriptor::getFieldArraySize(void *object, int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldArraySize(object, field);
        field -= basedesc->getFieldCount();
    }
    TrustData *pp = (TrustData *)object; (void)pp;
    switch (field) {
        default: return 0;
    }
}

const char *TrustDataDescriptor::getFieldDynamicTypeString(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldDynamicTypeString(object,field,i);
        field -= basedesc->getFieldCount();
    }
    TrustData *pp = (TrustData *)object; (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string TrustDataDescriptor::getFieldValueAsString(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldValueAsString(object,field,i);
        field -= basedesc->getFieldCount();
    }
    TrustData *pp = (TrustData *)object; (void)pp;
    switch (field) {
        case FIELD_vehicleId: return long2string(pp->vehicleId);
        case FIELD_DR: return double2string(pp->DR);
        case FIELD_GT: return double2string(pp->GT);
        case FIELD_GP: return double2string(pp->GP);
        default: return "";
    }
}

bool TrustDataDescriptor::setFieldValueAsString(void *object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->setFieldValueAsString(object,field,i,value);
        field -= basedesc->getFieldCount();
    }
    TrustData *pp = (TrustData *)object; (void)pp;
    switch (field) {
        case FIELD_vehicleId: pp->vehicleId = string2long(value); return true;
        case FIELD_DR: pp->DR = string2double(value); return true;
        case FIELD_GT: pp->GT = string2double(value); return true;
        case FIELD_GP: pp->GP = string2double(value); return true;
        default: return false;
    }
}

const char *TrustDataDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldStructName(field);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    };
}

void *TrustDataDescriptor::getFieldStructValuePointer(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldStructValuePointer(object, field, i);
        field -= basedesc->getFieldCount();
    }
    TrustData *pp = (TrustData *)object; (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

Register_Class(RSUBroadcast)

RSUBroadcast::RSUBroadcast(const char *name, short kind) : ::veins::BaseFrame1609_4(name, kind)
{
}

RSUBroadcast::RSUBroadcast(const RSUBroadcast& other) : ::veins::BaseFrame1609_4(other)
{
    copy(other);
}

RSUBroadcast::~RSUBroadcast()
{
    delete [] this->trustData;
    delete [] this->blacklist;
}

RSUBroadcast& RSUBroadcast::operator=(const RSUBroadcast& other)
{
    if (this == &other) return *this;
    ::veins::BaseFrame1609_4::operator=(other);
    copy(other);
    return *this;
}

void RSUBroadcast::copy(const RSUBroadcast& other)
{
    this->reporterAddress = other.reporterAddress;
    this->reporteeAddress = other.reporteeAddress;
    delete [] this->trustData;
    this->trustData = (other.trustData_arraysize==0) ? nullptr : new TrustData[other.trustData_arraysize];
    trustData_arraysize = other.trustData_arraysize;
    for (size_t i = 0; i < trustData_arraysize; i++) {
        this->trustData[i] = other.trustData[i];
    }
    this->stage = other.stage;
    delete [] this->blacklist;
    this->blacklist = (other.blacklist_arraysize==0) ? nullptr : new int[other.blacklist_arraysize];
    blacklist_arraysize = other.blacklist_arraysize;
    for (size_t i = 0; i < blacklist_arraysize; i++) {
        this->blacklist[i] = other.blacklist[i];
    }
}

void RSUBroadcast::parsimPack(omnetpp::cCommBuffer *b) const
{
    ::veins::BaseFrame1609_4::parsimPack(b);
    doParsimPacking(b,this->reporterAddress);
    doParsimPacking(b,this->reporteeAddress);
    b->pack(trustData_arraysize);
    doParsimArrayPacking(b,this->trustData,trustData_arraysize);
    doParsimPacking(b,this->stage);
    b->pack(blacklist_arraysize);
    doParsimArrayPacking(b,this->blacklist,blacklist_arraysize);
}

void RSUBroadcast::parsimUnpack(omnetpp::cCommBuffer *b)
{
    ::veins::BaseFrame1609_4::parsimUnpack(b);
    doParsimUnpacking(b,this->reporterAddress);
    doParsimUnpacking(b,this->reporteeAddress);
    delete [] this->trustData;
    b->unpack(trustData_arraysize);
    if (trustData_arraysize == 0) {
        this->trustData = nullptr;
    } else {
        this->trustData = new TrustData[trustData_arraysize];
        doParsimArrayUnpacking(b,this->trustData,trustData_arraysize);
    }
    doParsimUnpacking(b,this->stage);
    delete [] this->blacklist;
    b->unpack(blacklist_arraysize);
    if (blacklist_arraysize == 0) {
        this->blacklist = nullptr;
    } else {
        this->blacklist = new int[blacklist_arraysize];
        doParsimArrayUnpacking(b,this->blacklist,blacklist_arraysize);
    }
}

const LAddress::L2Type& RSUBroadcast::getReporterAddress() const
{
    return this->reporterAddress;
}

void RSUBroadcast::setReporterAddress(const LAddress::L2Type& reporterAddress)
{
    this->reporterAddress = reporterAddress;
}

const LAddress::L2Type& RSUBroadcast::getReporteeAddress() const
{
    return this->reporteeAddress;
}

void RSUBroadcast::setReporteeAddress(const LAddress::L2Type& reporteeAddress)
{
    this->reporteeAddress = reporteeAddress;
}

size_t RSUBroadcast::getTrustDataArraySize() const
{
    return trustData_arraysize;
}

const TrustData& RSUBroadcast::getTrustData(size_t k) const
{
    if (k >= trustData_arraysize) throw omnetpp::cRuntimeError("Array of size trustData_arraysize indexed by %lu", (unsigned long)k);
    return this->trustData[k];
}

void RSUBroadcast::setTrustDataArraySize(size_t newSize)
{
    TrustData *trustData2 = (newSize==0) ? nullptr : new TrustData[newSize];
    size_t minSize = trustData_arraysize < newSize ? trustData_arraysize : newSize;
    for (size_t i = 0; i < minSize; i++)
        trustData2[i] = this->trustData[i];
    delete [] this->trustData;
    this->trustData = trustData2;
    trustData_arraysize = newSize;
}

void RSUBroadcast::setTrustData(size_t k, const TrustData& trustData)
{
    if (k >= trustData_arraysize) throw omnetpp::cRuntimeError("Array of size  indexed by %lu", (unsigned long)k);
    this->trustData[k] = trustData;
}

void RSUBroadcast::insertTrustData(size_t k, const TrustData& trustData)
{
    if (k > trustData_arraysize) throw omnetpp::cRuntimeError("Array of size  indexed by %lu", (unsigned long)k);
    size_t newSize = trustData_arraysize + 1;
    TrustData *trustData2 = new TrustData[newSize];
    size_t i;
    for (i = 0; i < k; i++)
        trustData2[i] = this->trustData[i];
    trustData2[k] = trustData;
    for (i = k + 1; i < newSize; i++)
        trustData2[i] = this->trustData[i-1];
    delete [] this->trustData;
    this->trustData = trustData2;
    trustData_arraysize = newSize;
}

void RSUBroadcast::insertTrustData(const TrustData& trustData)
{
    insertTrustData(trustData_arraysize, trustData);
}

void RSUBroadcast::eraseTrustData(size_t k)
{
    if (k >= trustData_arraysize) throw omnetpp::cRuntimeError("Array of size  indexed by %lu", (unsigned long)k);
    size_t newSize = trustData_arraysize - 1;
    TrustData *trustData2 = (newSize == 0) ? nullptr : new TrustData[newSize];
    size_t i;
    for (i = 0; i < k; i++)
        trustData2[i] = this->trustData[i];
    for (i = k; i < newSize; i++)
        trustData2[i] = this->trustData[i+1];
    delete [] this->trustData;
    this->trustData = trustData2;
    trustData_arraysize = newSize;
}

int RSUBroadcast::getStage() const
{
    return this->stage;
}

void RSUBroadcast::setStage(int stage)
{
    this->stage = stage;
}

size_t RSUBroadcast::getBlacklistArraySize() const
{
    return blacklist_arraysize;
}

int RSUBroadcast::getBlacklist(size_t k) const
{
    if (k >= blacklist_arraysize) throw omnetpp::cRuntimeError("Array of size blacklist_arraysize indexed by %lu", (unsigned long)k);
    return this->blacklist[k];
}

void RSUBroadcast::setBlacklistArraySize(size_t newSize)
{
    int *blacklist2 = (newSize==0) ? nullptr : new int[newSize];
    size_t minSize = blacklist_arraysize < newSize ? blacklist_arraysize : newSize;
    for (size_t i = 0; i < minSize; i++)
        blacklist2[i] = this->blacklist[i];
    for (size_t i = minSize; i < newSize; i++)
        blacklist2[i] = 0;
    delete [] this->blacklist;
    this->blacklist = blacklist2;
    blacklist_arraysize = newSize;
}

void RSUBroadcast::setBlacklist(size_t k, int blacklist)
{
    if (k >= blacklist_arraysize) throw omnetpp::cRuntimeError("Array of size  indexed by %lu", (unsigned long)k);
    this->blacklist[k] = blacklist;
}

void RSUBroadcast::insertBlacklist(size_t k, int blacklist)
{
    if (k > blacklist_arraysize) throw omnetpp::cRuntimeError("Array of size  indexed by %lu", (unsigned long)k);
    size_t newSize = blacklist_arraysize + 1;
    int *blacklist2 = new int[newSize];
    size_t i;
    for (i = 0; i < k; i++)
        blacklist2[i] = this->blacklist[i];
    blacklist2[k] = blacklist;
    for (i = k + 1; i < newSize; i++)
        blacklist2[i] = this->blacklist[i-1];
    delete [] this->blacklist;
    this->blacklist = blacklist2;
    blacklist_arraysize = newSize;
}

void RSUBroadcast::insertBlacklist(int blacklist)
{
    insertBlacklist(blacklist_arraysize, blacklist);
}

void RSUBroadcast::eraseBlacklist(size_t k)
{
    if (k >= blacklist_arraysize) throw omnetpp::cRuntimeError("Array of size  indexed by %lu", (unsigned long)k);
    size_t newSize = blacklist_arraysize - 1;
    int *blacklist2 = (newSize == 0) ? nullptr : new int[newSize];
    size_t i;
    for (i = 0; i < k; i++)
        blacklist2[i] = this->blacklist[i];
    for (i = k; i < newSize; i++)
        blacklist2[i] = this->blacklist[i+1];
    delete [] this->blacklist;
    this->blacklist = blacklist2;
    blacklist_arraysize = newSize;
}

class RSUBroadcastDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertynames;
    enum FieldConstants {
        FIELD_reporterAddress,
        FIELD_reporteeAddress,
        FIELD_trustData,
        FIELD_stage,
        FIELD_blacklist,
    };
  public:
    RSUBroadcastDescriptor();
    virtual ~RSUBroadcastDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyname) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyname) const override;
    virtual int getFieldArraySize(void *object, int field) const override;

    virtual const char *getFieldDynamicTypeString(void *object, int field, int i) const override;
    virtual std::string getFieldValueAsString(void *object, int field, int i) const override;
    virtual bool setFieldValueAsString(void *object, int field, int i, const char *value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual void *getFieldStructValuePointer(void *object, int field, int i) const override;
};

Register_ClassDescriptor(RSUBroadcastDescriptor)

RSUBroadcastDescriptor::RSUBroadcastDescriptor() : omnetpp::cClassDescriptor(omnetpp::opp_typename(typeid(veins::RSUBroadcast)), "veins::BaseFrame1609_4")
{
    propertynames = nullptr;
}

RSUBroadcastDescriptor::~RSUBroadcastDescriptor()
{
    delete[] propertynames;
}

bool RSUBroadcastDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<RSUBroadcast *>(obj)!=nullptr;
}

const char **RSUBroadcastDescriptor::getPropertyNames() const
{
    if (!propertynames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
        const char **basenames = basedesc ? basedesc->getPropertyNames() : nullptr;
        propertynames = mergeLists(basenames, names);
    }
    return propertynames;
}

const char *RSUBroadcastDescriptor::getProperty(const char *propertyname) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : nullptr;
}

int RSUBroadcastDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 5+basedesc->getFieldCount() : 5;
}

unsigned int RSUBroadcastDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldTypeFlags(field);
        field -= basedesc->getFieldCount();
    }
    static unsigned int fieldTypeFlags[] = {
        0,    // FIELD_reporterAddress
        0,    // FIELD_reporteeAddress
        FD_ISARRAY | FD_ISCOMPOUND,    // FIELD_trustData
        FD_ISEDITABLE,    // FIELD_stage
        FD_ISARRAY | FD_ISEDITABLE,    // FIELD_blacklist
    };
    return (field >= 0 && field < 5) ? fieldTypeFlags[field] : 0;
}

const char *RSUBroadcastDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldName(field);
        field -= basedesc->getFieldCount();
    }
    static const char *fieldNames[] = {
        "reporterAddress",
        "reporteeAddress",
        "trustData",
        "stage",
        "blacklist",
    };
    return (field >= 0 && field < 5) ? fieldNames[field] : nullptr;
}

int RSUBroadcastDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount() : 0;
    if (fieldName[0] == 'r' && strcmp(fieldName, "reporterAddress") == 0) return base+0;
    if (fieldName[0] == 'r' && strcmp(fieldName, "reporteeAddress") == 0) return base+1;
    if (fieldName[0] == 't' && strcmp(fieldName, "trustData") == 0) return base+2;
    if (fieldName[0] == 's' && strcmp(fieldName, "stage") == 0) return base+3;
    if (fieldName[0] == 'b' && strcmp(fieldName, "blacklist") == 0) return base+4;
    return basedesc ? basedesc->findField(fieldName) : -1;
}

const char *RSUBroadcastDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldTypeString(field);
        field -= basedesc->getFieldCount();
    }
    static const char *fieldTypeStrings[] = {
        "veins::LAddress::L2Type",    // FIELD_reporterAddress
        "veins::LAddress::L2Type",    // FIELD_reporteeAddress
        "veins::TrustData",    // FIELD_trustData
        "int",    // FIELD_stage
        "int",    // FIELD_blacklist
    };
    return (field >= 0 && field < 5) ? fieldTypeStrings[field] : nullptr;
}

const char **RSUBroadcastDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldPropertyNames(field);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

const char *RSUBroadcastDescriptor::getFieldProperty(int field, const char *propertyname) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldProperty(field, propertyname);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

int RSUBroadcastDescriptor::getFieldArraySize(void *object, int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldArraySize(object, field);
        field -= basedesc->getFieldCount();
    }
    RSUBroadcast *pp = (RSUBroadcast *)object; (void)pp;
    switch (field) {
        case FIELD_trustData: return pp->getTrustDataArraySize();
        case FIELD_blacklist: return pp->getBlacklistArraySize();
        default: return 0;
    }
}

const char *RSUBroadcastDescriptor::getFieldDynamicTypeString(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldDynamicTypeString(object,field,i);
        field -= basedesc->getFieldCount();
    }
    RSUBroadcast *pp = (RSUBroadcast *)object; (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string RSUBroadcastDescriptor::getFieldValueAsString(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldValueAsString(object,field,i);
        field -= basedesc->getFieldCount();
    }
    RSUBroadcast *pp = (RSUBroadcast *)object; (void)pp;
    switch (field) {
        case FIELD_reporterAddress: {std::stringstream out; out << pp->getReporterAddress(); return out.str();}
        case FIELD_reporteeAddress: {std::stringstream out; out << pp->getReporteeAddress(); return out.str();}
        case FIELD_trustData: {std::stringstream out; out << pp->getTrustData(i); return out.str();}
        case FIELD_stage: return long2string(pp->getStage());
        case FIELD_blacklist: return long2string(pp->getBlacklist(i));
        default: return "";
    }
}

bool RSUBroadcastDescriptor::setFieldValueAsString(void *object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->setFieldValueAsString(object,field,i,value);
        field -= basedesc->getFieldCount();
    }
    RSUBroadcast *pp = (RSUBroadcast *)object; (void)pp;
    switch (field) {
        case FIELD_stage: pp->setStage(string2long(value)); return true;
        case FIELD_blacklist: pp->setBlacklist(i,string2long(value)); return true;
        default: return false;
    }
}

const char *RSUBroadcastDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldStructName(field);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        case FIELD_trustData: return omnetpp::opp_typename(typeid(TrustData));
        default: return nullptr;
    };
}

void *RSUBroadcastDescriptor::getFieldStructValuePointer(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldStructValuePointer(object, field, i);
        field -= basedesc->getFieldCount();
    }
    RSUBroadcast *pp = (RSUBroadcast *)object; (void)pp;
    switch (field) {
        case FIELD_reporterAddress: return toVoidPtr(&pp->getReporterAddress()); break;
        case FIELD_reporteeAddress: return toVoidPtr(&pp->getReporteeAddress()); break;
        case FIELD_trustData: return toVoidPtr(&pp->getTrustData(i)); break;
        default: return nullptr;
    }
}

} // namespace veins

