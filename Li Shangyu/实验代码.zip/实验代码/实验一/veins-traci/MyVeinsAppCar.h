#pragma once

#include "veins/modules/application/ieee80211p/DemoBaseApplLayer.h"
#include "veins/modules/application/traci/common.h"
#include "veins/modules/application/traci/RSUBroadcast_m.h"
//#include <stdlib.h>

namespace veins {

/**
 * @brief
 * A tutorial demo for TraCI. When the car is stopped for longer than 10 seconds
 * it will send a message out to other cars containing the blocked road id.
 * Receiving cars will then trigger a reroute via TraCI.
 * When channel switching between SCH and CCH is enabled on the MAC, the message is
 * instead send out on a service channel following a Service Advertisement
 * on the CCH.
 *
 * @author Christoph Sommer : initial DemoApp
 * @author David Eckhoff : rewriting, moving functionality to DemoBaseApplLayer, adding WSA
 *
 */

class VEINS_API MyVeinsAppCar: public DemoBaseApplLayer {
public:
    void initialize(int stage) override;
    void finish() override;
protected:
    simtime_t messageInterval;
    simtime_t satMessageInterval;
    simtime_t variance;
    cMessage *sendDTMsgEvt;
    cMessage *sendMsgEvt;
    LAddress::L2Type RSUAddr;

//    int reportedMsgId;
//    int recMsg;
//    int recRprt;
//    int sentRprt;
//    int sent;
//    std::map<int, std::map<int, bool>> myReports;
//    bool sentMessage;
//    int currentSubscribedServiceId;

    void sendSatToNearbyVehicles(); // ģ�ⷢ��·����Ϣ����һ����
    void sendDTToNearbyVehicles(); // ����DT

    void onWSM(BaseFrame1609_4 *wsm) override;
//    void onWSA(DemoServiceAdvertisment *wsa) override;

    void handleSelfMsg(cMessage *msg) override;
//    void initVehicle(int id, bool dontRequestDump = false);
    void handlePositionUpdate(cObject *obj) override;

    void calRT(int stage);
    void calLT(int stage);
    void writeInFile();

    // ÿmalAper������ѡһ��
    // A:20\10\7\5\4\3\2
    int malAper = 5;
    int malBper = 11;
    int nodeId;
    bool isMal;
    int myStage;
    int rsuStage;
    double RANGE = 500;
    std::set<int> allVehs;
    std::set<int> BL; // ������
    std::map<int, double> DT; // �����ڣ��ɽ����õ�������ȸ���DT
    std::map<int, double> malDT; // �����۰��DT������ڮ�ٹ���
    std::map<int, std::map<int, double>> allDT; // �յ�������DT����������RT���洢����A...: ��������������DT
    std::map<int, double> RT;  // ����-RT
    std::map<int, std::map<int, double>> LT;
    std::map<int, std::map<int, TrustData>> GTV; // global trust view, ����ID��ֵ
};

} // namespace veins
