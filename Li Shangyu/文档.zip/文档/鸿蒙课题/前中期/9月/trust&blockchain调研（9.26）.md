## 调研（9.28）

### 会议记录

mpc 恶意用户攻击获取模型参数；FPGA加速卡、PSI\PIR；机密计算confidential compute（硬件），云上保证多参与方数据代码安全。密码分析、攻击



### 1. 相关论文

#### Blockchain Meets Edge Computing: A Distributed and Trusted Authentication System

*IEEE T RANSACTIONS ON INDUSTRIAL INFORMATICS, VOL. 16, NO. 3, MARCH 2020*

#### 简介

文章关注不同平台之间的有效身份验证和协作共享。

该系统由物理网络层、区块链边缘层和区块链网络层组成。区块链网络层作为底层支持层，使用优化的实用拜占庭容错（PBFT）共识算法存储认证数据和日志。

两种边缘节点：其中解析边缘节点提供名称解析服务，缓存节点实现边缘认证服务。

为了保证边缘安全，设计了一种基于椭圆曲线密码学（ECC）的密码学。特别提出了一种基于边缘计算的缓存策略来更新区块链边缘节点的缓存，提高命中率。

**主要贡献：**

1）本文提出了一个结合区块链和边缘计算的**分布式可信认证系统**。在区块链网络中，设计了一种优化的 PBFT 共识算法来存储认证数据和日志。它保证了可信认证并实现了终端的活动可追溯性。

2）利用动态名称解析策略和ECC设计**分布式认证机制**。通过名称解析策略，边缘节点可以及时同步终端数据。同时，密码学可以保护边缘节点和终端之间的身份保密和通信安全。

3）提出了一种基于置信传播（BP）算法的**缓存策略**，以提高命中率和最小化延迟。与无法应对移动终端的传统缓存策略相比，依赖智能合约的策略可以动态优化缓存空间的分配。

#### 系统模型

<img src="D:\Onedrive\md文件-研究生阶段\pic\image-20220928164320044.png" alt="image-20220928164320044" style="zoom:50%;" />

* physical network layer：移动或固定的终端，收集数据并传输到其他层。
* blockchain edge layer：cache nodes B<sub>c</sub> and resolution nodes B<sub>r</sub> ，解析节点解析域名、验证交易、提交区块；缓存节点缓存终端所需的内容。
* blockchain network layer：存储终端信息，通过Hyperledger Fabric创建智能合约。

**共识算法  optimized PBFT algorithm：**

> 共识算法的执行是为了存储认证数据和日志，以支持数据的可追溯性和促进认证效率。
>
> 共N个对等节点，每一轮选一个speaker N<sub>x</sub>，x=（h mod N）+1(h是当前区块高度)，N<sub>x</sub>可以主持N次共识过程
>
> 边缘节点可以向联盟同伴（alliance peers）广播认证结果
>
> 1. t为生成区块的时间间隔，经过t后**N<sub>x</sub>广播pre_prepare消息**<v, h, d, Sig<sub>x</sub>>，（视图id，高度，消息摘要，摘要的签名）
>
> 2. N<sub>i</sub>验证消息和签名，若为真则**广播prepare消息**<v, h, d, Sig<sub>x</sub>>
>
> 3. 收到超过2f+1个不同的prepare消息后**广播commit消息**<v, h, d, Sig<sub>x</sub>>，f = |(N − 1)/3|
> 4. speaker N<sub>x</sub>收到超过**f+1**个commit消息后，确认共识完成，在分布式账本中生成一个区块，**广播**认证日志，节点**更新**分布式账本。**？？？？？？？**
>

#### 分布式认证机制

* Dynamic Name Resolution Strategy
  *  resolution nodes and cache nodes 都维护一个本地domain name system数据库，包括终端ID、公钥和IP地址。
  * 终端以同一个域名访问边缘节点（传递延迟较低），边缘节点把ip传递给附近的缓存节点。认证通过后可以实现单点登录访问系统资源。
  * 若该终端没有注册，解析节点提交一个区块，获得唯一ID以及相应的公钥。（单向传递给解析节点，然后缓存节点以设定的时间间隔同步ID和缓存在解析节点的账户。**冗余的日志**将被存储在解析节点，以缓解区块链网络的存储压力，提高查询效率**？？？？？？**）

* 基于ECC的非对称加密算法
  * setup: 主公钥PK<sub>BE</sub> = s*P
  * abstract
  * sign
  * verify



#### 缓存策略



#### Trust-Based Blockchain Authorization for IoT

#### 简介

基于属性的去中心化访问控制机制和辅助的信任与信誉系统(TRS)用于物联网授权。（提出了动态的授权方案）

新的信任和信誉系统TRS量化**服务消费者了SC和服务提供者SP**（？设备认证场景是什么）的行为，使用递归简化了信任值的计算。（我们将信任定义为一个节点基于之前与另一个节点的交互而对其行为的主观信念，这可能有助于确定下一次交互的可能性。另一方面，我们将信誉称为来自多个节点的聚合信任关系的节点过去行为的全局视图。）

将节点的信任和信誉量化并整合到访问机制中。

系统在公链，用户隐私存储在私链

**相关引用论文：**

ABAC mechanisms (attribute-based access control): S. Ding, J. Cao, C. Li, K. Fan, and H. Li, “A novel attribute-based access control scheme using blockchain for IoT,” IEEE Access, vol. 7, pp. 38431–8441, 2019. [Online]. Available: https://ieeexplore.ieee.org/document/8668769/；通过记录区块链事务中的属性注册和撤销来提供更细粒度的访问控制。



#### Blockchain-based IoT security authentication system

*2021 International Conference on Computer, Blockchain and Financial Development (CBFD)*, 2021

#### 概述：

本文提出了一种名为iot-chain的物联网安全认证系统，它基于Hyperledger Fabric区块链框架提供了基于属性的安全认证。
系统包含三种链码，即接入码、设备码和策略码：

* 访问码是实现用户安全认证方法的主程序
* 设备代码为存储设备生成的资源数据的URL提供查询方法
* 策略代码为管理员用户提供访问控制策略

iot-chain结合访问控制和区块链技术，提供物联网动态安全认证管理。实验结果表明，iot-chain 在分布式系统中可以保持高吞吐量并有效达成共识。

#### 模型：

本文设计了一个设备与资源的URL映射模型：设备→资源→URL



### 2. 金融领域鸿蒙平台
