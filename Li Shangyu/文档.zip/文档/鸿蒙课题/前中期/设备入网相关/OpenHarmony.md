## OpenHarmony

### 1. hichain

<img src="D:\Onedrive\md文件-研究生阶段\pic\设备认证.png" alt="设备认证" style="zoom:150%;" />

如何通信？

**分布式软总线模块**的主要作用是为设备间提供通信能力。

通过TCP协议实现。调用socket进行通信：

问题：客户端如何获取服务端IP和端口号？

```C
/*
函数参数：callback为回调函数的地址；ip为server端ip地址
函数功能：为启动监听其他设备的连接请求或者新数据响应
*/
int StartListener(BaseListener *callback, const char *ip) 
{
	...
    // 初始化server端套接字（TCP），绑定ip地址及port，动态选取本地可用端口号
    int rc = InitListenFd(ip, SESSIONPORT);  
    
	// 创建子线程进行监听任务，包括设备认证过程中的新连接或者新数据
	register ThreadId threadId = (ThreadId)AuthCreate((Runnable)WaitProcess, &attr);
	// WaitProcess监听listenFd和数据g_dataFd的信息，监听到有数据可读就调用ProcessAuthData来处理数据
	// 如果有设备发起连接，响应listenFd事件，accept建立socket连接，然后调用回调函数onConnectEvent处理连接事件	
	// 如果接收到设备发送的可读数据，响应g_dataFd的事件，调用回调函数onDataEvent处理数据传输事件
	...
}
```

发什么包？

公私钥怎么生成？

回话过程中临时公钥：十六进制格式的字符串：

```
ret = cal_bignum_exp((struct var_buffer *)&base, (struct var_buffer *)&pake_server->self_esk, prime_len, (struct big_num *)self_epk);//再次计算大素数指数作为本端临时公钥self_epk
```

