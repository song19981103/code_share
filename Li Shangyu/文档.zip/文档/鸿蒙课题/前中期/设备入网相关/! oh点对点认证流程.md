## 点对点认证流程

**Test**

```c
//get_instance参数：
static struct session_identity g_serverIdentity = {
    0,//session_id
    {strlen("testServer"), "testServer"},//package_name
    {strlen("testServer"), "testServer"},//service_type
    0//void *context
};
//HC_ACCESSORY这里对应参数hc_type是枚举类型，值为HC_CENTRE或HC_ACCESSORY，表示主控设备和配件设备
//callback中的GetProtocolParams函数给pin、peer_auth_id、self_auth_id赋以下值
static struct hc_pin g_testPin = {strlen("123456789012345"), "123456789012345"};
static struct hc_auth_id g_testClientAuthId = {strlen("authClient"), "authClient"};
static struct hc_auth_id g_testServerAuthId = {strlen("authServer"), "authServer"};

//主流程，配件设备作为server
//服务器创建hichain实例
hc_handle server = get_instance(&g_serverIdentity, HC_ACCESSORY, &callBack);
const struct operation_parameter params = {g_testServerAuthId, g_testClientAuthId, KEY_LEN};
//通过pake协议协商会话秘钥
int32_t ret = start_pake(server, &params);
```

**get_instance:**创建hichain实例，初始化群组身份秘钥

```c
int32_t ret = key_info_init();
hichain->identity = *identity; //g_serverIdentity
hichain->type = type; //HC_ACCESSORY
//INIT_STATE = 0, KEY_AGREEMENT_STATE = 1, OPERATION_STATE, OVER_STATE
hichain->state = INIT_STATE;
hichain->last_state = INIT_STATE;
hichain->cb = *call_back;

//创建自己的long store/term密钥对:
//首先调用回调函数get_protocol_params获取认证会话密钥长度、对端认证id和本端认证id
//HC包名称和服务类型用sha256哈希得到service_id
//service_id+self_auth_id("authServer")+秘钥类型——>秘钥别名alias
//通过秘钥别名判断long term公钥是否存在，若不存在则用ED25519生成公私钥对，参数为alias, self_auth_id
build_self_lt_key_pair(hichain);
```

**start_pake:**身份确认以及协商会话秘钥

```c
//获取hichain实例，即get_instance的返回值（hichain->identity为更新过参数的g_serverIdentity）
struct hichain *hichain = (struct hichain *)handle;
//构建PAKE_MODULAR client子对象（true对应参数名为is_client）
int32_t ret = build_object(hichain, PAKE_MODULAR, true, params);
//触发pake client子对象，发起设备绑定，hc操作码为1，表示BIND（主控设备发起）
ret = triggered_pake_client(hichain, BIND);
```

**1. 客户端（主控设备） pake start** （发送所有A信任的设备的id？）(数据包大小？)

build_pake_client_object初始化hichain->pake_client，*获取pin码、双方认证id等参数*

发送信息发送给服务端，向服务端发起认证会话密钥协商请求：

* 本端的协议版本号
* 是否支持256mod（服务器据此赋值大素数长度）
* operationCode（=1，即BIND）

**2. 服务器 pake start response** （选取共信设备B，获取口令，返回设备B的id）

初始化pake_server，*获取pin码、双方认证id等参数*

发送消息：

* challenge_S，本端的挑战值，随机生成
* salt值：生成的随机值
* epk_S，本端临时公钥：
  * esk_S: 临时私钥，随机生成
  * 派生秘钥secret = hkdf (pin, salt)
  * base = cal_bignum_exp (secret, exp, prime_len); (计算大素数指数，exp=2，即平方)
  * **epk_S = cal_bignum_exp (base, esk_S, prime_len)**
* 自己的版本号

$$
epk={(hkdf(pin, salt)^2\%len)}^{esk}\%len
$$

**3. 客户端 pake end** （获取口令）

解析start response消息：

* 收到challenge_S, salt, epk_S
* secret = hkdf (pin, salt)
* base = cal_bignum_exp (secret, exp, prime_len);
* 随机生成esk_C
* epk_C = cal_bignum_exp (base, esk_C, prime_len)

发送end消息：

* 本端的挑战值：challenge_C，生成的随机值
* 临时公钥epk_C
* kcfData，用于身份认证，涉及到的参数：spk_S, esk_C, salt, len, challenge_C, challenge_S
  * shared_secret = cal_bignum_exp (epk_S, esk_C, prime_len) //计算共享秘钥
  * hkdf = HKDF (shared_secret , salt)
  * session_key_C = hkdf
  * hmac_key_C = hkdf + PAKE_SESSION_KEY_LENGTH
  * proof = HMAC(hmac_key_C, challenge_C, challenge_S)

$$
shared\_secret = (epk_s^{esk_c})\%len=[(base^{esk_s})\%len]^{esk_c}\%len
$$

**4. 服务器 pake end response**

解析pake end request消息：

* 收到kcfData, challenge_C, epk_C
* shared_secret = cal_bignum_exp (epk_C, esk_S, prime_len)
* hkdf = HKDF (shared_secret , salt)
* session_key_S = hkdf  
* hmac_key_S = hkdf + PAKE_SESSION_KEY_LENGTH

$$
shared\_secret = (epk_c^{esk_s})\%len=[(base^{esk_c})\%len]^{esk_s}\%len
$$

消息验证：

* verify_proof = HMAC (hmac_key_S , challenge_C, challenge_S)
* 与客户端发送来的kcfData进行对比

如果验证正确，生成output_key：（基于shared_secret和salt生成）

* **service_key** = hkdf (session_key_S, salt, HICHAIN_RETURN_KEY, key_length)
* session_key = service_key

发送pake end response消息：

* kdfData_S，包含参数epk_C, esk_S, salt, challenge_C, challenge_S
  * proof = HMAC (hmac_key_S, challenge_C, challenge_S) 

**5. 客户端接收消息**

接收pake end response消息：

* 接收kdfData_S

验证消息：

* verify_proof=HMAC(hmac_key, challenge_S, challenge_C)

* 然后与服务端发送来的kdfData_S进行对比

如果验证正确，生成output_key：（即service_key）

* **service_key** = hkdf (session_key_C, salt, HICHAIN_RETURN_KEY, key_length)
* session_key = service_key



> $$
> [(a^{c})\%n]^{b}\%n=(a^c)^b\%n=(a^b)^c\%n=[(a^{b})\%n]^{c}\%n
> $$
>
> 安全性：
>
> **伪造身份**：截获信息：salt、epk_S、epk_C、challenge_S、challenge_C、hmac(……)
>
> 客户端生成proof需要esk_C，敌手没有
>
> 服务器验证客户端，基于共有的pin码（base）和esk_S可以验证对方是有pin码的
>
> 客户端同样可以验证服务器的身份
>
> **会话秘钥**：敌手没有esk，无法生成会话秘钥

### 自动认证

*callback->get_protocol_params修改其中pin码获取的代码，替换为通过协商生成*

场景：同一厂商的设备之间互相信任，设备预置相同的对称秘钥和字符串以及独特的设备ID，发送预置秘钥加密的消息：Enc (str, id, session_key)来协商会话秘钥。……

c0——c1     a1——a2——b3——b2——b1

c0——a2



c0假冒d1向a2获取对于b2的信任凭证

发id给a2，id1和id2建立关系，其他设备发送也ok



敌手——会话秘钥

敌手——伪造身份；没有意义



有共同设备即可

手动帮助a2和b2通过输入pin码进行认证，之后a1和b2、a1和b1、a2和b1自动认证

解决问题：基于多个共信设备自动建立信任关系

a1和b2自动认证过程：

1. a1向所有信任的设备（a2）请求获取向b2认证的凭证：
   * msg_id = PROOF_REQUEST
   * id_a1
   * id_b2
2. 和b2互信的设备（a2）返回加密消息
   * msg_id = PROOF_RESPONSE
   * proof_id，随机数
   * b2_Pk
3. a1向b2请求通过hichain认证，发送的start消息增加发送了信任凭证的设备的id（id_a2）
4. b2获取start消息后和(a2)协商回话秘钥session_key，然后发送加密的消息（是否必要）
   * msg_id = PROOF_GET
   * id_b2
   * id_a1
5. a2向b2返回加密消息
   * msg_id = PROOF_SEND
   * proof_id
6. b2收到超过所有信任设备一半的proof消息后向a1发送start response
7. a1向b2发送end消息，消息内容用到pin码的用hmac(b2_Pk,…, proof_id)替换
8. b2向a1发送end response
9. a1接收该消息



### 下周计划

这周末在把这个方案写详细，考虑和信任值等结合一下

下周开始写专利初稿





问题：

1. 首先是调用回调函数**get_protocol_params**获取协议参数，此函数的实现位于分布式软总线模块的auth_interface.c文件中，函数名为**AuthGetProtocolParams**，没找到；是否涉及到pin码？
2. pake_session_key session_key和hc_session_key service_key分别什么作用，后者就是前者？
3. shared_secret是否相同，如何完成认证的？

### 其他：

cal_bignum_exp(base, exp, len)

```c
int32_t cal_bignum_exp(struct var_buffer *base, struct var_buffer *exp,
    const uint32_t big_num_len, struct big_num *out_result):

struct HksBlob big_num_a = { base->length, base->data };
struct HksBlob big_num_e = { exp->length, exp->data };
struct HksBlob big_num_n = { big_num_len, large_num };
struct HksBlob big_num_x = { big_num_len, out_result->big_num };
status = HksBnExpMod(&big_num_x, &big_num_a, &big_num_e, &big_num_n);
// x=pow(a,e)%n
```

数据结构：

```c
struct pake_client {
    struct key_agreement_client client_info;
    uint32_t key_length;
    struct hc_pin pin; //创建时调用回调函数获取参数得到
    struct hc_salt salt; //服务器回复start时发送
    struct hc_auth_id self_id; //创建时调用回调函数获取参数得到
    struct hc_auth_id peer_id; //创建时调用回调函数获取参数得到
    struct challenge self_challenge; //自己发送end前生成
    struct challenge peer_challenge; //服务器回复start时发送
    struct esk self_esk;
    struct pake_session_key session_key;
    struct pake_hmac_key hmac_key; 
    struct hc_session_key service_key;
    enum large_prime_number_type prime_type;
    struct epk self_epk;
    struct epk peer_epk; //服务器回复start时发送
    struct pake_shared_secret shared_secret;
    struct hmac kcf_data; //自己发送end前生成
    const struct session_identity *identity; //hichain会话标识，即hichain->identity
    int32_t operation_code;
};

struct pake_server {
    struct key_agreement_server server_info;
    uint32_t key_length;
    struct hc_pin pin;
    struct hc_salt salt;
    struct hc_auth_id self_id;
    struct hc_auth_id peer_id;
    struct challenge self_challenge;
    struct challenge peer_challenge;
    struct esk self_esk;
    struct pake_session_key session_key;
    struct pake_hmac_key hmac_key;
    struct hc_session_key service_key;
    enum large_prime_number_type prime_type;
};

struct hc_session_key {
    uint32_t length;
    uint8_t session_key[HC_SESSION_KEY_LEN];
};
```





AuthManagerSetSessionKey即回调函数set_session_key

```c
//秘钥类型：
static const uint8_t g_key_type_pairs[HC_MAX_KEY_TYPE_NUM][HC_KEY_TYPE_PAIR_LEN] = {
    { 0x00, 0x00 }, /* ACCESSOR_PK */
    { 0x00, 0x01 }, /* CONTROLLER_PK */
    { 0x00, 0x02 }, /* ed25519 KEYPAIR */
    { 0x00, 0x03 }, /* KEK, key encryption key, used only by DeviceAuthService */
    { 0x00, 0x04 }, /* DEK, data encryption key, used only by upper apps */
    { 0x00, 0x05 }, /* key tmp */
    { 0x00, 0x06 }  /* PSK, preshared key index */
};
```

