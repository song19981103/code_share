## DevEco Studio

<img src="D:\OneDrive\md文件-研究生阶段\pic\image-20220929194235582.png" alt="image-20220929194235582"  />

C++源码

index.d.ts是hello.cpp的接口文件

package.json是接口注册配置文件，给index.d.ts设置一个name

index.ets可以import这个接口文件的name来调用接口



**烧录：** 按钮同时电源线  软件中擦除 固件添加img文件 升级

