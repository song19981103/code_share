### socket

[LINUX下C++ Socket 网络通信简单实现_linux c++socket线程通信](https://blog.csdn.net/HUSTIS1804/article/details/122637618)

[Socket的基本操作函数socket()、bind()、listen()、connect()、accept()、recv()、send()、select()、close()_socket函数和bind](https://blog.csdn.net/qq_36025591/article/details/113964442)

### cmake

如果你想在 `main.c` 中调用 `client` 类并创建一个可执行程序，则应该使用 `add_executable`。 `add_executable` 用于构建可执行程序，而 `add_library` 用于创建库文件（静态或共享库），通常是供其他项目使用的。

```c
add_executable(your_executable_name main.c client.c)
```

### vector

```c++
// 函数接受一个 vector 的引用（别名，指向同一内存），并修改其内容
void modifyVector(std::vector<int> &myVector) {
    for (int &value : myVector) {
        value *= 2; // 修改 vector 中的每个元素
    }
}
modifyVector(numbers); //可以实现修改vector的内容

size(): 返回向量中的元素数量。
empty(): 检查向量是否为空。
capacity(): 返回向量的容量。
push_back(value): 在向量的末尾添加一个值为 value 的元素。
sort(): 对向量中的元素进行排序。
    
注意：auto device遍历无法该值，auto &device才可以改值
  std::vector<double> a;
  a.push_back(1);
  a.push_back(2);
  for (auto &device : a) {
    device = 3;
  }
```

### map

```c++
std::unordered_map<std::string, int> myMap;
myMap.insert(std::make_pair("apple", 3));
myMap["banana"] = 5;

auto it = myMap.find("apple");
if (it != myMap.end()) {
    // 元素 "apple" 存在，可以访问其值
    int count = it->second;
}

for (auto& pair : myMap) {
        pair.second *= 2; // 修改值（将值乘以2）
    }
for (auto it = myMap.begin(); it != myMap.end(); ++it) {
    it->second = newValue; // 修改值


int count = myMap["banana"];
myMap.erase("banana"); // 删除键为 "banana" 的元素

for (const auto &pair : myMap) {
    std::cout << pair.first << ": " << pair.second << std::endl;
}
// 或者使用迭代器
for (auto it = myMap.begin(); it != myMap.end(); ++it) {
    std::cout << it->first << ": " << it->second << std::endl;
}

size_t size = myMap.size();
if (myMap.empty()) {
    // 容器为空
}
```

### set

```c++
std::unordered_set<int> mySet;

mySet.insert(42);
mySet.insert(23);

if (mySet.find(42) != mySet.end()) {
    // 元素 42 存在于集合中
}

mySet.erase(42); // 删除元素 42

for (int value : mySet) {
    std::cout << value << " ";
}
// 或者使用迭代器
for (auto it = mySet.begin(); it != mySet.end(); ++it) {
    std::cout << *it << " ";
}

if (mySet.empty()) {
    // 集合为空
}
size_t size = mySet.size();
```

