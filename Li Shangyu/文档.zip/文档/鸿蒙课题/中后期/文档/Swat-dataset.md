## SWaT测试平台

### 一、简介

SWaT 是水处理的操作测试平台，可生产 5 US gallons/hr的过滤水。该试验台占地面积约90平方米，是**大城市大型现代化水处理厂的小型版本**。整体测试台设计与**新加坡公用事业局（全国性水务公司）**协调，并由第三方供应商建造。这种合作确保了整个物理过程和控制系统与现场的真实系统非常相似，因此结果也可以应用于真实系统。是一种用于安全研究和培训的现代工业控制系统（ICS）。

![7469060-fig-1-source-large](D:\OneDrive\md文件-研究生阶段\pic\7469060-fig-1-source-large-1697422187593-4.gif)





**SWaT目前用于：**

（a）了解网络和物理攻击对水处理系统的影响

**（b）评估攻击检测算法的有效性**

（c）评估系统受到攻击时防御机制的有效性

（d）了解一个工业控制系统（ICS）故障对另一个相关ICS的级联效应

#### 多源异常检测方案

GDN模型：将结构学习方法与图神经网络相结合。

GDN模型可以实现多源异常检测，模型的检测效果可以使用该数据集进行测试。

### 二、SWaT 架构

#### 架构

SWaT由6级水处理过程组成，每个阶段由本地可编程逻辑控制器（PLC）自主控制。传感器、执行器和PLC之间的本地现场总线通信通过替代的有线和无线通道实现。

SWaT由一个现代化的六阶段过程组成。

* P1: 过程首先吸收原水
* P2: 向其中添加必要的化学物质
* P3: 通过超滤（UF）系统过滤
* P4: 使用紫外线灯对其进行脱氯
* P5: 然后将其送入反渗透（RO）系统
* P6: 反冲洗过程使用RO产生的水清洁UF中的膜

SWaT的网络部分由分层通信网络，可编程逻辑控制器（PLC），人机界面（HMI），监控和数据采集（SCADA）工作站以及历史数据库组成。来自传感器的数据可供SCADA系统（即数据采集与监视控制系统）使用，并由历史学家记录以供后续分析。

#### 传感器

![7469060-fig-2-source-large](D:\OneDrive\md文件-研究生阶段\pic\7469060-fig-2-source-large.gif)

#### 传感器相关性

**对一个传感器/执行器的攻击可能会影响其他传感器/执行器或整个系统的性能。**

值为1表示高度相关的特征，而值为-1表示高度逆相关。一些特征中的空白表示无法计算Pearson相关性，因为该特征的值在整个数据集上保持不变。

![img](D:\OneDrive\md文件-研究生阶段\pic\v2-d4546927ac0a71850f775477b45281f0_720w.webp)

### 三、攻击类型

#### A. 攻击者模型

最初的系统侦察和对系统的第一次攻击是在SWaT投入运营后不久发起的。特别是，我们专注于几个攻击者设置：

a）有权访问本地工厂通信网络的攻击者A

b）物理上接近但不直接在现场的攻击者B

c）在现场并具有对设备的物理访问权限的攻击者C

在所有情况下，攻击者的目标都是操纵工厂的正常运行。

在一次模范攻击中，目标是使SWaT中的原水箱溢出。有人认为，这个目标虽然不会威胁到高损害，但代表了要求攻击者完全控制ICS中的传感器和执行器的攻击。同时，在实验室中实现它足够安全而不会损坏设备。对于第 III-B 节中的第一个攻击场景，我们假设攻击者对所使用的技术有一般了解，但还不知道受攻击系统的详细信息。在该设置中，攻击者试图获取有关受攻击系统的更多信息，并找到其他攻击媒介来操纵系统。特别是，攻击者拥有使用特定工业协议（例如EtherNet/IP和CIP）与工业设备进行交互的工具

#### B. 攻击类型

| 攻击类型 | 攻击次数 |
| :------: | :------: |
|   SSSP   |    26    |
|   SSMP   |    4     |
|   MSSP   |    2     |
|   MSMP   |    4     |



* 单阶段单点 （SSSP）：单阶段单点攻击只关注信息物理系统（CPS）中的一个点。
* 单阶段多点 （SSMP）：单阶段多点攻击侧重于 CPS 中的两个或多个攻击点，但只针对一个阶段。在本例集中，P 由从任一阶段选择的 CPS 中的多个元素组成。
* 多阶段单点 （MSSP）：多阶段单点攻击类似于 SSMP 攻击，只是现在 SSMP 攻击分多个阶段执行。
* 多阶段多点 （MSMP）：多阶段多点攻击是在 CPS 的两个或多个阶段中执行的 SSMP 攻击。

#### C. 实际攻击

实际执行攻击：主要是对传感器**开关进行恶意控制**以及对传感器的**值进行恶意修改**

![image-20231016110554959](D:\Onedrive\md文件-研究生阶段\pic\image-20231016110554959.png)

实际执行的所有攻击：

| Attack                                                       |
| :----------------------------------------------------------- |
| Open  MV-101                                                 |
| Turn on P-102                                                |
| Increase by 1  mm every second                               |
| Open MV-504                                                  |
| Set value of  AIT-202 as 6                                   |
| Water level  increased above HH                              |
| Set value of  DPIT as >40kpa                                 |
| Set value of  FIT-401 as <0.7                                |
| Set value of  FIT-401 as 0                                   |
| Close MV-304                                                 |
| Do not let  MV-303 open                                      |
| Decrease water  level by 1mm each second                     |
| Do not let  MV-303 open                                      |
| Set value of  AIT-504 to 16 uS/cm                            |
| Set value of  AIT-504 to 255 uS/cm                           |
| Keep MV-101 on  countinuosly; Value of LIT-101 set as 700 mm |
| Stop UV-401;  Value of AIT502 set as 150; Force P-501 to remain on |
| Value of  DPIT-301 set to >0.4 bar; Keep MV-302 open; Keep P-602 closed |
| Turn of P-203  and P-205                                     |
| Set value of  LIT-401 as 1000; P402 is kept on               |
| P-101 is  turned on continuosly; Set value of LIT-301 as 801 mm |
| Keep P-302 on  contineoulsy; Value of LIT401 set as  600 mm till 1:26:01 |
| Close P-302                                                  |
| Turn on P-201;  Turn on P-203; Turn on P-205                 |
| Turn P-101 on  continuously; Turn MV-101 on continuously; Set value of LIT-101 as 700 mm;  P-102 started itself because LIT301 level became low |
| Set LIT-401 to  less than L                                  |
| Set LIT-301 to  above HH                                     |
| Set LIT-101 to  above H                                      |
| Turn P-101 off                                               |
| Turn P-101  off; Keep P-102 off                              |
| Set LIT-101 to  less than LL                                 |
| Close P-501;  Set value of FIT-502 to 1.29 at  11:18:36      |
| Set value of  AIT402 as 260; Set value of AIT502 to 260      |
| Set value of  FIT-401 as 0.5; Set value of AIT-502 as 140 mV |
| Set value of  FIT-401 as 0                                   |
| decrease value  by 0.5 mm per second                         |

### 四、数据采集

#### 数据采集

数据收集过程总共持续了11天。在整个11天期间，SWaT每天24小时不间断地运行。

SWaT在11天的前七天没有任何攻击。在剩下的四天里发动了攻击。

各种类型的攻击是在测试平台上实现的。这些攻击的意图各不相同，持续了几分钟到一个小时。根据攻击场景，系统要么在发起另一次攻击之前达到其正常运行状态，要么连续发起攻击。

在数据收集过程中做出以下假设。

1. 系统将在正常运行的前七天内稳定并达到其运行状态。
2. 设在不到一秒的时间内不会对SWaT测试台发起重大攻击，则每秒记录一次数据。
3. 可编程逻辑控制器(PLC)固件不变。

#### 数据规模

|                         Item                          |  SWaT  |
| :---------------------------------------------------: | :----: |
|                    Variables 变量                     |   51   |
|                   Attacks 攻击次数                    |   36   |
|         Attack durations (mins) 攻击持续时间          |  2~25  |
|        Training size (normal data) 训练集大小         | 496800 |
|      Testing size (data with attacks) 测试集大小      | 449919 |
| Normal rate in Testing dataset (%) 测试集正常数据占比 | 88.02  |







