conda python=3.9.x
conda install pytorch torchvision torchaudio cpuonly -c pytorch
conda install keras=2.11.0