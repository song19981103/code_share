import math
import torch
import keras
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pandas import read_csv, Series
from keras.models import Sequential
from keras.layers import LSTM, Dense, Dropout, Activation
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
import plotly.io as pio
pio.renderers.default = 'iframe_connected'

# 定义随机种子
np.random.seed()
# 加载数据
dataframe = read_csv('traindata.csv', encoding='gbk', usecols=[0], engine='python')
# print(dataframe)
data = dataframe.values
data = data.astype('float32')
# # 缩放数据归一化
scaler = MinMaxScaler(feature_range=(0, 1))
data = scaler.fit_transform(data)
data = data[:1000]
# 分割数据作为训练集和测试集
train_size = int(len(data) * 0.8)
test_size = len(data) - train_size
train, test = data[0:train_size, :], data[train_size:len(data), :]

# 预测数据步长为100,100个数据为一组预测1个数据，100->1 步长需要和保存模型时的一致  步长越小对现有数据集的拟合越好，对未来值的预测越差
look_back = 100

def create_dataset(data, look_back=1):
    dataX, dataY = [], []
    for i in range(len(data) - look_back - 1):
        a = data[i:(i + look_back), 0]
        dataX.append(a)
        dataY.append(data[i + look_back, 0])
    return np.array(dataX), np.array(dataY)


trainX, trainY = create_dataset(train, look_back)
testX, testY = create_dataset(test, look_back)
# 重构输入数据格式 [samples, time steps, features] = [样本数,1,100]
# 输入必须是三维 包括样本（数据的行） 时间步 特征（数据的行）
# samples 输入LSTM的样本的数量 timesteps 窗口大小，即截取的样本长度（拿多长的样本进行预测） features 样本的维度
trainX = np.reshape(trainX, (trainX.shape[0], 1, trainX.shape[1]))
testX = np.reshape(testX, (testX.shape[0], 1, testX.shape[1]))
print(testX.shape)

train = True
if train:
    # 构建 LSTM
    # 1.定义网络
    model = Sequential()  # 创建层序列 Sequential类
    model.add(LSTM(256, input_shape=(1, look_back),
                   return_sequences=True))  # units 神经元的数量 input_shape = (TIME_STEPS,INPUT_SIZE)),第一个代表每个输入的样本序列长度，第二个元素代表
    # 每个序列里面的1个元素具有多少个输入数据。
    model.add(Dropout(0.2))  # Dropout把上一层神经元进行随机丢弃，减少过拟合
    model.add(LSTM(128, return_sequences=False))
    model.add(Dropout(0.2))
    model.add(Dense(1))  # 全连接层 用于输出预测
    # model.add(Activation("tanh"))
    # 2.编译网络

    model.compile(loss='mean_squared_error',
                  optimizer=keras.optimizers.SGD(lr=0.001))  # 编译网络 优化算法 sgd--随机梯度下降 Adam RMSprop等优化算法
    print(model.summary())
    # 3.适合网络
    history = model.fit(trainX, trainY, epochs=25, batch_size=1, verbose=1,
                        validation_data=(testX, testY), )  # verbose是日志显示，有三个参数可选择，分别为0,1和2。
    # 4.评估网络
    plt.plot(history.history['loss'], label='train')
    plt.plot(history.history['val_loss'], label='test')
    plt.legend()
    plt.show()
    # loss,accuracy=model.evaluate(trainX,trainY)
    torch.save(model, 'Tang-model.pt')  # 16
else:
    # #加载模型
    model = torch.load('Tang-model.pt')

# 5.预测
# 对训练数据的Y进行预测
trainPredict = model.predict(trainX)
print(trainPredict.shape)
# 对测试数据的Y进行预测
testPredict = model.predict(testX)
# 对数据进行逆缩放
trainPredict = scaler.inverse_transform(trainPredict)
trainY = scaler.inverse_transform([trainY])
testPredict = scaler.inverse_transform(testPredict)
testY = scaler.inverse_transform([testY])

# 计算RMSE误差
trainScore = math.sqrt(mean_squared_error(trainY[0], trainPredict[:, 0]))
print('Train Score: %.2f RMSE' % (trainScore))
testScore = math.sqrt(mean_squared_error(testY[0], testPredict[:, 0]))
print('Test Score: %.2f RMSE' % (testScore))
# 计算均方误差（MSE）
mse = mean_squared_error(testY[0], testPredict[:, 0])
# 计算R平方值（R^2）
r2 = r2_score(testY[0], testPredict[:, 0])
# 计算平均绝对误差（MAE）
mae = mean_absolute_error(testY[0], testPredict[:, 0])
# 计算平均绝对百分比误差（MAPE）
mape = np.mean(np.abs((testY[0] - testPredict[:, 0]) / testY[0])) * 100
# 对称平均绝对百分比误差(SMAPE)
smape = 2.0 * np.mean(np.abs(testPredict[:, 0] - testY[0]) / (np.abs(testPredict[:, 0]) + np.abs(testY[0]))) * 100
# 模型评估性能指标
print(f"均方误差 (MSE): {mse:.2f}")
print(f"R平方值 (R-Square): {r2:.2f}")
print(f"平均绝对误差 (MAE): {mae:.2f}")
print(f"平均绝对百分比误差 (MAPE): {mape:.2f}%")
print(f"对称平均绝对百分比误差 (SMAPE): {smape:.2f}%")

# 构造一个和dataset格式相同的数组 dataset为总数据集
trainPredictPlot = np.empty_like(data)
# 用nan填充数组
trainPredictPlot[:, :] = np.nan
# 将训练集预测的Y添加进数组
trainPredictPlot[look_back:len(trainPredict) + look_back, :] = trainPredict

# 构造一个和dataset格式相同的数组 把预测的测试数据放进去
testPredictPlot = np.empty_like(data)
testPredictPlot[:, :] = np.nan
# 将测试集预测的Y添加进数组
testPredictPlot[len(trainPredict) + (look_back * 2) + 1:len(data) - 1, :] = testPredict

# 画图
# plt.plot(scaler.inverse_transform(data), color='r', label='original data')
# plt.plot(trainPredictPlot, color='g', label='trianPredict data')
# plt.plot(testPredictPlot, color='b', label='testPredict data')
# plt.legend()
# plt.show()

# 加载训练模型
model = torch.load('Tang-model.pt')
# 读入测试集预测的后三个数据
n = look_back
testpredict = testPredictPlot[-n - 1:-1]
a = []
for i in range(len(testpredict)):
    a.append(testpredict[i][0])
# print(a)


# 预测后100数据
def Perdict(a, n):
    Input = a[-n:]
    Input = np.array(Input)
    Input = Input.astype('float32')
    Input = scaler.fit_transform(Input.reshape(-1, 1))
    Input = Input.reshape(-1, 1)
    Input = np.reshape(list(Input[-n:]), (1, Input.shape[1], len(Input)))
    featruePredict = model.predict(Input)
    # #将标准化数据逆缩放
    featruePredict = scaler.inverse_transform(featruePredict)
    # print(featruePredict[0][0])
    return featruePredict[0][0]


for i in range(len(testpredict)):
    t = Perdict(a, n)
    a.append(t)
print("预测结果为：", a)
# plt.plot(a)
# plt.ticklabel_format(style='plain')
# plt.show()
