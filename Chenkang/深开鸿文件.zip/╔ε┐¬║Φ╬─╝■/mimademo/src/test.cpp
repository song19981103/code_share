
#include "miracl/miracl.h"
#include "miracl/func.h"

#include <iostream>
#include <thread>
#include <chrono>
#include <cstring>
#include <chrono>
#include <stdio.h>
#include <vector>

int main(int argc, char const *argv[])
{
    device d, d1;
    miracl *mip = mirsys(500, 0); // 大数运算必须以mirsys开始，结束时mirexit
    irand(time(NULL));            // 初始化内部随机数系统
    big x = mirvar(0), y;
    int n = 100000;
    std::chrono::time_point<std::chrono::system_clock> start, end;
    double run_time;


    d.initial(3, 5);
    d.rand_size = 300;
    d.p_size = 300;
    d.setpsize(d.p_size);       // 设备设定大素数的位数
    d.setrandsize(d.rand_size); // 设备设定随机数的位数

    d.generatebigprime();
    d.generatepoly();

    start = std::chrono::system_clock::now(); // 开始时间
    for (size_t i = 0; i < n; i++)
    {
        bigdig(d.p_size, 20, x);
        powmod(x, mirvar(1), d.p, x);
        d.generateshare(x);
    }
    end = std::chrono::system_clock::now();
    run_time = std::chrono::duration_cast<std::chrono::microseconds>(end - start).count() * (1.0f / CLOCKS_PER_SEC); // 计算运行时间(单位：微秒)

    cout << "300位的程序运行" << n <<"次的运行时间为："<< run_time<<endl;

    d1.initial(3, 5);
    d1.rand_size = 30;
    d1.p_size = 30;
    d1.setpsize(d1.p_size);       // 设备设定大素数的位数
    d1.setrandsize(d1.rand_size); // 设备设定随机数的位数

    d1.generatebigprime();
    d1.generatepoly();
    start = std::chrono::system_clock::now(); // 开始时间
    for (size_t i = 0; i < n; i++)
    {
        bigdig(d1.p_size, 20, x);
        powmod(x, mirvar(1), d1.p, x);
        d1.generateshare(x);
    }
    end = std::chrono::system_clock::now();
    run_time = std::chrono::duration_cast<std::chrono::microseconds>(end - start).count() * (1.0f / CLOCKS_PER_SEC); // 计算运行时间(单位：微秒)

    cout << "30位的程序运行" << n <<"次的运行时间为："<< run_time<<endl;

    mirexit(); // 在MIRACL的当前实例之后清理，并释放所有内部变量
    return 0;
}
