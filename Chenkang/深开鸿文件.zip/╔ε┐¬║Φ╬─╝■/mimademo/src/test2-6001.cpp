#include <iostream>
#include <thread>
#include <chrono>
#include <cstring>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <vector>
#include <map>
#include <queue>
#include <mutex>
#include <condition_variable>
#include <fcntl.h>

#include "miracl/miracl.h"
#include "miracl/func.h"

// #define PORT 6000
#define MAX_BUF_SIZE 1024
#define P_SIZE 300
#define RAND_SIZE 300

using namespace std;

vector<int> port_pool; // 群组中的地址列表
queue<int> leave_id;   // 离开群组的设备id
vector<big> kvec;	   // 存储
vector<big> vvec;
map<int, big> id_pool;		 // 地址和设备id的对应数对
map<int, big> subsecret_map; // 存储各个设备的秘密份额
map<int, big> tsecret_map;	 // 存储各个设备的秘密值
map<int, big> key_map;		 // 收集回应的数据分片
map<int, big> value_map;	 // 收集回应的秘密份额
// map<big, big> key_value_map;
map<string, int> action_map; // 消息标识和收到相应消息程序采取的动作

int recv_secret_num;
int datashareport = 0;
mutex mtx;			   // 定义互斥锁
condition_variable cv; // 定义条件变量
bool exit_group = false;

void udp_sender(int port, string msg);

/**
 * @description: 设备之间消息的头，作为标识
 * @return {*}
 */
void add_actions()
{
	action_map["PRIME"] = 0;	 // 大素数
	action_map["SUBSECRET"] = 1; // 秘密份额
	action_map["DEVICEID"] = 2;	 // 设备id

	action_map["REQUEST_S"] = 3;  // 请求秘密份额
	action_map["RESPONSE_S"] = 4; // 响应秘密份额的请求
	action_map["REQUEST_D"] = 5;  // 请求数据分片值
	action_map["RESPONSE_D"] = 6; // 响应数据分片请求
	action_map["REQUEST_T"] = 7;  // 请求秘密值
	action_map["RESPONSE_T"] = 8; // 响应秘密值的请求
	action_map["DATA_PIECE"] = 9; // 分发数据分片

	action_map["REQUEST_P"] = 10;	   // 请求大素数
	action_map["REQUEST_ID"] = 11;	   // 请求其他设备的id
	action_map["QUIT"] = 12;		   // 设备离开群组，但是暂时不更新，保证原有的秘密值能恢复
	action_map["REQUEST_DATA"] = 13;   // 向数据拥有者请求数据来验证
	action_map["RESPONSE_DATA"] = 14;  // 响应数据请求
	action_map["REQUEST_SHARE"] = 15;  // 请求各个设备分发秘密份额
	action_map["REQUEST_DSHARE"] = 16; // 请求数据分发者发送数据分片
	action_map["UPDATE"] = 17;		   // 各个设备更新离开设备所分发的值
}

/**
 * @description: 根据消息的头将消息分类，设备收到不同的消息采取不同的动作
 * @param {string} str: 消息
 * @return {pair<int, int>}: 返回数对(a,b)，a为消息在action_map中的类别，
 * 				b为消息类别头的长度+1
 * @example: msg:"PRIME:6000:12345",返回(0,6)
 */
pair<int, int> start_with(string str)
{
	int ret = 0;
	string head;
	map<string, int>::iterator it;

	// 遍历消息，找到头结束的位置
	for (size_t i = 0; i < str.size(); i++)
	{
		if (str[i] == ':')
		{
			ret = i;
			break;
		}
	}
	// 找到头结束的位置后，与action_map中消息类别比对，找到对应消息类别的编号
	if (ret)
	{
		head = str.substr(0, ret);
		it = action_map.find(head);
		if (it != action_map.end())
		{
			return make_pair(action_map[head], ret + 1);
		}
		else
		{
			printf("there not exist such head\n");
		}
	}
	return make_pair(-1, ret);
}

/**
 * @description: 解析消息获取有用的信息
 * @param {string} str: 消息
 * @param {int} start: 消息头结束的位置，不用重头遍历
 * @return {pair<int, int>}: 返回数对(a,b)，a为消息发送方标识（本demo中用端口号作为标识）
 * 				b为消息发送方标识结束的位置+1
 * @example: msg:"PRIME:6000:12345",返回(6000,11)
 */
pair<int, int> parse_msg(string str, int start)
{
	int ret, tmp;
	for (size_t i = start; i < str.size(); i++)
	{
		if (str[i] == ':')
		{
			ret = i;
			break;
		}
	}
	tmp = stoi(str.substr(start, ret - start));
	return make_pair(tmp, ret + 1);
}

/**
 * @description: 获取map 中(key, value)的value集合
 * @param {map<int, big>} mymap: 一个c++中映射
 * @return {vector<big>}: 返回该映射中的值的列表
 *
 * @example: mymap:{(1,123),(2,3434),(3,5623)},返回[123,3434,5623]
 */
vector<big> detach_value(map<int, big> mymap)
{
	vector<big> ret_vec;

	for (map<int, big>::iterator it = mymap.begin(); it != mymap.end(); ++it)
	{
		ret_vec.push_back(it->second);
	}
	return ret_vec;
}

/**
 * @description: 获取map 中(key, value)的value列表或者key列表
 * @param {map<big, big>} mymap: 一个c++中映射容器
 * @param {int} pos: 0表示要获取key的列表，1表示要获取value的列表
 * @return {vector<big>}: 返回该映射中key/value的值的列表
 *
 * @example: mymap:{(1,123),(2,3434),(3,5623)},返回value列表[123,3434,5623]
 * 			或key列表[1,2,3]
 */
vector<big> detach_key_value(map<big, big> mymap, int pos)
{
	vector<big> ret_vec;
	if (pos)
	{
		for (map<big, big>::iterator it = mymap.begin(); it != mymap.end(); ++it)
		{
			ret_vec.push_back(it->second);
		}
	}
	else
	{
		for (map<big, big>::iterator it = mymap.begin(); it != mymap.end(); ++it)
		{
			ret_vec.push_back(it->first);
		}
	}

	return ret_vec;
}

/**
 * @description: 设置udp通信为非阻塞
 * @param {int} sockfd
 * @return {*}
 */
static void setnonblocking(int sockfd)
{
	// 获取套接字的标志位
	int flag = fcntl(sockfd, F_GETFL, 0);
	if (flag < 0)
	{
		exit(EXIT_FAILURE);
		return;
	}
	// 设置套接字标志位为非阻塞
	if (fcntl(sockfd, F_SETFL, flag | O_NONBLOCK) < 0)
	{
		exit(EXIT_FAILURE);
	}
}

/**
 * @description: 创建 UDP 监听线程函数
 * @param {device} &d: 当前设备
 * @return {*}
 */
void udp_listener(device &d)
{
	struct sockaddr_in addr;

	pair<int, int> msg_type, msg_parse;
	map<int, big>::iterator tmpit;
	int head_type, leave_port;
	string recv_msg, head, resp_msg;

	// 通信地址，端口设置（本demo中设置为本地）
	memset(&addr, 0, sizeof(addr));
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = htonl(INADDR_ANY);
	addr.sin_port = htons(d.port);

	// 创建 UDP socket套接字
	int sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	// 设置套接字为非阻塞
	setnonblocking(sockfd);
	// 将 socket 与地址绑定
	bind(sockfd, (struct sockaddr *)&addr, sizeof(addr));

	char buf[MAX_BUF_SIZE];
	char ch[MAX_BUF_SIZE];

	// 当设备退出群组时，结束循环
	while (!exit_group)
	{
		memset(buf, 0, sizeof(buf));

		// 接收 UDP 消息
		int len = recvfrom(sockfd, buf, MAX_BUF_SIZE, 0, NULL, NULL);
		if (len > 0)
		{
			big recv_big_num = mirvar(0), reconstruc_num = mirvar(0);

			// 解析消息的头
			msg_type = start_with(buf);
			head_type = msg_type.first;

			// 根据消息的头执行不同的程序
			switch (head_type)
			{
			case 0: // 收到统一大素数的消息,设置自己的大素数和生成自己的多项式

				msg_parse = parse_msg(buf, msg_type.second);  // 解析消息
				cinstr(recv_big_num, buf + msg_parse.second); // 将消息中的字符串转为大数结构
				d.setprime(recv_big_num);					  // 设置大素数

				d.coef.clear();	  // 将自己的多项式系数列表清空
				d.generatepoly(); // 生成多项式系数列表
				printf("收到的大素数是：%s, 来自于地址: %d\n", buf + msg_parse.second, msg_parse.first);
				printf("生成的多项式的系数如下所示:\n");
				for (size_t i = 0; i < d.coef.size(); i++)
				{
					cotnum(d.coef[i], stdout);
				}

				break;
			case 1:											  // 收到分发密钥，添加到其秘密份额里面
				msg_parse = parse_msg(buf, msg_type.second);  // 解析消息
				cinstr(recv_big_num, buf + msg_parse.second); // 将消息中的字符串转为大数结构

				// 查找是否已经存在有来自于设备msg_parse.first的秘密份额，若有就删除掉
				tmpit = subsecret_map.find(msg_parse.first);
				if (tmpit != subsecret_map.end())
				{
					d.secretsub(tmpit->second);
				}
				subsecret_map[msg_parse.first] = recv_big_num; // 将秘密份额记录下来，后续设备离开后删除掉

				d.secretsum(recv_big_num); // 将新的秘密份额添加到自己的总的秘密份额中
				break;
			case 2:											  // 收到设备 id
				msg_parse = parse_msg(buf, msg_type.second);  // 解析消息
				cinstr(recv_big_num, buf + msg_parse.second); // 将消息中的字符串转为大数结构

				// 检查设备是否已经存在，若不存在群组设备+1
				tmpit = id_pool.find(msg_parse.first);
				if (tmpit == id_pool.end())
				{
					d.member += 1; // 判断有一定问题，但是由于调试受限需要修改，功能不影响
				}

				// 记录发送该消息的设备id
				id_pool[msg_parse.first] = recv_big_num;

				// 检测发送该消息的设备id和自己的id是否重合，若重合提示重新生成新id
				if (msg_parse.first != d.port && mr_compare(recv_big_num, d.Deviceid) == 0)
				{
					udp_sender(msg_parse.first, "群组中已存在该id的设备\n ");
					printf("发送该消息的设备id和本设备的id相同\n ");
				}

				printf("收到的设备id和端口是 (%d,%s)\n", msg_parse.first,
					   buf + msg_parse.second);

				break;
			case 3:											 // 收到请求秘密份额
				msg_parse = parse_msg(buf, msg_type.second); // 解析消息

				resp_msg = "RESPONSE_S:"; // 设置返回消息的头
				resp_msg += to_string(d.port) + ":";

				cotnum(d.ownshare, stdout); // 终端输出本设备的总的秘密份额

				cotstr(d.ownshare, ch); // 将自己的总的秘密份额转为字符串类型
				resp_msg += string(ch);
				udp_sender(msg_parse.first, resp_msg); // 将该响应返回给请求的设备
				break;
			case 4:											  // 收到秘密份额请求的回应
				msg_parse = parse_msg(buf, msg_type.second);  // 解析消息
				cinstr(recv_big_num, buf + msg_parse.second); // 将消息中的字符串转为大数结构

				// 将收到的消息和发送消息的对应端口存储起来
				value_map[msg_parse.first] = recv_big_num;

				// 如果收到超过门限数量的消息开始密钥恢复
				if (value_map.size() == d.tresh)
				{
					kvec.clear(); // 记录设备id值
					vvec.clear(); // 记录设备的总的秘密份额
					printf("收到的设备id和总的秘密份额如下所示:\n");
					for (map<int, big>::iterator it = value_map.begin(); it != value_map.end(); it++)
					{
						kvec.push_back(id_pool[it->first]);
						vvec.push_back(it->second);
						cotnum(*kvec.rbegin(), stdout);
						cotnum(*vvec.rbegin(), stdout);
						printf("-----------\n");
					}
					reconstruc_num = d.secretreconstruct(vvec, kvec); // 秘密重构
					printf("重构出来的秘密为：");
					cotnum(reconstruc_num, stdout); // 终端输出重构出来的密钥

					/* 判断重构出来的密钥是否和群组的密钥一致，若不一致可能是恢复出现问题，
					也有可能是群组的密钥没有更新，需要更新后重新验证 */
					if (mr_compare(d.groupsecret, reconstruc_num) == 0)
					{
						printf("成功恢复秘密\n");
					}
					else
					{
						printf("恢复秘密失败（或者重新更新群组的秘密值）\n");
					}
				}
				break;
			case 5:											 // 收到数据重构请求
				msg_parse = parse_msg(buf, msg_type.second); // 解析消息

				resp_msg = "RESPONSE_D:"; // 回复该请求消息的头
				resp_msg += to_string(d.port) + ":";
				cotstr(d.datapiece, ch); // 将局部计算的值
				resp_msg += string(ch);
				udp_sender(msg_parse.first, resp_msg); // 发送数据分片给请求的设备
				break;
			case 6:											  // 收到数据重构回应
				msg_parse = parse_msg(buf, msg_type.second);  // 解析消息
				cinstr(recv_big_num, buf + msg_parse.second); // 将消息中的字符串转为大数结构

				// 将收到的消息和发送消息的对应端口存储起来
				key_map[msg_parse.first] = recv_big_num;
				// 如果收到超过门限数量的消息开始数据恢复
				if (key_map.size() == d.tresh)
				{
					kvec.clear(); // 存储设备的id值
					vvec.clear(); // 存储设备的数据分片值
					printf("收到的id和数据分片如下所示:\n");
					for (map<int, big>::iterator it = key_map.begin(); it != key_map.end(); it++)
					{
						kvec.push_back(id_pool[it->first]);
						vvec.push_back(it->second);
						cotnum(*kvec.rbegin(), stdout); // 终端输出设备id
						cotnum(*vvec.rbegin(), stdout); // 终端输出设备数据分片
						printf("-----------\n");
					}
					reconstruc_num = d.secretreconstruct(vvec, kvec); // 数据重构
					printf("重构出来的数据为：");
					cotnum(reconstruc_num, stdout); // 终端输出重构出来的数据

					/* 判断重构出来的数据是否和原始数据一致，若不一致可能是恢复出现问题，
					也有可能是用于验证的数据有误，需要获取到原始数据后重新验证 */
					if (mr_compare(d.sharedata, reconstruc_num) == 0)
					{
						printf("成功恢复数据\n");
					}
					else
					{
						printf("恢复数据失败（或者重新请求原数据再进行比较）,原数据如下\n");
						cotnum(d.sharedata, stdout);
					}
				}
				break;
			case 7:											 // 收到请求各自的秘密值
				msg_parse = parse_msg(buf, msg_type.second); // 解析消息

				resp_msg = "RESPONSE_T:"; // 返回的响应消息的头
				resp_msg += to_string(d.port) + ":";

				cotstr(d.coef[d.tresh - 1], ch); // 将设备的秘密值转为字符串
				resp_msg += string(ch);
				udp_sender(msg_parse.first, resp_msg); // 将该消息发送给请求的设备
				break;
			case 8:											  // 收到请求各自的秘密值的响应
				msg_parse = parse_msg(buf, msg_type.second);  // 解析消息
				cinstr(recv_big_num, buf + msg_parse.second); // 将消息中的字符串转为大数结构

				// 将收集到的秘密值存储起来
				tsecret_map[msg_parse.first] = recv_big_num;
				cotnum(recv_big_num, stdout);

				d.totalsecretsum(recv_big_num); // 计算已经收集到的秘密值

				// 已经收集到群组中的所有秘密值，可以计算出了群组的密钥值
				if (tsecret_map.size() == d.member)
				{
					printf("the total secret of the group is:");
					cotnum(d.groupsecret, stdout);
				}
				break;
			case 9:											  // 收到数据分片,局部计算
				msg_parse = parse_msg(buf, msg_type.second);  // 解析消息
				datashareport = msg_parse.first;			  // 记录对数据分片的设备端口（地址）
				cinstr(recv_big_num, buf + msg_parse.second); // 将消息中的字符串转为大数结构
				d.getdatapiece(recv_big_num);				  // 对收到的数据分片进行局部计算
				printf("the datapiece after get:");
				cotnum(d.datapiece, stdout); // 终端输出经过局部计算后的数据分片值
				break;
			case 10:										  // 收到大素数请求
				msg_parse = parse_msg(buf, msg_type.second);  // 解析消息
				cinstr(recv_big_num, buf + msg_parse.second); // 将消息中的字符串转为大数结构

				resp_msg = "PRIME:"; // 回应请求消息的头
				resp_msg += to_string(d.port) + ":";
				cotstr(d.p, ch); // 将大素数转为字符串
				resp_msg += string(ch);
				udp_sender(msg_parse.first, resp_msg); // 将回应的消息发送给请求得设备
				break;
			case 11:										 // 收到ID请求
				msg_parse = parse_msg(buf, msg_type.second); // 解析消息
				resp_msg = "DEVICEID:";						 // 回应请求消息的头

				resp_msg += to_string(d.port) + ":";
				cotstr(d.Deviceid, ch); // 将设备的id转为字符串
				resp_msg += string(ch);
				udp_sender(msg_parse.first, resp_msg); // 将回应的消息发送给请求得设备
				break;
			case 12: // 收到有设备离开群组

				// 有设备离开群组提示需要立即恢复密钥值
				printf("有设备离开群组，如果要恢复原来的秘密值，");
				printf("请停止新设备加入或者恢复原来的秘密值后再进行新设备加入\n");
				msg_parse = parse_msg(buf, msg_type.second); // 解析消息
				leave_id.push(msg_parse.first);				 // 将离开设备的id记录起来，用于后续更新操作

				// 如果离开群组的设备时分发数据的设备，提示需要立即恢复数据
				if (msg_parse.first == datashareport)
				{
					printf("分享数据的设备离开群组，如果要恢复原有数据，");
					printf("请停止新设备加入或者恢复原始数据后再进行新设备加入\n");
				}

				break;
			case 13:										 // 请求原始数据的响应
				msg_parse = parse_msg(buf, msg_type.second); // 解析消息
				resp_msg = "RESPONSE_DATA:";				 // 响应请求消息的头
				resp_msg += to_string(d.port) + ":";		 // 本机的地址添加到回应消息中
				cotstr(d.sharedata, ch);					 // 将原始数据转为字符串
				resp_msg += string(ch);
				udp_sender(msg_parse.first, resp_msg); // 发送消息给请求的设备
				break;
			case 14:										 // 收到原始数据
				msg_parse = parse_msg(buf, msg_type.second); // 解析消息
				cinstr(d.sharedata, buf + msg_parse.second); // 将请求到的原始数据存到d.sharedata中
				break;
			case 15:										 // 收到请求秘密份额的消息
				msg_parse = parse_msg(buf, msg_type.second); // 解析消息
				resp_msg = "SUBSECRET:";					 // 响应请求消息的头
				resp_msg += to_string(d.port) + ":";		 // 本机的地址添加到回应消息中

				// 查找请求的设备的id值是否存在
				tmpit = id_pool.find(msg_parse.first);
				if (tmpit == id_pool.end())
				{
					printf("there's no device id of %d", msg_parse.first);
					break;
				}

				// 根据请求设备的id计算秘密份额
				recv_big_num = d.generateshare(id_pool[msg_parse.first]);
				cotstr(recv_big_num, ch); // 将计算到的秘密份额转为字符串
				resp_msg += string(ch);

				udp_sender(msg_parse.first, resp_msg); // 将消息发送给请求的设备
				break;
			case 16:										 // 收到请求数据分片的消息
				msg_parse = parse_msg(buf, msg_type.second); // 解析消息

				// 查找请求的设备的秘密份额是否存在
				tmpit = tsecret_map.find(msg_parse.first);
				// 如果本设备是数据分片设备，并且请求的设备是新加入的设备，提示需要群组更新
				if (d.port == datashareport && tmpit == tsecret_map.end())
				{
					printf("the data owner should update the groupsecret\n");
					break;
				}

				if (datashareport == d.port) // 原数据拥有者收到请求
				{
					resp_msg = "DATA_PIECE:"; // 响应请求的头
					resp_msg += to_string(d.port) + ":";

					printf("d.sharedata is as follows:");
					cotnum(d.sharedata, stdout); // 终端输出原始数据
					printf("d.groupsecret is as follows:");
					cotnum(d.groupsecret, stdout); // 终端输出群组密钥

					// 重新计算数据分片值
					recv_big_num = d.datashare(d.sharedata, d.groupsecret);
					cotstr(recv_big_num, ch); // 将分片值转为字符串
					resp_msg += string(ch);
					for (map<int, big>::iterator it = id_pool.begin(); it != id_pool.end(); it++)
					{
						udp_sender(it->first, resp_msg); // 将数据分片的消息发送给群组中所有设备
					}
				}
				else
					break;

				break;
			case 17:										 // 群组更新
				msg_parse = parse_msg(buf, msg_type.second); // 解析消息
				while (!leave_id.empty())					 // 离开群组的队列为空才停止
				{
					leave_port = leave_id.front(); // 离开设备的端口号
					leave_id.pop();

					// 查找离开设备的秘密值是否存在
					tmpit = tsecret_map.find(leave_port);
					if (tmpit != tsecret_map.end())
					{
						d.totalsecretsub(tsecret_map[leave_port]); // 减去离开设备的秘密值
						tsecret_map.erase(leave_port);
					}

					// 查找离开设备的秘密份额是否存在
					tmpit = subsecret_map.find(leave_port);
					if (tmpit != subsecret_map.end())
					{
						d.secretsub(subsecret_map[leave_port]); // 减去离开设备分发的秘密份额
						subsecret_map.erase(leave_port);
					}

					// 查找离开设备的id是否存在
					tmpit = id_pool.find(leave_port);
					if (tmpit != id_pool.end())
					{
						id_pool.erase(leave_port); // 删除离开设备的地址和id数对
						d.member -= 1;
					}
				}

				// 如果是数据分片节点，需要重新计算数据分片值
				if (d.port == datashareport)
				{
					/* 睡眠5秒，等待其他的设备更新好秘密份额后发送数据的分片，
					否则其他设备收到数据分片值后,进行局部计算会使用
					原来的秘密份额计算，会出现错误（也可以通过获取其他设备的确认后进行数据分片） */
					sleep(5);
					resp_msg = "DATA_PIECE:"; // 响应消息的头
					resp_msg += to_string(d.port) + ":";

					printf("原始数据为如下所示:");
					cotnum(d.sharedata, stdout); // 终端输出原始数据
					printf("群组密钥为如下所示:");
					cotnum(d.groupsecret, stdout); // 终端输出现在的群组密钥

					recv_big_num = d.datashare(d.sharedata, d.groupsecret); // 数据分片
					cotstr(recv_big_num, ch);								// 将数据分片转为字符串
					resp_msg += string(ch);
					for (map<int, big>::iterator it = id_pool.begin(); it != id_pool.end(); it++)
					{
						udp_sender(it->first, resp_msg); // 给群组中的所有设备发送数据分片消息
					}
				}

				break;

			default:
				break;
			}
			cout << "Received message: " << buf << endl; // 输出接收到的消息
		}
	}

	// 关闭 UDP socket
	close(sockfd);
}

/**
 * @description: 创建 UDP 发送线程函数
 * @param {int} port: 发送的端口号
 * @param {string} msg: 发送的消息
 * @return {*}
 */
void udp_sender(int port, string msg)
{
	struct sockaddr_in addr;
	memset(&addr, 0, sizeof(addr));

	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = inet_addr("127.0.0.1"); // 发送给本地IP地址，实际场景中要使用对应的ip地址
	addr.sin_port = htons(port);

	// 创建 UDP socket
	int sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);

	char buf[MAX_BUF_SIZE];

	// 发送消息
	sprintf(buf, msg.data(), (int)time(NULL));
	sendto(sockfd, buf, strlen(buf), 0, (struct sockaddr *)&addr, sizeof(addr));

	// 等待1秒再继续发送消息
	this_thread::sleep_for(chrono::seconds(1));

	// 关闭 UDP socket
	close(sockfd);
}

// 可执行操作目录
void content()
{
	printf("选择动作:\n"); // 选择如下动作
	printf("0.退出\n");	   // 设备退出群组，但是不更新退出设备分发的秘密份额和数据分片
	printf("1.初始化\n");
	printf("2.发送秘密份额\n");
	printf("3.发送设备id\n");
	printf("4.请求重构密钥\n");
	printf("5.请求重构数据\n");
	printf("6.数据分片\n");		 // 数据分片（分享）
	printf("7.请求大素数\n");	 // 请求大素数，用于设备初始化参数设置
	printf("8.请求设备id\n");	 // 请求设备的id值，用于设备初始加入
	printf("9.请求秘密值\n");	 // 用于验证和数据分片
	printf("10.请求原始数据\n"); // 用于验证恢复数据是否正确
	printf("11.请求秘密份额\n");
	printf("12.请求数据分片\n");			 // 请求数据分片
	printf("13.更新秘密份额和数据分片值\n"); // 去除退出设备分发的秘密份额和数据分片
	printf("14.for test use\n");
}

int main()
{
	miracl *mip = mirsys(500, 10); // 大数运算必须以mirsys开始，结束时mirexit
	irand(time(NULL));			  // 初始化内部随机数系统

	device d; // 创建一个设备
	big tmp = mirvar(0), randomdata = mirvar(0), one = mirvar(1), c;
	int read_in;
	string tmp_str;
	char ch[MAX_BUF_SIZE];
	map<int, big>::iterator mtmpit;

	d.initial(3, 5); //(t, n) 群组中成员数量5，门限设定为3
	d.port = 6001;	 // 设备的地址为本地，端口为6000

	d.setpsize(P_SIZE);		  // 设备设定大素数的位数
	d.setrandsize(RAND_SIZE); // 设备设定随机数的位数
	d.setid();				  // 生成自己的id（或者用自身唯一标识id，群组中不能有相同的id值）

	// 每个设备都有群组中的各个设备的ip+端口号(建立好的群组需要保证这个基础)
	for (size_t i = 6000; i < 6000 + d.member; i++)
	{
		port_pool.push_back(i);
	}

	add_actions(); // 添加消息头来识别和处理消息

	thread listener(udp_listener, ref(d)); // 创建 UDP 监听线程，根据收到的不同消息进行不同处理

	do
	{
		content(); // 可以选择的动作的目录
		read_in = 0;
		cin >> read_in; // 读取采取动作

		switch (read_in)
		{
		case 1:					  // 初始化生成大素数并发给所有设备，并生成多项式
			d.generatebigprime(); // 生成大素数
			printf("生成的大素数如下所示:");
			cotnum(d.p, stdout);
			d.coef.clear();	  // 清空系数的列表
			d.generatepoly(); // 生成多项式的系数
			printf("生成的多项式如下所示:\n");
			for (size_t i = 0; i < d.coef.size(); i++)
			{
				cotnum(d.coef[i], stdout);
			}
			tmp_str = "PRIME:";					// 生成发送消息的头
			tmp_str += to_string(d.port) + ":"; // 添加本设备的地址
			cotstr(d.p, ch);					// 将大素数转为字符串后添加到消息中
			tmp_str += ch;
			for (size_t i = 0; i < port_pool.size(); i++) // 给其他设备发送大素数的消息
			{
				if (port_pool[i] == d.port)
					continue;
				udp_sender(port_pool[i], tmp_str);
			}
			break;
		case 2: // 计算设备的秘密份额并发送给对应设备
			printf("计算并发送秘密份额:\n");
			for (size_t i = 0; i < port_pool.size(); i++)
			{
				tmp_str = "SUBSECRET:";				// 发送消息的头
				tmp_str += to_string(d.port) + ":"; // 添加端口（地址）
				printf("%d : ", port_pool[i]);

				/* 查找该地址的设备id用于计算秘密份额，若群组中设备的地址无对应
				的设备id，会提示设备id缺少 */
				mtmpit = id_pool.find(port_pool[i]);
				if (mtmpit == id_pool.end())
				{
					printf("该地址的设备无对应的设备id");
					break;
				}

				tmp = d.generateshare(id_pool[port_pool[i]]); // 根据对于设备id计算秘密份额
				cotstr(tmp, ch);							  // 将秘密生成的秘密份额发送给对应设备
				cotnum(tmp, stdout);						  // 终端输出该秘密份额
				tmp_str += ch;
				udp_sender(port_pool[i], tmp_str); // 发送消息给对应设备
			}
			break;
		case 3: // 发送设备id给所有设备
			for (size_t i = 0; i < port_pool.size(); i++)
			{
				tmp_str = "DEVICEID:";				// 消息的头
				tmp_str += to_string(d.port) + ":"; // 添加地址
				cotstr(d.Deviceid, ch);				// 将设备id转为字符串
				tmp_str += ch;
				udp_sender(port_pool[i], tmp_str); // 将消息发送给对应设备
			}
			break;
		case 4:				   // 请求重构密钥值
			value_map.clear(); // 清空接收接收回应的map容器
			for (size_t i = 0; i < port_pool.size(); i++)
			{
				tmp_str = "REQUEST_S:";				// 消息的头
				tmp_str += to_string(d.port) + ":"; // 添加地址
				udp_sender(port_pool[i], tmp_str);	// 将消息发送给对应设备
			}
			break;
		case 5:				 // 请求重构数据
			key_map.clear(); // 清空接收接收回应的map容器
			for (size_t i = 0; i < port_pool.size(); i++)
			{
				tmp_str = "REQUEST_D:";				// 消息的头
				tmp_str += to_string(d.port) + ":"; // 添加地址
				udp_sender(port_pool[i], tmp_str);	// 将消息发送给对应设备
			}
			break;
		case 6: // 对数据分片，然后发送给所有设备
			if (mr_compare(d.groupsecret, mirvar(0)) == 0)
			{
				printf("请先获取到(或者更新)群组的秘密值\n");
				break;
			}
			printf("已经获取到了群组的秘密值\n");

			// 随机生成一个数据(或者使用已有数据)，该数据要小于p
			d.sharedata = mirvar(0);
			bigdig(P_SIZE, 10, d.sharedata);			// 随机生成一个P_SIZE位的10进制数据，复制到d.sharedata
			powmod(d.sharedata, one, d.p, d.sharedata); // d.sharedata 模 p(保证该数据小于p)

			// 数据拥有者进行数据分片
			c = mirvar(0);
			c = d.datashare(d.sharedata, d.groupsecret); // 对数据分片
			for (size_t i = 0; i < port_pool.size(); i++)
			{
				tmp_str = "DATA_PIECE:";			// 消息的头
				tmp_str += to_string(d.port) + ":"; // 本设备的地址
				cotstr(c, ch);						// 将数据分片值转为字符串
				tmp_str += ch;
				udp_sender(port_pool[i], tmp_str); // 将消息发送给对应设备（消息是一样的）
			}
			break;
		case 7: // 请求大素数
			for (size_t i = 0; i < port_pool.size(); i++)
			{
				if (port_pool[i] == d.port)
					continue;

				tmp_str = "REQUEST_P:";				// 消息的头
				tmp_str += to_string(d.port) + ":"; // 本设备的地址
				udp_sender(port_pool[i], tmp_str);	// 将消息发送给对应设备
				break;
			}
			break;
		case 8: // 请求device id
			printf("打印出群组中已有设备的地址:\n");
			for (auto i : port_pool)
			{
				printf("%d\n", i);
			}
			for (size_t i = 0; i < port_pool.size(); i++)
			{
				tmp_str = "REQUEST_ID:";			// 消息的头
				tmp_str += to_string(d.port) + ":"; // 本设备的地址
				udp_sender(port_pool[i], tmp_str);	// 将消息发送给对应设备
			}
			break;

		case 9:						   // 请求每个设备的秘密值
			d.groupsecret = mirvar(0); // 请求之前需要初始化
			tsecret_map.clear();	   // 请求之前需要清空存储的秘密值
			for (size_t i = 0; i < port_pool.size(); i++)
			{
				tmp_str = "REQUEST_T:";				// 消息的头
				tmp_str += to_string(d.port) + ":"; // 本设备的地址
				udp_sender(port_pool[i], tmp_str);	// 将消息发送给对应设备
			}
			break;
		case 10:						 // 请求分享的数据
			if (d.port == datashareport) // 如果本机就是对数据分片的设备
			{
				printf("this device is the data share device");
				break;
			}
			if (datashareport == 0) // 如果群组中未进行数据分片（或者本设备未收到数据分片）
			{
				printf("this group has no datashare or the device didn't get device piece\n");
				break;
			}

			tmp_str = "REQUEST_DATA:";			// 消息的头
			tmp_str += to_string(d.port) + ":"; // 本设备的地址
			udp_sender(datashareport, tmp_str); // 将消息发送给请求的设备
			break;
		case 11: // 请求秘密份额
			for (size_t i = 0; i < port_pool.size(); i++)
			{
				tmp_str = "REQUEST_SHARE:";			// 消息的头
				tmp_str += to_string(d.port) + ":"; // 本设备的地址
				udp_sender(port_pool[i], tmp_str);	// 给群组中的所有设备发送请求
			}

			break;
		case 12: // 请求数据分片局部值
			for (size_t i = 0; i < port_pool.size(); i++)
			{
				tmp_str = "REQUEST_DSHARE:";		// 消息的头
				tmp_str += to_string(d.port) + ":"; // 本设备的地址
				udp_sender(port_pool[i], tmp_str);	// 给群组中的所有设备发送请求
			}

			break;
		case 13: // 更新群组中的所有设备
			for (size_t i = 0; i < port_pool.size(); i++)
			{
				tmp_str = "UPDATE:";				// 消息的头
				tmp_str += to_string(d.port) + ":"; // 本设备的地址
				udp_sender(port_pool[i], tmp_str);	// 发送给群组中所有设备，使得群组更新
			}

			break;
		case 14:												// 测试使用，可以观察本设备的属性值的变换
			printf("the memeber is as follows:%d\n", d.member); // 群组中成员数量
			cotnum(d.sharedata, stdout);						// 群组中的原始数据

			// 本设备存储的秘密份额如下所示
			printf("the subsecret_map is as follows:\n");
			for (map<int, big>::iterator it = subsecret_map.begin(); it != subsecret_map.end(); ++it)
			{
				printf("%d,", it->first);
				cotnum(it->second, stdout);
			}

			printf("the ownshare is as follows:\n");// 本设备存储的总的秘密份额
			cotnum(d.ownshare, stdout);
			break;
		case 0:// 本设备退出群组
		// 通知群组中其他设备
			for (size_t i = 0; i < port_pool.size(); i++)
			{
				if (port_pool[i] == d.port)
					continue;
				tmp_str = "QUIT:";// 消息的头
				tmp_str += to_string(d.port) + ":";
				udp_sender(port_pool[i], tmp_str);
			}
			exit_group = true; // 设置停止标记为true
			cv.notify_all();   // 通知所有线程，停止监听接收消息
			break;
		default:
			break;
		}

	} while (read_in);

	// 等待线程结束
	listener.join();
	mirexit();//在MIRACL的当前实例之后清理，并释放所有内部变量
	printf("本设备已离开群组\n");
	return 0;
}