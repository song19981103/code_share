<!--
 * @Author: ck
 * @Date: 2023-06-16 05:39:23
 * @LastEditors: ck
 * @LastEditTime: 2023-06-16 05:47:28
 * @FilePath: /mimademo/include/miracl/fumula.md
 * @Description: 
 * 
 * Copyright (c) 2023 by ${git_name_email}, All Rights Reserved. 
-->

* secretreconstruct 中公式表达式如下

拉格朗日插值公式如下所示：$$f(x) = \sum_{j=0}^{n-1}f(x_j)\prod_{i \ne j} \frac{x_{i}-x}{x_{i}-x_{j}}$$

将x设为0代入可以得到如下计算式：

$$f(0) = \sum_{j=0}^{t}f(x_j)\prod_{i \ne j} \frac{x_{i}}{x_{i}-x_{j}}$$

计算过程为secret，id分别代入为$f(x)$和$x$中即可计算
