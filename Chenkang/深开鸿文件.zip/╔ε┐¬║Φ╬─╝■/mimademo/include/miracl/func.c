#include <stdio.h>
#include <time.h>
#include <string.h>

#include "miracl/miracl.h"
#include "miracl/mirdef.h"

//(3,5)门限
//(T, N)门限
#define N 5
#define T 3
#define P_SIZE 30
#define RAND_SIZE 30

/* 
 *生成并返回一个p_size位的大素数
 */
big generatebigprime(int p_size)
{
	big p = mirvar(0);
	do
	{
		bigdig(p_size, 10, p); // 这将生成一个12位十进制随机数
	} while (!isprime(p));
	return p;
}

/* 
 * 随机生成一个t-1阶多项式，p为大素数，coef为多项式系数列表[a_{t-1}, ..., a_1, a_0]
 * 多项式为f(x) = a_{t-1}x^{t-1} + ... + a_1x + a_0
 */
void generatepoly(int t, big p, big *coef)
{
	big tmp = mirvar(0), one = mirvar(1);
	for (size_t i = 0; i < T; i++)
	{
		coef[i] = mirvar(0);
		bigdig(RAND_SIZE, 10, tmp);	  // 这将生成一个100位十进制随机数
		powmod(tmp, one, p, coef[i]); // 模p
	}
}

/* 
 * 根据多项式的系数列表coef，大素数p，代入值x，生成对应的多项式的值，也即是子秘密
 */
big generateshare(big x, big p, big *coef)
{
	big ret = mirvar(0);
	big one = mirvar(1);
	for (size_t i = 0; i < T; i++)
	{
		// f(x) = a_0  + a_1*x + ... + a_{t-1}*x^{t-1}
		multiply(ret, x, ret);
		add(ret, coef[i], ret);

		// tmp = mirvar(i);
		// powmod(x, tmp, p, tmp1);
		// multiply(tmp1, coef[i], tmp1);
		// add(ret, tmp1, ret);
	}
	powmod(ret, one, p, ret);
	return ret;
}


/* 
 * 根据收集到的子秘密，进行重构，通过拉格朗日插值定理求解
 * 根据多个秘密使用拉格朗日插值公式重构秘密
 * f(x) = \\sum_{j=0}^{n-1}f(x_j)\\prod_{i \ne j} \frac{x_{i}-x}{x_{i}-x_{j}}
 * f(0) = \\sum_{j=0}^{t}f(x_j)\\prod_{i \ne j} \frac{x_{i}}{x_{i}-x_{j}}
 */
big reconstruct(int t, big p, big *k, big *d)
{
	big ret = mirvar(0), one = mirvar(1), tmp, tmp1 = mirvar(0);

	for (size_t i = 0; i < t; i++)
	{
		tmp = mirvar(1);
		for (size_t j = 0; j < t; j++)
		{
			if (i == j)
				continue;
			subtract(d[j], d[i], tmp1);
			xgcd(tmp1, p, tmp1, tmp1, tmp1);

			multiply(tmp1, d[j], tmp1);
			multiply(tmp, tmp1, tmp);
			powmod(tmp, one, p, tmp);
		}

		multiply(tmp, k[i], tmp);
		add(ret, tmp, ret);
	}
	powmod(ret, one, p, ret);
	return ret;
}


big datadivide(big data, big p, big secret){
	big ret = mirvar(0), one = mirvar(1);

	xgcd(secret, p, secret, secret, secret);
	powmod(data, secret, p, ret);
	return ret;
}



int main()
{
	miracl *mip = mirsys(500, 0); // 大数运算必须以mirsys开始，结束时mirexit
	irand(time(NULL));			  // 初始化内部随机数系统
	big coef[T];				  // 存放多项式系数
	big k[N], d[N];				  // d存放的是随机数，k存放的是对应d中随机数代入多项式得到的值，也即是分割后的子秘密份额
	big p = generatebigprime(P_SIZE);	//生成一个P_SIZE位的大素数
	big tmp = mirvar(0), one = mirvar(1);

	printf("p is:");
	cotnum(p, stdout);
	generatepoly(T, p, coef); //生成多项式
	
	for (size_t i = 0; i < N; i++) // 这将生成n个小于p的随机数
	{
		d[i] = mirvar(0);
		bigdig(RAND_SIZE, 10, tmp);
		powmod(tmp, one, p, d[i]);
	}
	for (size_t i = 0; i < N; i++) // 这将生成n个秘密值
	{
		k[i] = mirvar(0);
		k[i] = generateshare(d[i], p, coef);
	}

	tmp = reconstruct(T, p, k, d);

	printf("reconstruct is:");
	cotnum(tmp, stdout);
	printf("original is:");
	cotnum(coef[T - 1], stdout);


	if (mr_compare(tmp, coef[T - 1]) == 0)
	{
		printf("成功恢复秘密\n");
	}
	else
	{
		printf("秘密恢复失败\n");
	}

	mirexit();

	return 0;
}
