/*
 * @Author: ck
 * @Date: 2023-09-25 03:06:53
 * @LastEditors: ck
 * @LastEditTime: 2023-09-27 00:19:59
 * @FilePath: /mimademov1/src/test20 copy.cpp
 * @Description:
 *
 * Copyright (c) 2023 by ${git_name_email}, All Rights Reserved.
 */
#include <iostream>
#include <openssl/bn.h>
#include <openssl/evp.h>
#include <string>
#include <cstring>
#include <sstream>
#include <iomanip>

#include <openssl/evp.h>
#include <openssl/sha.h>
#include <openssl/rand.h>
#include <iostream>
#include <string>
#include <cstring>
using namespace std;

int main()
{
    BIGNUM *a = BN_new();

    BN_dec2bn(&a, "1234");
    cout << "first time :" << BN_bn2dec(a) << endl;

    BN_free(a);
    cout << "second time :" << BN_bn2dec(a) << endl;
    a = BN_new();
    BN_dec2bn(&a, "5678");
    cout << "second time :" << BN_bn2dec(a) << endl;
    BN_free(a);
    return 0;
}
