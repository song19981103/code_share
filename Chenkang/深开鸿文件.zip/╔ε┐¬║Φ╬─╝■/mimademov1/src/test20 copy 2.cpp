#include <iostream>
#include <openssl/bn.h>
#include <openssl/sha.h>
#include <openssl/evp.h>
#include <string>
#include <cstring>
#include <sstream>
#include <iomanip>

#include <miracl/secretsplit.h>

using namespace std;

int main()
{
    BIGNUM *bigNum = BN_new();
    string myinput;
    cin >> myinput;
    BN_dec2bn(&bigNum, myinput.data()); // 十进制输入转为大数

    /* 分割密钥 sk = sk1 || sk2*/
    string part1, part2;
    splitBigInt(bigNum, part1, part2); // 大数转为字符串后均等分割为两部分

    cout << "Part 1: " << part1 << endl;
    cout << "Part 2: " << part2 << endl;
    unsigned char *ciphertext = nullptr;
    int ciphertextLength = 0;

    string part1hash = hashStringToFixedLength(part1);//转为固定长度的密钥，与后续加解密中位数对应
    /* 加密部分密钥并解密测试 Enc_{sk1}(sk2) */
    anyLengthKeyEnc(part1hash.data(), part1hash.size(), part2.data(), part2.size(), &ciphertext, &ciphertextLength);
    // anyLengthKeyEnc(key, strlen(key), part2.data(), part2.size(), &ciphertext, &ciphertextLength);

    myinput = stringToHex(ciphertext, strlen((const char *)ciphertext));
    cout << "the ciphertext hex is:" << myinput << endl;
    cout << "the ciphertext is:" << ciphertext << endl;
    unsigned char *decryptedText = nullptr;
    int decryptedTextLength = 0;
    // anyLengthKeyDec(key, strlen(key), (const char *)ciphertext, ciphertextLength, &decryptedText, &decryptedTextLength);
    anyLengthKeyDec(part1hash.data(), part1hash.size(), (const char *)ciphertext, ciphertextLength, &decryptedText, &decryptedTextLength);
    cout << "the plaintext is:" << decryptedText << endl;

    /* 计算异或 Enc_{sk1}(sk2) ⊕ sk1 留存本地*/
    BIGNUM *part1_BN = BN_new();
    BIGNUM *share_BN = BN_new();
    BIGNUM *cipher_bignum = BN_new();

    string testoutput;

    BN_hex2bn(&part1_BN, part1.data());
    BN_hex2bn(&cipher_bignum, myinput.data());
    xorBIGNUM(part1_BN, cipher_bignum, share_BN);

    testoutput = BN_bn2hex(share_BN);
    cout << "the share part is:" << testoutput << endl;

    /* 解密过程 */
    BIGNUM *plain_bignum = BN_new();
    xorBIGNUM(share_BN, cipher_bignum, plain_bignum); // 计算出sk1
    string sk1, cipher_str, sk22;
    sk1 = BN_bn2hex(part1_BN);
    cout << "the sk1 bignum:" << sk1 << endl;
    cipher_str = hexToString(BN_bn2hex(cipher_bignum));

    decryptedText = nullptr;
    decryptedTextLength = 0;

    anyLengthKeyDec(part1hash.data(), part1hash.size(), cipher_str.data(), cipher_str.size(), &decryptedText, &decryptedTextLength);

    cout << "the ciphertext is:" << cipher_str << endl;
    cout << "the message is:" << decryptedText << endl;

    string sk11 = hashStringToFixedLength(sk1);
    anyLengthKeyDec(sk11.data(), sk11.size(), cipher_str.data(), cipher_str.size(), &decryptedText, &decryptedTextLength);

    cout << "the ciphertext1 is:" << cipher_str << endl;
    cout << "the message1 is:" << decryptedText << endl;

    if (sk11.compare(part1hash) == 0)
    {
        cout << "the same string " << endl;
    }
    else
    {
        cout << "different" << endl;
    }

    BN_free(bigNum);

    return 0;
}
