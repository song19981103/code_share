#include <iostream>
#include <openssl/bn.h>
#include <openssl/sha.h>
#include <openssl/evp.h>
#include <string>
#include <cstring>
#include <sstream>
#include <iomanip>
using namespace std;

void splitBigInt(const BIGNUM *bigNum, string &part1, string &part2)
{
    // 将大数转换为十进制字符串
    string bigNumStr = BN_bn2hex(bigNum);

    // 检查字符串长度是否为奇数
    if (bigNumStr.size() % 2)
    {
        bigNumStr.push_back('0');
    }

    // 计算均分点
    size_t splitPoint = bigNumStr.size() / 2;

    // 分割字符串
    part1.assign(bigNumStr, 0, splitPoint);
    part2.assign(bigNumStr, splitPoint, bigNumStr.size());
}

bool anyLengthKeyEnc(const char *key, int keyLength, const char *plaintext, int plaintextLength, unsigned char **ciphertext, int *ciphertextLength)
{
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();

    // 选择加密算法和模式
    const EVP_CIPHER *cipher = EVP_aes_256_cbc(); // 选择AES-256-CBC加密算法
    int blockSize = EVP_CIPHER_block_size(cipher);

    // 初始化加密上下文
    EVP_EncryptInit_ex(ctx, cipher, NULL, (const unsigned char *)key, NULL);

    // 分配足够的内存来保存加密后的数据
    *ciphertext = new unsigned char[plaintextLength + blockSize];
    memset(*ciphertext, 0, plaintextLength + blockSize);

    // 执行加密
    int updateLength = 0;
    EVP_EncryptUpdate(ctx, *ciphertext, &updateLength, (const unsigned char *)plaintext, plaintextLength);
    *ciphertextLength = updateLength;

    // 结束加密
    int finalLength = 0;
    EVP_EncryptFinal_ex(ctx, *ciphertext + updateLength, &finalLength);
    *ciphertextLength += finalLength;

    EVP_CIPHER_CTX_free(ctx);

    return true;
}

// 解密函数
bool anyLengthKeyDec(const char *key, int keyLength, const char *ciphertext, int ciphertextLength, unsigned char **plaintext, int *plaintextLength)
{
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();

    // 选择解密算法和模式
    const EVP_CIPHER *cipher = EVP_aes_256_cbc(); // 选择AES-256-CBC解密算法
    int blockSize = EVP_CIPHER_block_size(cipher);

    // 初始化解密上下文
    EVP_DecryptInit_ex(ctx, cipher, NULL, (const unsigned char *)key, NULL);

    // 分配足够的内存来保存解密后的数据
    *plaintext = new unsigned char[ciphertextLength];
    memset(*plaintext, 0, ciphertextLength);

    // 执行解密
    int updateLength = 0;
    EVP_DecryptUpdate(ctx, *plaintext, &updateLength, (const unsigned char *)ciphertext, ciphertextLength);
    *plaintextLength = updateLength;

    // 结束解密
    int finalLength = 0;
    EVP_DecryptFinal_ex(ctx, *plaintext + updateLength, &finalLength);
    *plaintextLength += finalLength;

    EVP_CIPHER_CTX_free(ctx);

    return true;
}

string stringToHex(const unsigned char *byteArray, size_t length)
{
    stringstream hexStream;

    for (size_t i = 0; i < length; ++i)
    {
        hexStream << hex << setw(2) << setfill('0') << static_cast<int>(byteArray[i]);
    }

    return hexStream.str();
}

string hexToString(const string &hex)
{
    string result;
    for (size_t i = 0; i < hex.length(); i += 2)
    {
        // 从十六进制字符串中提取两个字符
        string byteString = hex.substr(i, 2);

        // 将提取的字符转换为整数
        unsigned char byte = static_cast<unsigned char>(stoi(byteString, nullptr, 16));

        // 将整数转换为字符并追加到结果字符串
        result.push_back(static_cast<char>(byte));
    }
    return result;
}

void xorBIGNUM(const BIGNUM *a, const BIGNUM *b, BIGNUM *result)
{
    // 获取a和b的字节数组表示
    const int a_bytes = BN_num_bytes(a);
    const int b_bytes = BN_num_bytes(b);
    unsigned char *b_data, *a_data;

    // 确保result足够大来存储异或结果
    const int max_bytes = a_bytes > b_bytes ? a_bytes : b_bytes;
    unsigned char *result_data = (unsigned char *)OPENSSL_malloc(max_bytes);
    b_data = (unsigned char *)OPENSSL_malloc(max_bytes);
    a_data = (unsigned char *)OPENSSL_malloc(max_bytes);

    BN_bn2binpad(a, a_data, max_bytes); // 输出大数二进制，不足的高位补0
    BN_bn2binpad(b, b_data, max_bytes); // 输出大数二进制，不足的高位补0

    // 执行异或操作
    for (int i = 0; i < max_bytes; ++i)
    {
        result_data[i] = a_data[i] ^ b_data[i];
    }

    // 将结果设置为BIGNUM对象
    BN_bin2bn(result_data, max_bytes, result);

    // 释放内存
    OPENSSL_free(a_data);
    OPENSSL_free(b_data);
    OPENSSL_free(result_data);
}

// 将字符串哈希为固定位数的数字（SHA-256）与后续的加解密对应，否则会出错
string hashStringToFixedLength(const string &input)
{
    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256_CTX sha256;
    SHA256_Init(&sha256);
    SHA256_Update(&sha256, input.c_str(), input.size());
    SHA256_Final(hash, &sha256);

    string ret(reinterpret_cast<char *>(hash), 32);
    return ret;
}

int main()
{
    BIGNUM *bigNum = BN_new();
    string myinput;
    cin >> myinput;
    BN_dec2bn(&bigNum, myinput.data()); // 十进制输入转为大数

    /* 分割密钥 sk = sk1 || sk2*/
    string part1, part2;
    splitBigInt(bigNum, part1, part2); // 大数转为字符串后均等分割为两部分

    cout << "Part 1: " << part1 << endl;
    cout << "Part 2: " << part2 << endl;
    unsigned char *ciphertext = nullptr;
    int ciphertextLength = 0;

    string part1hash = hashStringToFixedLength(part1);//转为固定长度的密钥，与后续加解密中位数对应
    /* 加密部分密钥并解密测试 Enc_{sk1}(sk2) */
    anyLengthKeyEnc(part1hash.data(), part1hash.size(), part2.data(), part2.size(), &ciphertext, &ciphertextLength);
    // anyLengthKeyEnc(key, strlen(key), part2.data(), part2.size(), &ciphertext, &ciphertextLength);

    myinput = stringToHex(ciphertext, strlen((const char *)ciphertext));
    cout << "the ciphertext hex is:" << myinput << endl;
    cout << "the ciphertext is:" << ciphertext << endl;
    unsigned char *decryptedText = nullptr;
    int decryptedTextLength = 0;
    // anyLengthKeyDec(key, strlen(key), (const char *)ciphertext, ciphertextLength, &decryptedText, &decryptedTextLength);
    anyLengthKeyDec(part1hash.data(), part1hash.size(), (const char *)ciphertext, ciphertextLength, &decryptedText, &decryptedTextLength);
    cout << "the plaintext is:" << decryptedText << endl;

    /* 计算异或 Enc_{sk1}(sk2) ⊕ sk1 留存本地*/
    BIGNUM *part1_BN = BN_new();
    BIGNUM *share_BN = BN_new();
    BIGNUM *cipher_bignum = BN_new();

    string testoutput;

    BN_hex2bn(&part1_BN, part1.data());
    BN_hex2bn(&cipher_bignum, myinput.data());
    xorBIGNUM(part1_BN, cipher_bignum, share_BN);

    testoutput = BN_bn2hex(share_BN);
    cout << "the share part is:" << testoutput << endl;

    /* 解密过程 */
    BIGNUM *plain_bignum = BN_new();
    xorBIGNUM(share_BN, cipher_bignum, plain_bignum); // 计算出sk1
    string sk1, cipher_str, sk22;
    sk1 = BN_bn2hex(part1_BN);
    cout << "the sk1 bignum:" << sk1 << endl;
    cipher_str = hexToString(BN_bn2hex(cipher_bignum));

    decryptedText = nullptr;
    decryptedTextLength = 0;

    anyLengthKeyDec(part1hash.data(), part1hash.size(), cipher_str.data(), cipher_str.size(), &decryptedText, &decryptedTextLength);

    cout << "the ciphertext is:" << cipher_str << endl;
    cout << "the message is:" << decryptedText << endl;

    string sk11 = hashStringToFixedLength(sk1);
    anyLengthKeyDec(sk11.data(), sk11.size(), cipher_str.data(), cipher_str.size(), &decryptedText, &decryptedTextLength);

    cout << "the ciphertext1 is:" << cipher_str << endl;
    cout << "the message1 is:" << decryptedText << endl;

    if (sk11.compare(part1hash) == 0)
    {
        cout << "the same string " << endl;
    }
    else
    {
        cout << "different" << endl;
    }

    BN_free(bigNum);

    return 0;
}
