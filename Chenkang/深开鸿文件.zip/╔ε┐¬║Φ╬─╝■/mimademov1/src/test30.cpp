/*
 * @Author: ck
 * @Date: 2023-09-24 18:28:34
 * @LastEditors: ck
 * @LastEditTime: 2023-09-28 00:26:57
 * @FilePath: /mimademov1/src/test30.cpp
 * @Description:
 *
 * Copyright (c) 2023 by ${git_name_email}, All Rights Reserved.
 */
#include <iostream>
#include <openssl/rsa.h>
#include <openssl/pem.h>
#include <miracl/miracl.h>
#include <miracl/secretsplit.h>
#include <vector>

#include <cstring>

using namespace std;

int main()
{
    OpenSSL_add_all_algorithms();
    string a, b;

    BIGNUM *bigtest = BN_new();

    BN_hex2bn(&bigtest, "12345");
    splitBigInt(bigtest, a, b);

    cout << "a:" << a << endl;
    cout << "b:" << b << endl;
    return 0;
}
