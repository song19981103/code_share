/*
 * @Author: ck
 * @Date: 2023-09-07 18:50:11
 * @LastEditors: ck
 * @LastEditTime: 2023-09-26 02:35:51
 * @FilePath: /mimademov1/src/test1.cpp
 * @Description:
 *
 * Copyright (c) 2023 by ${git_name_email}, All Rights Reserved.
 */
#include "miracl/miracl.h"
#include "miracl/func.h"

#include <iostream>
#include <thread>
#include <chrono>
#include <cstring>
#include <chrono>
#include <stdio.h>
#include <vector>
#include <sstream>
#include <iomanip>

#include <openssl/ec.h>
#include <openssl/obj_mac.h>
#include <openssl/err.h>
#include <openssl/evp.h>
#include <openssl/sha.h>
#include <openssl/rand.h>

bool anyLengthKeyEnc(const char *key, int keyLength, const char *plaintext, int plaintextLength, unsigned char **ciphertext, int *ciphertextLength)
{
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();

    // 选择加密算法和模式
    const EVP_CIPHER *cipher = EVP_aes_256_cbc(); // 选择AES-256-CBC加密算法
    int blockSize = EVP_CIPHER_block_size(cipher);

    // 初始化加密上下文
    EVP_EncryptInit_ex(ctx, cipher, NULL, (const unsigned char *)key, NULL);

    // 分配足够的内存来保存加密后的数据
    *ciphertext = new unsigned char[plaintextLength + blockSize];
    memset(*ciphertext, 0, plaintextLength + blockSize);

    // 执行加密
    int updateLength = 0;
    EVP_EncryptUpdate(ctx, *ciphertext, &updateLength, (const unsigned char *)plaintext, plaintextLength);
    *ciphertextLength = updateLength;

    // 结束加密
    int finalLength = 0;
    EVP_EncryptFinal_ex(ctx, *ciphertext + updateLength, &finalLength);
    *ciphertextLength += finalLength;

    EVP_CIPHER_CTX_free(ctx);

    return true;
}

// 解密函数
bool anyLengthKeyDec(const char *key, int keyLength, unsigned char *ciphertext, int ciphertextLength, unsigned char **plaintext, int *plaintextLength)
{
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();

    // 选择解密算法和模式
    const EVP_CIPHER *cipher = EVP_aes_256_cbc(); // 选择AES-256-CBC解密算法
    int blockSize = EVP_CIPHER_block_size(cipher);

    // 初始化解密上下文
    EVP_DecryptInit_ex(ctx, cipher, NULL, (const unsigned char *)key, NULL);

    // 分配足够的内存来保存解密后的数据
    *plaintext = new unsigned char[ciphertextLength];
    memset(*plaintext, 0, ciphertextLength);

    // 执行解密
    int updateLength = 0;
    EVP_DecryptUpdate(ctx, *plaintext, &updateLength, (const unsigned char *)ciphertext, ciphertextLength);
    *plaintextLength = updateLength;

    // 结束解密
    int finalLength = 0;
    EVP_DecryptFinal_ex(ctx, *plaintext + updateLength, &finalLength);
    *plaintextLength += finalLength;

    EVP_CIPHER_CTX_free(ctx);

    return true;
}

int main()
{
    // 初始化 OpenSSL 库
    OpenSSL_add_all_algorithms();
    ERR_load_crypto_strings();

    string key = "123456";
    string plaintext = "789012";

    const char * k11 = "12345";
    const char *k22= "12345";

    unsigned char *ciphertext = nullptr;
    int ciphertextLength = 0;

    const char *keytest1 = key.data();
    const char *plaintexttest1 = plaintext.data();
    anyLengthKeyEnc(keytest1, strlen(keytest1), plaintexttest1, strlen(plaintexttest1), &ciphertext, &ciphertextLength);

    cout << "the ciphertext is : " << ciphertext << endl;

    unsigned char *decplain1 = nullptr;
    int decplain1Length = 0;
    anyLengthKeyDec(keytest1, strlen(keytest1), ciphertext, ciphertextLength, &decplain1, &decplain1Length);
    cout << "the plaintext1 is : " << decplain1;

    string key1 = "123456";
    const char *key1test1 = key1.data();

    cout << "keytest1" << strlen(keytest1)<<endl;
    cout << "key1test1" << strlen(key1test1)<<endl;
    unsigned char *decplain2 = nullptr;
    int decplain2Length = 0;
    anyLengthKeyDec(key1test1, strlen(key1test1), ciphertext, ciphertextLength, &decplain2, &decplain2Length);
    
    cout << decplain1Length << endl;

    cout << strlen((const char*)decplain1) << endl;
    cout << decplain2Length << endl;

    cout << strlen((const char*)decplain2) << endl;
    // cout << "the plaintext2 is : " << decplain2;
    return 0;
}
