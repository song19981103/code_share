#include <iomanip>

#include <openssl/ec.h>
#include <openssl/obj_mac.h>
#include <openssl/err.h>
#include <openssl/evp.h>
#include <openssl/sha.h>

/**
 * @description: 生成message的hash值然后转为字符串
 * @return {*}
 */
string generateHash(const string &message)
{
	unsigned char hash[SHA256_DIGEST_LENGTH];
	SHA256_CTX sha256;
	SHA256_Init(&sha256);
	SHA256_Update(&sha256, message.c_str(), message.length());
	SHA256_Final(hash, &sha256);

	stringstream ss;
	for (int i = 0; i < SHA256_DIGEST_LENGTH; ++i)
	{
		ss << hex << setw(2) << setfill('0') << static_cast<int>(hash[i]);
	}

	return ss.str();
}

/**
 * @description: 字符串转16进制字符串
 * @param {unsigned char} *byteArra， 原始字符串
 * @param {size_t} length，字符串长度
 * @return {*}
 */
string stringToHex(const unsigned char *byteArray, size_t length)
{
	stringstream hexStream;

	for (size_t i = 0; i < length; ++i)
	{
		hexStream << hex << setw(2) << setfill('0') << static_cast<int>(byteArray[i]);
	}

	return hexStream.str();
}

/**
 * @description: 生成公私钥对
 * @param {EC_GROUP} *curve，椭圆曲线
 * @param {EC_POINT} *G，椭圆曲线的生成点
 * @return {*} 返回公私钥对
 */
pair<const BIGNUM *, const EC_POINT *> generateKeyPair(EC_KEY *ec_key)
{
	const EC_GROUP *curve = EC_KEY_get0_group(ec_key); // 椭圆曲线群
	const EC_POINT *G = EC_GROUP_get0_generator(curve); // 生成点G
	BN_CTX *ctx = BN_CTX_new();//大数运算的辅助变量

	// 生成随机私钥
	if (!EC_KEY_generate_key(ec_key))
	{
		cerr << "生成随机私钥出错" << endl;
		return make_pair(nullptr, nullptr);
	}

	// 获取私钥，本处椭圆曲线包含了公私钥，实际中可以选用随机数为私钥，通过点乘得到公钥
	const BIGNUM *private_key = EC_KEY_get0_private_key(ec_key);
	cout << "椭圆曲线私钥为: " << BN_bn2dec(private_key) << endl;

	const EC_POINT *public_key = EC_KEY_get0_public_key(ec_key); 
	return make_pair(private_key, public_key);
}

/**
 * @description: 根据消息和私钥生成非交互的签名
 * @param {string} &message，消息
 * @param {EC_GROUP} *curve，椭圆曲线
 * @param {BIGNUM} *private_key，私钥
 * @return {*}，返回（c,z）签名数对用于其他设备根据公钥验签
 */
pair<BIGNUM *, BIGNUM *> signature(string &message, EC_KEY *ec_key, const BIGNUM *private_key)
{
	BN_CTX *ctx = BN_CTX_new(); //大数运算的辅助变量
	const EC_GROUP *curve = EC_KEY_get0_group(ec_key); //椭圆曲线的群
	const EC_POINT *G = EC_GROUP_get0_generator(curve); // 生成点G

	// 生成随机数r，计算R，即r * 原点 G
	BIGNUM *random_number = BN_new();
	if (!BN_rand(random_number, 256, -1, 0))
	{ // 生成一个随机正整数数，256位长
		cerr << "生成随机数出错" << endl;
		return make_pair(nullptr, nullptr);
	}
	cout << "选取的随机数r : " << BN_bn2dec(random_number) << endl;

	// 创建结果R
	EC_POINT *result_point = EC_POINT_new(curve);
	// 执行随机数r与原点 G 的乘法操作
	if (!EC_POINT_mul(curve, result_point, random_number, G, NULL, ctx))
	{
		cerr << "椭圆曲线的点乘出错" << endl;
		return make_pair(nullptr, nullptr);
	}
	ctx = BN_CTX_new();

	BIGNUM *x = BN_new();
	BIGNUM *y = BN_new();
	EC_POINT_get_affine_coordinates_GFp(EC_KEY_get0_group(ec_key), result_point, x, y, NULL);
	cout << "椭圆曲线点R的横坐标x : " << BN_bn2dec(x) << endl;
	cout << "椭圆曲线点R的纵坐标y : " << BN_bn2dec(y) << endl;

	// 生成Hash(m, R)
	SHA256_CTX sha256Context;
	SHA256_Init(&sha256Context);

	SHA256_Update(&sha256Context, message.data(), message.size());

	// 转化椭圆曲线上的点为字节数组然后进行hash
	size_t len = EC_POINT_point2oct(curve, result_point, POINT_CONVERSION_UNCOMPRESSED, NULL, 0, NULL);
	unsigned char *buffer = (unsigned char *)malloc(len);

	// 将 EC_POINT 转换为字节数组
	EC_POINT_point2oct(curve, result_point, POINT_CONVERSION_UNCOMPRESSED, buffer, len, NULL);

	SHA256_Update(&sha256Context, buffer, len);

	// 计算哈希值
	unsigned char hash[SHA256_DIGEST_LENGTH];
	SHA256_Final(hash, &sha256Context);
	string hash_hex;
	hash_hex = stringToHex(hash, SHA256_DIGEST_LENGTH);

	// 计算z， z = r + c*sk
	BIGNUM *z = BN_new();
	BIGNUM *big_tmp1 = BN_new();
	BIGNUM *c = BN_new();
	BN_hex2bn(&c, hash_hex.data());

	cout << "生成的值c:" << BN_bn2dec(c) << endl;

	BN_mul(big_tmp1, c, private_key, ctx);
	ctx = BN_CTX_new();
	BN_add(z, big_tmp1, random_number);
	return make_pair(c, z);
}

/**
 * @description: 对消息验签
 * @param {string} &message，消息
 * @param {EC_GROUP} *curve，椭圆曲线
 * @param {EC_POINT} *public_key，公钥
 * @param {BIGNUM} *c，签名中的hash值
 * @param {BIGNUM} *z，签名中计算出来的数
 * @return {*}，返回1表示验签通过，返回0表示不通过或者出错
 */
int validation(string &message, EC_KEY *ec_key, const EC_POINT *public_key, BIGNUM *c,
			   BIGNUM *z)
{
	BN_CTX *ctx = BN_CTX_new();							// 辅助变量，用于椭圆曲线乘法
	const EC_GROUP *curve = EC_KEY_get0_group(ec_key);	// 椭圆曲线的群
	const EC_POINT *G = EC_GROUP_get0_generator(curve); // 生成点G

	// R' = z * G - c * Pk
	// 创建结果R'以及两个临时变量
	EC_POINT *result_point_valid = EC_POINT_new(curve);
	EC_POINT *result_point_tmp1 = EC_POINT_new(curve);
	EC_POINT *result_point_tmp2 = EC_POINT_new(curve);

	// 执行z与原点 G 的乘法操作
	if (!EC_POINT_mul(curve, result_point_tmp1, z, G, NULL, NULL)) // 调用椭圆曲线点乘G的常数位置注意！！！！
	{
		cerr << "椭圆曲线上点乘计算出错" << endl;
		return 0;
	}

	// 执行c与Pk 的乘法操作
	if (!EC_POINT_mul(curve, result_point_tmp2, nullptr, public_key, c, ctx)) // 调用椭圆曲线点乘任意点的常数位置注意！！！！
	{
		cerr << "椭圆曲线上点乘计算出错" << endl;
		return 0;
	}
	ctx = BN_CTX_new();

	// 负号取逆 -c*Pk
	if (!EC_POINT_invert(curve, result_point_tmp2, NULL))
	{
		// 错误处理
		EC_POINT_free(result_point_tmp2);
		return 0;
	}

	// 求和得到R'
	EC_POINT_add(curve, result_point_valid, result_point_tmp1, result_point_tmp2, NULL);

	// 获取R' 的坐标，转化为字符串后和消息m一起计算hash值 // c = Hash(m, R')
	BIGNUM *x = BN_new();
	BIGNUM *y = BN_new();
	EC_POINT_get_affine_coordinates_GFp(EC_KEY_get0_group(ec_key), result_point_valid, x, y, NULL);
	cout << "R' x : " << BN_bn2dec(x) << endl;
	cout << "R' y : " << BN_bn2dec(y) << endl;

	// 计算消息的hash值
	SHA256_CTX sha256Context1;
	SHA256_Init(&sha256Context1);
	SHA256_Update(&sha256Context1, message.data(), message.size());
	// 转化椭圆曲线的点的hash值
	size_t len1 = EC_POINT_point2oct(curve, result_point_valid, POINT_CONVERSION_UNCOMPRESSED, NULL, 0, NULL);
	unsigned char *buffer1 = (unsigned char *)malloc(len1);
	EC_POINT_point2oct(curve, result_point_valid, POINT_CONVERSION_UNCOMPRESSED, buffer1, len1, NULL);
	SHA256_Update(&sha256Context1, buffer1, len1);

	// 计算哈希值
	unsigned char hash1[SHA256_DIGEST_LENGTH];
	SHA256_Final(hash1, &sha256Context1);

	// 将hash值转为16进制字符串,然后转为大数后比较
	string hash_hex1;
	hash_hex1 = stringToHex(hash1, SHA256_DIGEST_LENGTH);
	BIGNUM *c1 = BN_new();
	BN_hex2bn(&c1, hash_hex1.data());
	int result = BN_cmp(c1, c);
	if (result)
		return 0; // 不等，验签失败
	else
		return 1; // 相等，验签正确
}

/**
 * @description: 将带有分割符的字符串分割
 * @param {string&} input， 字符串
 * @param {char} delimiter，分割符
 * @return {*}
 */
vector<string> splitString(const string &input, char delimiter)
{
	vector<string> parts;
	string part;
	istringstream iss(input);

	while (getline(iss, part, delimiter))
	{
		parts.push_back(part);
	}

	return parts;
}

/**
 * @description: 将两个大数转为字符串连接起来
 * @param {BIGNUM} *x
 * @param {BIGNUM} *y
 * @return {*}
 */
string big_Pair_to_str(BIGNUM *x, BIGNUM *y)
{
	string ret = "";

	ret += BN_bn2hex(x);
	ret += ",";
	ret += BN_bn2hex(y);
	return ret;
}

/**
 * @description: 椭圆曲线的点转为字符串
 * @param {EC_GROUP} *curve，椭圆曲线
 * @param {EC_POINT} *public_key，椭圆曲线上的点
 * @return {*}
 */
string eccPoint_to_str(const EC_GROUP *curve, const EC_POINT *public_key)
{
	BIGNUM *x = BN_new();
	BIGNUM *y = BN_new();

	EC_POINT_get_affine_coordinates_GFp(curve, public_key, x, y, NULL);

	return big_Pair_to_str(x, y);
}

/**
 * @description: 坐标字符串转为椭圆曲线上的点
 * @param {EC_KEY} *ec_key， 椭圆曲线
 * @param {string} point_x，椭圆曲线点的横坐标字符串
 * @param {string} point_y，椭圆曲线点的纵坐标字符串
 * @return {*}
 */
EC_POINT *str_to_eccPoint(EC_KEY *ec_key, string point_x, string point_y)
{
	BIGNUM *x = BN_new();
	BIGNUM *y = BN_new();

	EC_POINT *ec_point = EC_POINT_new(EC_KEY_get0_group(ec_key)); // 创建椭圆曲线点
	if (!ec_point)
	{
		std::cerr << "创建椭圆曲线点出错" << std::endl;
		EC_KEY_free(ec_key);
		return nullptr;
	}

	if (!BN_hex2bn(&x, point_x.data())) // 获取椭圆曲线点横坐标
	{
		std::cerr << "获取椭圆曲线点横坐标出错" << std::endl;
		EC_POINT_free(ec_point);
		EC_KEY_free(ec_key);
		return nullptr;
	}
	if (!BN_hex2bn(&y, point_y.data())) // 获取椭圆曲线点纵坐标
	{
		std::cerr << "获取椭圆曲线点纵坐标出错" << std::endl;
		EC_POINT_free(ec_point);
		EC_KEY_free(ec_key);
		return nullptr;
	}

	// 设置椭圆曲线点
	if (!EC_POINT_set_affine_coordinates_GFp(EC_KEY_get0_group(ec_key), ec_point, x, y, NULL))
	{
		std::cerr << "设置椭圆曲线点出错" << std::endl;
		EC_POINT_free(ec_point);
		EC_KEY_free(ec_key);
		return nullptr;
	}

	return ec_point;
}
