#include <iostream>
#include <openssl/bn.h>
#include <openssl/sha.h>
#include <openssl/evp.h>
#include <string>
#include <cstring>
#include <sstream>
#include <iomanip>

using namespace std;

/**
 * @description: 将一个大数转为16进制字符串后，均等分成两部分，
 * @param {BIGNUM} *bigNum
 * @param {string} &part1
 * @param {string} &part2
 * @return {*}
 */
void splitBigInt(const BIGNUM *bigNum, string &part1, string &part2)
{
    // 将大数转换为16进制字符串
    string bigNumStr = BN_bn2hex(bigNum);

    // 检查字符串长度是否为奇数, 若是则添前方添0
    if (bigNumStr.size() % 2)
    {
        bigNumStr = "0" + bigNumStr;
        // bigNumStr.push_back('0');
    }

    // 计算均分点
    size_t splitPoint = bigNumStr.size() / 2;

    // 分割字符串
    part1.assign(bigNumStr, 0, splitPoint);
    part2.assign(bigNumStr, splitPoint, bigNumStr.size());

    BIGNUM *tmp_big = BN_new(); // 由于输入的完整密钥的字符串长度为奇数，需要重新计算
    BN_hex2bn(&tmp_big, part1.data());
    part1 = BN_bn2hex(tmp_big);
    BN_free(tmp_big);
}

/**
 * @description: 选用256位的密钥加密明文（内部加密算法以及密钥位数可以调整，但要对应上）
 * @param {char} *key 密钥字符串
 * @param {int} keyLength 密钥长度
 * @param {char} *plaintext 明文字符串
 * @param {int} plaintextLength 明文长度
 * @param {unsigned char} **ciphertext 存储密文的位置
 * @param {int} *ciphertextLength 存储密文长度的位置
 * @return {*} 返回加密成功与否
 */
bool anyLengthKeyEnc(const char *key, int keyLength, const char *plaintext, int plaintextLength, unsigned char **ciphertext, int *ciphertextLength)
{
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();

    // 选择加密算法和模式
    const EVP_CIPHER *cipher = EVP_aes_256_cbc(); // 选择AES-256-CBC加密算法
    int blockSize = EVP_CIPHER_block_size(cipher);

    // 初始化加密上下文
    EVP_EncryptInit_ex(ctx, cipher, NULL, (const unsigned char *)key, NULL);

    // 分配足够的内存来保存加密后的数据
    *ciphertext = new unsigned char[plaintextLength + blockSize];
    memset(*ciphertext, 0, plaintextLength + blockSize);

    // 执行加密
    int updateLength = 0;
    EVP_EncryptUpdate(ctx, *ciphertext, &updateLength, (const unsigned char *)plaintext, plaintextLength);
    *ciphertextLength = updateLength;

    // 结束加密
    int finalLength = 0;
    EVP_EncryptFinal_ex(ctx, *ciphertext + updateLength, &finalLength);
    *ciphertextLength += finalLength;

    EVP_CIPHER_CTX_free(ctx);

    return true;
}

/**
 * @description: 选用256位的密钥解密密文与 anyLengthKeyEnc函数对应
 * @param {char} *key 密钥字符串
 * @param {int} keyLength 密钥长度
 * @param {char} *ciphertext 密文字符串
 * @param {int} ciphertextLength 密文长度
 * @param {unsigned char} **ciphertext 存储明文的位置
 * @param {int} *plaintextLength 存储明文长度的位置
 * @return {*}
 */
bool anyLengthKeyDec(const char *key, int keyLength, const char *ciphertext, int ciphertextLength, unsigned char **plaintext, int *plaintextLength)
{
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();

    // 选择解密算法和模式
    const EVP_CIPHER *cipher = EVP_aes_256_cbc(); // 选择AES-256-CBC解密算法
    int blockSize = EVP_CIPHER_block_size(cipher);

    // 初始化解密上下文
    EVP_DecryptInit_ex(ctx, cipher, NULL, (const unsigned char *)key, NULL);

    // 分配足够的内存来保存解密后的数据
    *plaintext = new unsigned char[ciphertextLength];
    memset(*plaintext, 0, ciphertextLength);

    // 执行解密
    int updateLength = 0;
    EVP_DecryptUpdate(ctx, *plaintext, &updateLength, (const unsigned char *)ciphertext, ciphertextLength);
    *plaintextLength = updateLength;

    // 结束解密
    int finalLength = 0;
    EVP_DecryptFinal_ex(ctx, *plaintext + updateLength, &finalLength);
    *plaintextLength += finalLength;

    EVP_CIPHER_CTX_free(ctx);

    return true;
}

/**
 * @description: 将16进制转为字符串
 * @param {string} &hex
 * @return {*}
 */
string hexToString(const string &hex)
{
    string result;
    for (size_t i = 0; i < hex.length(); i += 2)
    {
        // 从十六进制字符串中提取两个字符
        string byteString = hex.substr(i, 2);

        // 将提取的字符转换为整数
        unsigned char byte = static_cast<unsigned char>(stoi(byteString, nullptr, 16));

        // 将整数转换为字符并追加到结果字符串
        result.push_back(static_cast<char>(byte));
    }
    return result;
}

/**
 * @description: 两个大数异或运算 result = a ^ b
 * @param {BIGNUM} *a
 * @param {BIGNUM} *b
 * @param {BIGNUM} *result
 * @return {*}
 */
void xorBIGNUM(const BIGNUM *a, const BIGNUM *b, BIGNUM *result)
{
    // 获取a和b的字节数组表示
    const int a_bytes = BN_num_bytes(a);
    const int b_bytes = BN_num_bytes(b);
    unsigned char *b_data, *a_data;

    // 确保result足够大来存储异或结果
    const int max_bytes = a_bytes > b_bytes ? a_bytes : b_bytes;
    unsigned char *result_data = (unsigned char *)OPENSSL_malloc(max_bytes);
    b_data = (unsigned char *)OPENSSL_malloc(max_bytes);
    a_data = (unsigned char *)OPENSSL_malloc(max_bytes);

    BN_bn2binpad(a, a_data, max_bytes); // 输出大数二进制，不足的高位补0
    BN_bn2binpad(b, b_data, max_bytes); // 输出大数二进制，不足的高位补0

    // 执行异或操作
    for (int i = 0; i < max_bytes; ++i)
    {
        result_data[i] = a_data[i] ^ b_data[i];
    }

    // 将结果设置为BIGNUM对象
    BN_bin2bn(result_data, max_bytes, result);

    // 释放内存
    OPENSSL_free(a_data);
    OPENSSL_free(b_data);
    OPENSSL_free(result_data);
}

/**
 * @description: 将字符串哈希为固定位数的数字（SHA-256）与后续的加解密对应，否则会出错
 * @param {string} &input
 * @return {*}
 */
string hashStringToFixedLength(const string &input)
{
    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256_CTX sha256;
    SHA256_Init(&sha256);
    SHA256_Update(&sha256, input.c_str(), input.size());
    SHA256_Final(hash, &sha256);

    string ret(reinterpret_cast<char *>(hash), 32);
    return ret;
}
