/*
 * @Author: ck
 * @Date: 2023-09-07 18:50:11
 * @LastEditors: ck
 * @LastEditTime: 2023-09-12 19:31:18
 * @FilePath: /mimademov2/src/test1.cpp
 * @Description:
 *
 * Copyright (c) 2023 by ${git_name_email}, All Rights Reserved.
 */
#include "miracl/miracl.h"
#include "miracl/func.h"

#include <iostream>
#include <thread>
#include <chrono>
#include <cstring>
#include <chrono>
#include <stdio.h>
#include <vector>
#include <sstream>
#include <iomanip>

#include <openssl/ec.h>
#include <openssl/obj_mac.h>
#include <openssl/err.h>
#include <openssl/evp.h>
#include <openssl/sha.h>

string stringToHex(const unsigned char *byteArray, size_t length)
{
    stringstream hexStream;

    for (size_t i = 0; i < length; ++i)
    {
        hexStream << hex << setw(2) << setfill('0') << static_cast<int>(byteArray[i]);
    }

    return hexStream.str();
}

int main()
{
    // 初始化 OpenSSL 库
    OpenSSL_add_all_algorithms();
    ERR_load_crypto_strings();
    char *decimalString;
    BN_CTX *ctx = BN_CTX_new();

    // 选择椭圆曲线参数（这里使用了 secp256k1 曲线，比特币也使用该曲线）
    EC_KEY *ec_key = EC_KEY_new_by_curve_name(NID_secp256k1);
    if (!ec_key)
    {
        cerr << "Error creating EC_KEY" << endl;
        return 1;
    }
    const EC_GROUP *curve = EC_KEY_get0_group(ec_key);
    const EC_POINT *G = EC_GROUP_get0_generator(curve); // 生成点G
    const char *hexStr = "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2F";
    BIGNUM *p = BN_new();
    BN_hex2bn(&p, hexStr);


    char *hex_str = BN_bn2hex(p);
    if (!hex_str) {
        // 错误处理
        BN_free(p);
        return 1;
    }

    // 打印十六进制字符串
    printf("Hexadecimal: %s\n", hex_str);
    

    // 生成随机私钥
    if (!EC_KEY_generate_key(ec_key))
    {
        cerr << "Error generating key pair" << endl;
        return 1;
    }

    /* test part */
    BIGNUM *num1 = BN_new();
    BN_set_word(num1, 6);
    BIGNUM *num2 = BN_new();
    BN_set_word(num2, 12);
    BIGNUM *num3 = BN_new();
    BN_set_word(num3, 2);
    /* test part */

    // 获取私钥
    const BIGNUM *private_key = EC_KEY_get0_private_key(ec_key);
    cout << "private_key: " << BN_bn2dec(private_key) << endl;

    // 计算公钥，即私钥 * 原点 G
    EC_POINT *public_key = EC_POINT_new(curve);
    if (!EC_POINT_mul(curve, public_key, private_key, G, NULL, ctx))
    {
        cerr << "Error computing public key" << endl;
        return 1;
    }

    /* test part */
    size_t lentest = EC_POINT_point2oct(curve, public_key, POINT_CONVERSION_UNCOMPRESSED, NULL, 0, NULL);
    unsigned char *buffertest = (unsigned char *)malloc(lentest);
    EC_POINT_point2oct(curve, public_key, POINT_CONVERSION_UNCOMPRESSED, buffertest, lentest, NULL);

    string teststr;
    teststr = stringToHex(buffertest, sizeof(buffertest));
    cout << "the buffer of ecc point is: " << teststr << endl;
    /* test part */

    /***************************************************
                        生成签名
    ***************************************************/

    // 生成随机数r，计算R，即r * 原点 G
    BIGNUM *random_number = BN_new();
    if (!BN_rand(random_number, 256, -1, 0))
    { // 生成一个随机数，256位长
        cerr << "Error generating random number" << endl;
        return 1;
    }
    cout << "r : " << BN_bn2dec(random_number) << endl;

    // 创建结果R
    EC_POINT *result_point = EC_POINT_new(curve);
    // 执行随机数r与原点 G 的乘法操作
    if (!EC_POINT_mul(curve, result_point, random_number, G, NULL, ctx))
    {
        cerr << "Error computing result public key" << endl;
        return 1;
    }
    BN_CTX_free(ctx);
    ctx = BN_CTX_new();
    

    /* test part */
    lentest = EC_POINT_point2oct(curve, result_point, POINT_CONVERSION_UNCOMPRESSED, NULL, 0, NULL);
    buffertest = (unsigned char *)malloc(lentest);
    EC_POINT_point2oct(curve, result_point, POINT_CONVERSION_UNCOMPRESSED, buffertest, lentest, NULL);

    teststr = stringToHex(buffertest, sizeof(buffertest));
    cout << "the buffer of R point is: " << teststr << endl;
    /* test part */

    /* test part */
    EC_POINT *result_test = EC_POINT_new(curve);

    EC_POINT_mul(curve, result_test, random_number, public_key, NULL, ctx); // r*pk
    BN_CTX_free(ctx);
    ctx = BN_CTX_new();

    EC_POINT_get_affine_coordinates_GFp(curve, result_test, num1, num2, NULL);
    cout << "result_test x: " << BN_bn2dec(num1) << endl;
    cout << "result_test y: " << BN_bn2dec(num2) << endl;

    lentest = EC_POINT_point2oct(curve, result_test, POINT_CONVERSION_UNCOMPRESSED, NULL, 0, NULL);
    buffertest = (unsigned char *)malloc(lentest);
    EC_POINT_point2oct(curve, result_test, POINT_CONVERSION_UNCOMPRESSED, buffertest, lentest, NULL);

    teststr = stringToHex(buffertest, sizeof(buffertest));
    cout << "the buffer of r*pk point is: " << teststr << endl;
    /* test part */
    /* test part */
    EC_POINT *result_test1 = EC_POINT_new(curve);
    BIGNUM *r_sk = BN_new();
    BN_mod_mul(r_sk, random_number, private_key, p, ctx);
    cout << "r multiply sk x: " << BN_bn2dec(r_sk) << endl;

    EC_POINT_mul(curve, result_test1, r_sk, G, NULL, ctx); // r*sk*pk
    BN_CTX_free(ctx);
    ctx = BN_CTX_new();

    EC_POINT_get_affine_coordinates_GFp(curve, result_test1, num1, num2, NULL);
    cout << "result_test1 x: " << BN_bn2dec(num1) << endl;
    cout << "result_test1 y: " << BN_bn2dec(num2) << endl;

    lentest = EC_POINT_point2oct(curve, result_test1, POINT_CONVERSION_UNCOMPRESSED, NULL, 0, NULL);
    buffertest = (unsigned char *)malloc(lentest);
    EC_POINT_point2oct(curve, result_test1, POINT_CONVERSION_UNCOMPRESSED, buffertest, lentest, NULL);

    teststr = stringToHex(buffertest, sizeof(buffertest));
    cout << "the buffer of r*sk*G point is: " << teststr << endl;
    /* test part */

    // 生成Hash(m, R)
    SHA256_CTX sha256Context;
    SHA256_Init(&sha256Context);

    const char *m = "request subshare";
    SHA256_Update(&sha256Context, m, strlen(m));

    // 转化椭圆曲线上的点为字节数组然后进行hash
    size_t len = EC_POINT_point2oct(curve, result_point, POINT_CONVERSION_UNCOMPRESSED, NULL, 0, NULL);
    unsigned char *buffer = (unsigned char *)malloc(len);

    // 将 EC_POINT 转换为字节数组
    EC_POINT_point2oct(curve, result_point, POINT_CONVERSION_UNCOMPRESSED, buffer, len, NULL);

    SHA256_Update(&sha256Context, buffer, len);

    // 计算哈希值
    unsigned char hash[SHA256_DIGEST_LENGTH];

    SHA256_Final(hash, &sha256Context);

    string hash_hex;

    hash_hex = stringToHex(hash, SHA256_DIGEST_LENGTH);
    cout << "Hex to Decimal: " << hash_hex << endl;
    // 计算z， z = r + c*sk

    BIGNUM *z = BN_new();
    BIGNUM *c = BN_new();
    BN_hex2bn(&c, hash_hex.data());

    cout << "c : " << BN_bn2dec(c) << endl;
    cout << "private_key: " << BN_bn2dec(private_key) << endl;
    BN_mul(z, c, private_key, ctx);

    BN_add(z, z, random_number);
    decimalString = BN_bn2dec(z);
    cout << "z: " << decimalString << endl;

    /***************************************************
                        验证签名
    ***************************************************/
    // R' = z * G - c * Pk
    // 创建结果R
    EC_POINT *result_point_v = EC_POINT_new(curve);

    // 执行z与原点 G 的乘法操作
    if (!EC_POINT_mul(curve, result_point_v, z, NULL, NULL, NULL))
    {
        cerr << "Error computing result public key" << endl;
        return 1;
    }

    EC_POINT *result_point_v1 = EC_POINT_new(curve);
    // 执行c与Pk 的乘法操作
    if (!EC_POINT_mul(curve, result_point_v1, c, public_key, nullptr, ctx))
    {
        cerr << "Error computing result public key" << endl;
        return 1;
    }

    // 负号取逆
    if (!EC_POINT_invert(curve, result_point_v1, NULL))
    {
        // 错误处理
        EC_POINT_free(result_point_v1);
        EC_KEY_free(ec_key);
        return 1;
    }

    EC_POINT_add(curve, result_point_v, result_point_v, result_point_v1, NULL);

    /* test part */
    lentest = EC_POINT_point2oct(curve, result_point_v, POINT_CONVERSION_UNCOMPRESSED, NULL, 0, NULL);
    buffertest = (unsigned char *)malloc(lentest);
    EC_POINT_point2oct(curve, result_point_v, POINT_CONVERSION_UNCOMPRESSED, buffertest, lentest, NULL);

    teststr = stringToHex(buffertest, sizeof(buffertest));
    cout << "the buffer of R' point is: " << teststr << endl;
    /* test part */

    // c = Hash(m, R')
    SHA256_CTX sha256Context1;
    SHA256_Init(&sha256Context1);

    SHA256_Update(&sha256Context1, m, strlen(m));

    // 转化椭圆曲线上的点为字节数组然后进行hash
    size_t len1 = EC_POINT_point2oct(curve, result_point_v, POINT_CONVERSION_UNCOMPRESSED, NULL, 0, NULL);
    unsigned char *buffer1 = (unsigned char *)malloc(len1);

    // 将 EC_POINT 转换为字节数组
    EC_POINT_point2oct(curve, result_point_v, POINT_CONVERSION_UNCOMPRESSED, buffer1, len1, NULL);
    SHA256_Update(&sha256Context1, buffer1, len1);

    // 计算哈希值
    unsigned char hash1[SHA256_DIGEST_LENGTH];

    SHA256_Final(hash1, &sha256Context1);

    string hash_hex1;

    hash_hex1 = stringToHex(hash1, SHA256_DIGEST_LENGTH);
    cout << "c computation: " << hash_hex1 << endl;

    BIGNUM *c1 = BN_new();
    BN_hex2bn(&c1, hash_hex1.data());

    cout << "c : " << BN_bn2dec(c1) << endl;

    // 释放资源
    EC_KEY_free(ec_key);
    EC_POINT_free(public_key);
    EC_POINT_free(result_point);
    EC_POINT_free(result_point_v);
    EC_POINT_free(result_point_v1);
    EVP_cleanup();

    return 0;
}
