#include <iostream>
#include <thread>
#include <chrono>
#include <cstring>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <vector>
#include <map>
#include <queue>
#include <mutex>
#include <condition_variable>
#include <fcntl.h>

#include "miracl/miracl.h"
#include "miracl/func.h"
#include "miracl/senery.h"
#include "openssl/sha.h"
#include <iomanip>

#include <openssl/ec.h>
#include <openssl/obj_mac.h>
#include <openssl/err.h>
#include <openssl/evp.h>
#include <openssl/sha.h>

// #define PORT 6000
#define MAX_BUF_SIZE 1024
#define P_SIZE 30
#define RAND_SIZE 30

using namespace std;

vector<int> port_pool; // 群组中的地址列表
vector<big> kvec;	   // 存储
vector<big> vvec;

pair<const BIGNUM *, const EC_POINT *> key_pair; // 存储公私钥
string keyhash;									 // 记录key的hash值，用于恢复key后检查正确性
map<int, big> id_pool;							 // 地址和设备id的对应数对
map<int, big> subsecret_map;					 // 存储各个设备的秘密份额
map<int, big> key_map;							 // 收集回应的数据分片
map<int, big> value_map;						 // 收集回应的秘密份额
EC_POINT *valid_public_key;						 // 用于请求秘密份额的时候的身份验证
// map<big, big> key_value_map;
map<string, int> action_map; // 消息标识和收到相应消息程序采取的动作

int recv_secret_num;
int secretshareport = 0;
mutex mtx;			   // 定义互斥锁
condition_variable cv; // 定义条件变量
bool exit_group = false;

void udp_sender(int port, string msg);


/**
 * @description: 设备之间消息的头，作为标识
 * @return {*}
 */
void add_actions()
{
	action_map["PRIME"] = 0;	 // 大素数
	action_map["SUBSECRET"] = 1; // 秘密份额
	action_map["DEVICEID"] = 2;	 // 设备id

	action_map["REQUEST_S"] = 3;   // 请求秘密份额
	action_map["RESPONSE_S"] = 4;  // 响应秘密份额的请求
	action_map["SEND_SECRET"] = 5; // 接收到私钥，作为后续的重构的身份识别

	action_map["REQUEST_P"] = 10;  // 请求大素数
	action_map["REQUEST_ID"] = 11; // 请求其他设备的id

	action_map["REQUEST_SHARE"] = 15; // 请求各个设备分发秘密份额
}

/**
 * @description: 根据消息的头将消息分类，设备收到不同的消息采取不同的动作
 * @param {string} str: 消息
 * @return {pair<int, int>}: 返回数对(a,b)，a为消息在action_map中的类别，
 * 				b为消息类别头的长度+1
 * @example: msg:"PRIME:6000:12345",返回(0,6)
 */
pair<int, int> start_with(string str)
{
	int ret = 0;
	string head;
	map<string, int>::iterator it;

	// 遍历消息，找到头结束的位置
	for (size_t i = 0; i < str.size(); i++)
	{
		if (str[i] == ':')
		{
			ret = i;
			break;
		}
	}
	// 找到头结束的位置后，与action_map中消息类别比对，找到对应消息类别的编号
	if (ret)
	{
		head = str.substr(0, ret);
		it = action_map.find(head);
		if (it != action_map.end())
		{
			return make_pair(action_map[head], ret + 1);
		}
		else
		{
			printf("there not exist such head\n");
		}
	}
	return make_pair(-1, ret);
}

/**
 * @description: 解析消息获取有用的信息
 * @param {string} str: 消息
 * @param {int} start: 消息头结束的位置，不用重头遍历
 * @return {pair<int, int>}: 返回数对(a,b)，a为消息发送方标识（本demo中用端口号作为标识）
 * 				b为消息发送方标识结束的位置+1
 * @example: msg:"PRIME:6000:12345",返回(6000,11)
 */
pair<int, int> parse_msg(string str, int start)
{
	int ret, tmp;
	for (size_t i = start; i < str.size(); i++)
	{
		if (str[i] == ':')
		{
			ret = i;
			break;
		}
	}
	tmp = stoi(str.substr(start, ret - start)); // 端口号转为整数
	return make_pair(tmp, ret + 1);
}

/**
 * @description: 解析消息获取有用的信息
 * @param {string} str: 消息
 * @param {int} start: 消息头结束的位置，不用重头遍历
 * @return {pair<int, int>}: 返回数对(a,b)，a为消息发送方标识（本demo中用端口号作为标识）
 * 				b为消息发送方标识结束的位置+1
 * @example: msg:"12345,12312",返回(6000,11)
 */
pair<int, int> parse_msg1(string str, int start)
{
	int ret, tmp = start;
	for (size_t i = start; i < str.size(); i++)
	{
		if (str[i] == ',')
		{
			ret = i;
			break;
		}
	}
	return make_pair(tmp, ret + 1);
}

/**
 * @description: 获取map 中(key, value)的value集合
 * @param {map<int, big>} mymap: 一个c++中映射
 * @return {vector<big>}: 返回该映射中的值的列表
 *
 * @example: mymap:{(1,123),(2,3434),(3,5623)},返回[123,3434,5623]
 */
vector<big> detach_value(map<int, big> mymap)
{
	vector<big> ret_vec;

	for (map<int, big>::iterator it = mymap.begin(); it != mymap.end(); ++it)
	{
		ret_vec.push_back(it->second);
	}
	return ret_vec;
}

/**
 * @description: 获取map 中(key, value)的value列表或者key列表
 * @param {map<big, big>} mymap: 一个c++中映射容器
 * @param {int} pos: 0表示要获取key的列表，1表示要获取value的列表
 * @return {vector<big>}: 返回该映射中key/value的值的列表
 *
 * @example: mymap:{(1,123),(2,3434),(3,5623)},返回value列表[123,3434,5623]
 * 			或key列表[1,2,3]
 */
vector<big> detach_key_value(map<big, big> mymap, int pos)
{
	vector<big> ret_vec;
	if (pos)
	{
		for (map<big, big>::iterator it = mymap.begin(); it != mymap.end(); ++it)
		{
			ret_vec.push_back(it->second);
		}
	}
	else
	{
		for (map<big, big>::iterator it = mymap.begin(); it != mymap.end(); ++it)
		{
			ret_vec.push_back(it->first);
		}
	}

	return ret_vec;
}

/**
 * @description: 设置udp通信为非阻塞
 * @param {int} sockfd
 * @return {*}
 */
static void setnonblocking(int sockfd)
{
	// 获取套接字的标志位
	int flag = fcntl(sockfd, F_GETFL, 0);
	if (flag < 0)
	{
		exit(EXIT_FAILURE);
		return;
	}
	// 设置套接字标志位为非阻塞
	if (fcntl(sockfd, F_SETFL, flag | O_NONBLOCK) < 0)
	{
		exit(EXIT_FAILURE);
	}
}

/**
 * @description: 创建 UDP 监听线程函数
 * @param {device} &d: 当前设备
 * @return {*}
 */
void udp_listener(device &d)
{
	struct sockaddr_in addr;

	pair<int, int> msg_type, msg_parse, msg_parse1;
	map<int, big>::iterator tmpit;
	int head_type, leave_port, valid_flag;
	string recv_msg, head, resp_msg, tmp_str, tmp_str1;
	EC_KEY *ec_key_listen = EC_KEY_new_by_curve_name(NID_secp256k1);
	const EC_GROUP *curve = EC_KEY_get0_group(ec_key_listen);
	EC_POINT *public_key = EC_POINT_new(curve);
	vector<string> coordinatevec;
	BIGNUM *big_tmp1 = BN_new(), *big_tmp2 = BN_new();
	BN_CTX *ctx = BN_CTX_new();

	// 通信地址，端口设置（本demo中设置为本地）
	memset(&addr, 0, sizeof(addr));
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = htonl(INADDR_ANY);
	addr.sin_port = htons(d.port);

	// 创建 UDP socket套接字
	int sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	// 设置套接字为非阻塞
	setnonblocking(sockfd);
	// 将 socket 与地址绑定
	bind(sockfd, (struct sockaddr *)&addr, sizeof(addr));

	char buf[MAX_BUF_SIZE];
	char ch[MAX_BUF_SIZE];

	// 当设备退出群组时，结束循环
	while (!exit_group)
	{
		memset(buf, 0, sizeof(buf));

		// 接收 UDP 消息
		int len = recvfrom(sockfd, buf, MAX_BUF_SIZE, 0, NULL, NULL);
		if (len > 0)
		{
			big recv_big_num = mirvar(0), reconstruc_num = mirvar(0);

			// 解析消息的头
			msg_type = start_with(buf);
			head_type = msg_type.first;

			// 根据消息的头执行不同的程序
			switch (head_type)
			{
			case 0: // 收到统一大素数的消息,设置自己的大素数

				msg_parse = parse_msg(buf, msg_type.second); // 解析消息

				msg_parse1 = parse_msg1(buf, msg_parse.second);
				//  将消息中的字符串转为大素数
				cinstr(recv_big_num, (char *)tmp_str.assign(buf + msg_parse.second,
															buf + msg_parse1.second - 1)
										 .data());
				tmp_str.assign(buf + msg_parse1.second); // 公钥坐标字符串
				cout << "收到的公钥的坐标为 :(" << tmp_str << ")" << endl;
				coordinatevec = splitString(tmp_str, ',');
				// valid_public_key = EC_POINT_new(EC_KEY_get0_group(ec_key_listen));
				valid_public_key = str_to_eccPoint(ec_key_listen, coordinatevec[0], coordinatevec[1]);

				d.setprime(recv_big_num); // 设置大素数
				d.ownshare = mirvar(0);	  // 设置初始的秘密份额为0

				break;
			case 1:											 // 收到分发密钥，添加到其秘密份额里面
				msg_parse = parse_msg(buf, msg_type.second); // 解析消息

				msg_parse1 = parse_msg1(buf, msg_parse.second);

				tmp_str.assign(buf + msg_parse1.second);
				keyhash = tmp_str;
				secretshareport = msg_parse.first;

				cinstr(recv_big_num, (char *)tmp_str.assign(buf + msg_parse.second, buf + msg_parse1.second - 1).data()); // 将消息中的字符串转为大数结构

				// 查找是否已经存在有来自于设备msg_parse.first的秘密份额，若有就删除掉
				tmpit = subsecret_map.find(msg_parse.first);
				if (tmpit != subsecret_map.end())
				{
					d.secretsub(tmpit->second);
				}
				d.secretsum(recv_big_num);
				subsecret_map[msg_parse.first] = recv_big_num; // 将秘密份额记录下来，后续设备离开后删除掉

				break;
			case 2:											  // 收到设备 id
				msg_parse = parse_msg(buf, msg_type.second);  // 解析消息
				cinstr(recv_big_num, buf + msg_parse.second); // 将消息中的字符串转为大数结构

				// 检查设备是否已经存在，若不存在群组设备+1
				tmpit = id_pool.find(msg_parse.first);
				if (tmpit == id_pool.end())
				{
					d.member += 1; // 判断有一定问题，但是由于调试受限需要修改，功能不影响
				}

				// 记录发送该消息的设备id
				id_pool[msg_parse.first] = recv_big_num;

				// 检测发送该消息的设备id和自己的id是否重合，若重合提示重新生成新id
				if (msg_parse.first != d.port && mr_compare(recv_big_num, d.Deviceid) == 0)
				{
					udp_sender(msg_parse.first, "群组中已存在该id的设备\n ");
					printf("发送该消息的设备id和本设备的id相同\n ");
				}

				printf("收到的设备id和端口是 (%d,%s)\n", msg_parse.first,
					   buf + msg_parse.second);

				break;
			case 3:											 // 收到请求秘密份额
				msg_parse = parse_msg(buf, msg_type.second); // 解析消息
				msg_parse1 = parse_msg1(buf, msg_parse.second);

				// 检验签名
				tmp_str1 = tmp_str.assign(buf, buf + msg_parse.second);
				tmp_str.assign(buf + msg_parse1.first, buf + msg_parse1.second - 1);
				BN_hex2bn(&big_tmp1, tmp_str.data());
				tmp_str.assign(buf + msg_parse1.second);
				BN_hex2bn(&big_tmp2, tmp_str.data());

				valid_flag = validation(tmp_str1, ec_key_listen, valid_public_key, big_tmp1, big_tmp2);
				resp_msg = "RESPONSE_S:"; // 设置返回消息的头
				resp_msg += to_string(d.port) + ":";

				if (!valid_flag)
				{
					resp_msg += "1";
					udp_sender(msg_parse.first, resp_msg); // 将该响应返回给请求的设备
					break;
				}
				cotnum(d.ownshare, stdout); // 终端输出本设备的总的秘密份额

				cotstr(d.ownshare, ch); // 将自己的总的秘密份额转为字符串类型
				resp_msg += string(ch);
				udp_sender(msg_parse.first, resp_msg); // 将该响应返回给请求的设备
				break;
			case 4:											 // 收到秘密份额请求的回应
				msg_parse = parse_msg(buf, msg_type.second); // 解析消息

				cinstr(recv_big_num, buf + msg_parse.second); // 将消息中的字符串转为大数结构

				// 将收到的消息和发送消息的对应端口存储起来
				value_map[msg_parse.first] = recv_big_num;

				// 如果收到超过门限数量的消息开始密钥恢复
				if (value_map.size() == d.tresh)
				{
					kvec.clear(); // 记录设备id值
					vvec.clear(); // 记录设备的总的秘密份额
					printf("收到的设备id和总的秘密份额如下所示:\n");
					for (map<int, big>::iterator it = value_map.begin(); it != value_map.end(); it++)
					{
						kvec.push_back(id_pool[it->first]);
						vvec.push_back(it->second);
						cotnum(*kvec.rbegin(), stdout);
						cotnum(*vvec.rbegin(), stdout);
						printf("-----------\n");
					}
					reconstruc_num = d.secretreconstruct(vvec, kvec); // 秘密重构
					printf("重构出来的秘密为：");
					cotnum(reconstruc_num, stdout); // 终端输出重构出来的密钥

					// 判断重构出来的密钥是否和群组的密钥一致，若不一致可能是恢复出现问题
					cotstr(reconstruc_num, ch);
					string tmp = generateHash(ch);
					printf("重构出来的秘密的哈希值为：%s\n", tmp.data());
					if (keyhash.compare(tmp) == 0)
					{
						printf("成功恢复秘密\n");
					}
					else
					{
						printf("恢复秘密失败（或者重新更新群组的秘密值）\n");
					}
				}
				break;
			case 5:											 // 收到私钥
				msg_parse = parse_msg(buf, msg_type.second); // 解析消息

				tmp_str.assign(buf + msg_parse.second);

				cout << "收到的私钥为：" << tmp_str << endl;
				BN_hex2bn(&big_tmp1, tmp_str.data());						// 将私钥转为大数
				key_pair.first = big_tmp1;									// 存储私钥到自己的公私钥对中
				EC_POINT_mul(curve, public_key, big_tmp1, NULL, NULL, ctx); // 计算公钥
				key_pair.second = public_key;								// 存储公钥到自己的公私钥对中
				break;

			case 10:										 // 收到大素数请求
				msg_parse = parse_msg(buf, msg_type.second); // 解析消息
				if (d.port == secretshareport)
				{
					// 分发的设备才响应大素数请求，需要同时提供公钥
				}
				else
					break;
				// cinstr(recv_big_num, buf + msg_parse.second); // 将消息中的字符串转为大数结构

				resp_msg = "PRIME:"; // 回应请求消息的头
				resp_msg += to_string(d.port) + ":";
				cotstr(d.p, ch); // 将大素数转为字符串
				resp_msg += string(ch);
				
				resp_msg += ",";
				resp_msg += eccPoint_to_str(curve, key_pair.second); // 添加公钥字符串
				udp_sender(msg_parse.first, resp_msg);				// 将回应的消息发送给请求的设备
				break;
			case 11:										 // 收到ID请求
				msg_parse = parse_msg(buf, msg_type.second); // 解析消息
				resp_msg = "DEVICEID:";						 // 回应请求消息的头

				resp_msg += to_string(d.port) + ":";
				cotstr(d.Deviceid, ch); // 将设备的id转为字符串
				resp_msg += string(ch);
				udp_sender(msg_parse.first, resp_msg); // 将回应的消息发送给请求得设备
				break;
			
			case 15:						   // 收到请求秘密份额的消息
				if (secretshareport != d.port) // 只有分发秘密的设备收到后进行回应
					break;

				resp_msg = "SUBSECRET:";			 // 响应请求消息的头
				resp_msg += to_string(d.port) + ":"; // 本机的地址添加到回应消息中

				// 查找请求的设备的id值是否存在
				tmpit = id_pool.find(msg_parse.first);
				if (tmpit == id_pool.end())
				{
					printf("该地址的设备无对应的设备id %d", msg_parse.first);
					break;
				}

				// 根据请求设备的id计算秘密份额
				recv_big_num = d.generateshare(id_pool[msg_parse.first]);

				cotstr(recv_big_num, ch); // 将计算到的秘密份额转为字符串
				resp_msg += string(ch);
				resp_msg += ",";

				cotstr(d.coef[d.tresh - 1], ch); // 转为字符串
				tmp_str1 = generateHash(ch);	 // 生成秘密值的hash值
				resp_msg += tmp_str1;				   // 添加上秘密的hash值
				udp_sender(msg_parse.first, resp_msg); // 将消息发送给请求的设备
				break;

			default:
				break;
			}
			cout << "Received message: " << buf << endl; // 输出接收到的消息
		}
	}

	// 关闭 UDP socket
	close(sockfd);
}

/**
 * @description: 创建 UDP 发送线程函数
 * @param {int} port: 发送的端口号
 * @param {string} msg: 发送的消息
 * @return {*}
 */
void udp_sender(int port, string msg)
{
	struct sockaddr_in addr;
	memset(&addr, 0, sizeof(addr));

	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = inet_addr("127.0.0.1"); // 发送给本地IP地址，实际场景中要使用对应的ip地址
	addr.sin_port = htons(port);

	// 创建 UDP socket
	int sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);

	char buf[MAX_BUF_SIZE];

	// 发送消息
	sprintf(buf, msg.data(), (int)time(NULL));
	sendto(sockfd, buf, strlen(buf), 0, (struct sockaddr *)&addr, sizeof(addr));

	// 等待1秒再继续发送消息
	this_thread::sleep_for(chrono::seconds(1));

	// 关闭 UDP socket
	close(sockfd);
}

// 可执行操作目录
void content()
{
	printf("选择动作:\n"); // 选择如下动作
	printf("0.退出\n");	   // 设备退出群组，但是不更新退出设备分发的秘密份额和数据分片
	printf("1.初始化\n");
	printf("2.发送秘密份额\n");
	printf("3.发送设备id\n");
	printf("4.请求重构密钥\n");
	printf("5.传递私钥\n");

	printf("8.请求设备id\n");				 // 请求设备的id值，用于设备初始加入
	printf("9.请求秘密份额\n");				 // 请求秘密份额，用于新设备加入
	printf("10.请求大素数\n");				 // 请求大素数的值
	printf("13.更新秘密份额和数据分片值\n"); // 去除退出设备分发的秘密份额

	printf("14.for test use\n");
}

int main()
{
	miracl *mip = mirsys(500, 10); // 大数运算必须以mirsys开始，结束时mirexit
	irand(time(NULL));			   // 初始化内部随机数系统

	device d; // 创建一个设备
	big tmp = mirvar(0), randomdata = mirvar(0), one = mirvar(1), c;
	int read_in, choose_port;
	string tmp_str, secret_hash;
	char ch[MAX_BUF_SIZE];
	map<int, big>::iterator mtmpit;

	d.initial(3, 5); //(t, n) 群组中成员数量5，门限设定为3
	d.port = 6002;	 // 设备的地址为本地，端口为6000

	d.setpsize(P_SIZE);		  // 设备设定大素数的位数
	d.setrandsize(RAND_SIZE); // 设备设定随机数的位数
	d.setid();				  // 生成自己的id（或者用自身唯一标识id，群组中不能有相同的id值）

	// 每个设备都有群组中的各个设备的ip+端口号(建立好的群组需要保证这个基础)
	for (size_t i = 6000; i < 6000 + d.member; i++)
	{
		port_pool.push_back(i);
	}

	/*****************************************************
	 *			    公私钥生成部分						  *
	 *****************************************************/
	OpenSSL_add_all_algorithms();
	ERR_load_crypto_strings();
	char *decimalString;
	BN_CTX *ctx = BN_CTX_new();
	int result = 0;

	// 选择椭圆曲线参数（这里使用了 secp256k1 曲线，比特币也使用该曲线）
	EC_KEY *ec_key = EC_KEY_new_by_curve_name(NID_secp256k1);
	const EC_GROUP *curve = EC_KEY_get0_group(ec_key);

	pair<BIGNUM *, BIGNUM *> sig_pair;
	BIGNUM *tmp_big1 = BN_new(), *tmp_big2 = BN_new();
	key_pair = generateKeyPair(ec_key);
	/*****************************************************
	 *			    公私钥生成结束						  *
	 *****************************************************/

	valid_public_key = EC_POINT_new(EC_KEY_get0_group(ec_key));
	add_actions(); // 添加消息头来识别和处理消息

	thread listener(udp_listener, ref(d)); // 创建 UDP 监听线程，根据收到的不同消息进行不同处理

	do
	{
		content(); // 可以选择的动作的目录
		read_in = 0;
		cin >> read_in; // 读取采取动作

		switch (read_in)
		{
		case 1:					  // 初始化生成大素数并发给所有设备，并生成多项式
			d.generatebigprime(); // 生成大素数
			printf("生成的大素数如下所示:");
			cotnum(d.p, stdout);

			d.coef.clear();	  // 清空系数的列表
			d.generatepoly(); // 生成多项式的系数
			//如果重新生成多项式，则需要先记录原来的key然后替换掉随机生成的key，保证key的不变
			
			// d.coef[d.tresh - 1] = key;
			printf("生成的多项式如下所示:\n");
			for (size_t i = 0; i < d.coef.size(); i++)
			{
				cotnum(d.coef[i], stdout);
			}

			tmp_str = "PRIME:";					// 生成发送消息的头
			tmp_str += to_string(d.port) + ":"; // 添加本设备的地址
			cotstr(d.p, ch);					// 将大素数转为字符串后添加到消息中
			tmp_str += ch;

			tmp_str += ",";

			tmp_str += eccPoint_to_str(curve, key_pair.second);

			for (size_t i = 0; i < port_pool.size(); i++) // 给其他设备发送大素数的消息
			{
				/* if (port_pool[i] == d.port)
					continue; */
				udp_sender(port_pool[i], tmp_str);
			}

			if (!EC_POINT_copy(valid_public_key, key_pair.second)) // copy自己的公钥值存储起来
			{
				std::cerr << "Error copying point" << std::endl;
				EC_POINT_free(valid_public_key);
			}

			break;
		case 2: // 计算设备的秘密份额并发送给对应设备
			printf("计算并发送秘密份额:\n");
			cotstr(d.coef[d.tresh - 1], ch); // 转为字符串
			secret_hash = generateHash(ch);	 // 生成秘密值的hash值
			for (size_t i = 0; i < port_pool.size(); i++)
			{
				tmp_str = "SUBSECRET:";				// 发送消息的头
				tmp_str += to_string(d.port) + ":"; // 添加端口（地址）
				printf("%d : ", port_pool[i]);

				// 查找该地址的设备id用于计算秘密份额，若群组中设备的地址无对应
				// 的设备id，会提示设备id缺少
				mtmpit = id_pool.find(port_pool[i]);
				if (mtmpit == id_pool.end())
				{
					printf("该地址的设备无对应的设备id");
					break;
				}

				tmp = d.generateshare(id_pool[port_pool[i]]); // 根据对于设备id计算秘密份额
				cotstr(tmp, ch);							  // 将秘密生成的秘密份额发送给对应设备
				cotnum(tmp, stdout);						  // 终端输出该秘密份额
				tmp_str += ch;

				tmp_str += ",";
				tmp_str += secret_hash;

				udp_sender(port_pool[i], tmp_str); // 发送消息给对应设备
			}

			break;
		case 3: // 发送设备id给所有设备
			for (size_t i = 0; i < port_pool.size(); i++)
			{
				tmp_str = "DEVICEID:";				// 消息的头
				tmp_str += to_string(d.port) + ":"; // 添加地址
				cotstr(d.Deviceid, ch);				// 将设备id转为字符串
				tmp_str += ch;
				udp_sender(port_pool[i], tmp_str); // 将消息发送给对应设备
			}
			break;
		case 4:				   // 请求重构密钥值
			value_map.clear(); // 清空接收接收回应的map容器

			/* 添加签名部分，本处签名为非交互式，带有的是接收的设备的地址，重传攻击不会凑效 */
			tmp_str = "REQUEST_S:";				// 消息的头
			tmp_str += to_string(d.port) + ":"; // 添加地址
			sig_pair = signature(tmp_str, ec_key, key_pair.first);
			tmp_str += big_Pair_to_str(sig_pair.first, sig_pair.second);

			for (size_t i = 0; i < port_pool.size(); i++)
			{
				udp_sender(port_pool[i], tmp_str); // 将消息发送给对应设备
			}
			break;
		case 5: // 传递私钥
			while (1)
			{
				printf("请输入要传递私钥给那个端口：\n");
				cin >> choose_port;
				for (size_t i = 0; i < port_pool.size(); i++)
				{
					if (port_pool[i] == choose_port)
					{
						tmp_str = "SEND_SECRET:";			// 消息的头
						tmp_str += to_string(d.port) + ":"; // 添加地址

						tmp_str += BN_bn2hex(key_pair.first); // 添加私钥
						cout << "发送的私钥是：" << BN_bn2dec(key_pair.first) << endl;
						udp_sender(choose_port, tmp_str); // 将消息发送给对应设备
						break;
					}
				}
				printf("是否输入一个新端口号(1/0):\n");
				cin >> choose_port;
				if (!choose_port)
					break;
			}
			break;
		case 8: // 广播请求device id, 本处无广播就遍历点对点通信
			printf("打印出群组中已有设备的地址:\n");
			for (auto i : port_pool)
			{
				printf("%d\n", i);
			}
			for (size_t i = 0; i < port_pool.size(); i++)
			{
				tmp_str = "REQUEST_ID:";			// 消息的头
				tmp_str += to_string(d.port) + ":"; // 本设备的地址
				udp_sender(port_pool[i], tmp_str);	// 将消息发送给对应设备
			}
			break;
		case 9: // 请求秘密份额，群组中广播，分发秘密的设备收到后响应
			for (size_t i = 0; i < port_pool.size(); i++)
			{
				tmp_str = "REQUEST_SHARE:";			// 消息的头
				tmp_str += to_string(d.port) + ":"; // 本设备的地址
				udp_sender(port_pool[i], tmp_str);	// 将消息发送给对应设备
			}
			break;
		case 10: // 请求大素数
			for (size_t i = 0; i < port_pool.size(); i++)
			{
				if (port_pool[i] != d.port)
				{
					tmp_str = "REQUEST_P:";				// 消息的头
					tmp_str += to_string(d.port) + ":"; // 本设备的地址
					udp_sender(port_pool[i], tmp_str);	// 将消息发送给对应设备
				}
			}
			break;

		case 13: // 更新群组中的所有设备
			for (size_t i = 0; i < port_pool.size(); i++)
			{
				tmp_str = "UPDATE:";				// 消息的头
				tmp_str += to_string(d.port) + ":"; // 本设备的地址
				udp_sender(port_pool[i], tmp_str);	// 发送给群组中所有设备，使得群组更新
			}
			break;
		
		case 0: // 本设备退出群组
				// 通知群组中其他设备
			for (size_t i = 0; i < port_pool.size(); i++)
			{
				if (port_pool[i] == d.port)
					continue;
				tmp_str = "QUIT:"; // 消息的头
				tmp_str += to_string(d.port) + ":";
				udp_sender(port_pool[i], tmp_str);
			}
			exit_group = true; // 设置停止标记为true
			cv.notify_all();   // 通知所有线程，停止监听接收消息
			break;
		default:
			break;
		}

	} while (read_in);

	// 等待线程结束
	listener.join();
	mirexit(); // 在MIRACL的当前实例之后清理，并释放所有内部变量
	printf("本设备已离开群组\n");
	return 0;
}