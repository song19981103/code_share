/*
 * @Author: ck
 * @Date: 2023-09-12 20:00:08
 * @LastEditors: ck
 * @LastEditTime: 2023-09-14 02:00:26
 * @FilePath: /mimademov2/src/test20.cpp
 * @Description:
 *
 * Copyright (c) 2023 by ${git_name_email}, All Rights Reserved.
 */
#include <openssl/ec.h>
#include <openssl/asn1.h>
#include <openssl/bio.h>
#include <stdio.h>
#include <string>
#include <iostream>

#include <iostream>
#include <openssl/ec.h>
#include <openssl/obj_mac.h>
#include <openssl/rand.h>
#include <openssl/evp.h>
#include <openssl/ec.h>
#include <openssl/obj_mac.h>
#include <openssl/err.h>
#include <openssl/evp.h>
#include <openssl/sha.h>

#include <iostream>
#include <string>
#include <vector>
	
#include <sstream>

using namespace std;



// 椭圆曲线上的点坐标的字符串分割
vector<string> splitString(const string& input, char delimiter) {
    vector<string> parts;
    string part;
    istringstream iss(input);

    while (getline(iss, part, delimiter)) {
        parts.push_back(part);
    }

    return parts;
}

// 椭圆曲线上的点转为坐标字符串
string eccPoint_to_str(EC_KEY *ec_key, const EC_POINT *ecc_point)
{
    string ret = "";

    BIGNUM *x = BN_new();
    BIGNUM *y = BN_new();
    if (!EC_POINT_get_affine_coordinates_GFp(EC_KEY_get0_group(ec_key), ecc_point, x, y, NULL))
    {
        cerr << "Error getting coordinates" << endl;
        BN_free(x);
        BN_free(y);
        EC_KEY_free(ec_key);
        return nullptr;
    }

    ret += BN_bn2hex(x);
    ret += ",";
    ret += BN_bn2hex(y);
    return ret;
}

// 坐标字符串转为椭圆曲线上的点
EC_POINT * str_to_eccPoint(EC_KEY *ec_key, string point_x, string point_y)
{
    BIGNUM *x = BN_new();
    BIGNUM *y = BN_new();

    EC_POINT *ec_point = EC_POINT_new(EC_KEY_get0_group(ec_key));
    if (!ec_point) {
        std::cerr << "Error creating EC_POINT" << std::endl;
        EC_KEY_free(ec_key);
        return nullptr;
    }

    if (!BN_hex2bn(&x, point_x.data())) {
        std::cerr << "Error setting y coordinate" << std::endl;
        EC_POINT_free(ec_point);
        EC_KEY_free(ec_key);
        return nullptr;
    }
    if (!BN_hex2bn(&y, point_y.data())) {
        std::cerr << "Error setting y coordinate" << std::endl;
        EC_POINT_free(ec_point);
        EC_KEY_free(ec_key);
        return nullptr;
    }

    if (!EC_POINT_set_affine_coordinates_GFp(EC_KEY_get0_group(ec_key), ec_point, x, y, NULL)) {
        std::cerr << "Error setting coordinates" << std::endl;
        EC_POINT_free(ec_point);
        EC_KEY_free(ec_key);
        return nullptr;
    }

    return ec_point;
}

int main()
{
    // 初始化 OpenSSL 库
    OpenSSL_add_all_algorithms();

    // 创建一个 EC_KEY 对象并选择椭圆曲线参数（这里使用了 secp256k1 曲线，比特币也使用该曲线）
    EC_KEY *ec_key = EC_KEY_new_by_curve_name(NID_secp256k1);
    if (!ec_key)
    {
        fprintf(stderr, "Error creating EC_KEY\n");
        return 1;
    }

    // 生成随机密钥对
    if (!EC_KEY_generate_key(ec_key))
    {
        fprintf(stderr, "Error generating key pair\n");
        return 1;
    }

    // 获取公钥
    const EC_POINT *public_key = EC_KEY_get0_public_key(ec_key);

    string oup = eccPoint_to_str(ec_key, public_key);
    cout <<oup<<endl;
    
    vector<string> strsplitvec;
    strsplitvec = splitString(oup, ',');
    
    const EC_POINT *public_key1 = str_to_eccPoint(ec_key ,strsplitvec[0], strsplitvec[1]);

    int ret_cmp = EC_POINT_cmp(EC_GROUP_new_by_curve_name(NID_secp256k1), public_key, public_key1, NULL);

    cout << ret_cmp <<endl;
    return 0;
}
