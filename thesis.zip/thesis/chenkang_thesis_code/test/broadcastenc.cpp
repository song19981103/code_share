/*
 * @Author: ck
 * @Date: 2024-12-21 06:32:19
 * @LastEditors: ck
 * @LastEditTime: 2025-04-22 00:10:11
 * @FilePath: /test/test1.cpp
 * @Description:
 *
 * Copyright (c) 2024 by ${git_name_email}, All Rights Reserved.
 */
#include <pbc/pbc.h>
#include <iostream>
#include <gmpxx.h>
#include <stdio.h>
#include <dlfcn.h>
#include <cctype>
#include <map>
#include <vector>
#include <chrono>
#include <queue>

#include "mysup.h"
#include "moreatt.h"
#include "miracl/miracl.h"
#include "miracl/mirdef.h"
#define MaxDevice 5
#define Treshold 3
#define security_para 512
#define Discrete_Var_Num 3
#define Continuous_Var_Num 1
#define Vid_Param 4

unsigned long int seed = 43; // 种子值
gmp_randstate_t state;
pairing_t pairing;

enum Device_Type
{
    Type1 = 57763896,
    Type2 = 38783872,
    Type3 = 81423801
};

enum Device_Level
{
    Level1 = 65395266,
    Level2 = 86919131,
    Level3 = 24239035
};

enum Department
{
    Dep1 = 81723230,
    Dep2 = 24266035,
    Dep3 = 46849904
};

/* the value of continuous attributes */
enum Cont_Var
{
    Production_time = 22836475
};

struct Device
{
    // Device_Type type;
    // Department dep;
    // Device_Level level;
    // int production_time;
    string id;
    vector<int> att_list;
    Device() {}
    Device(string id_val, vector<int> in_att)
    {
        id = id_val;
        att_list.insert(att_list.end(), in_att.begin(), in_att.end());
    }
};

struct TreeNode
{
    int attribute;
    int node_id;
    element_t t;
    element_t n;
    vector<element_t *> cdata;
    vector<TreeNode *> children;
    TreeNode() : attribute(0), node_id(0)
    {
        element_init_Zr(t, pairing);
        element_init_Zr(n, pairing);
    }

    TreeNode(int attr, int id, int t_val, int n_val)
        : attribute(attr), node_id(id)
    {
        element_init_Zr(t, pairing);
        element_init_Zr(n, pairing);
        element_set_si(t, t_val);
        element_set_si(n, n_val);
    }

    TreeNode(int attr, int id)
        : attribute(attr), node_id(id)
    {
        element_init_Zr(t, pairing);
        element_init_Zr(n, pairing);
    }
    void push_back_child(TreeNode *child)
    {
        children.push_back(child);
    }

    void push_compare_value(element_t v1)
    {
        element_t *newElement = (element_t *)pbc_malloc(sizeof(element_t));
        element_init_Zr(*newElement, pairing);
        element_set(*newElement, v1);
        cdata.push_back(newElement);
    }
    void push_compare_value(int v1)
    {
        element_t *newElement = (element_t *)pbc_malloc(sizeof(element_t));
        element_init_Zr(*newElement, pairing);
        element_set_si(*newElement, v1);
        cdata.push_back(newElement);
    }
};

mpz_t p;
element_t g, g_a, b, pp_a, pp_h, e_gg;
map<int, element_t *> att_table; // the public attributes table
map<int, int> index_of_att;      // the order of the attributes
vector<int> cont_list;           // continuous variable list
vector<int> tmpConditionTable;   // temporary decrypt condition table
Device *dev1;
vector<string> vid; // the vid of device
int tmp_cond_pos;   // the temporary position in tmpConditionTable

vector<vector<int>> all_att_vector = {
    {Type1, Type2, Type3},
    {Level1, Level2, Level3},
    {Dep1, Dep2, Dep3},
    {Production_time}};

element_t test_g_r;

void generate_tree(element_t s, TreeNode *root);

/* generation of public parameters */
void generate_PP()
{
    pbc_param_t params;
    /**
     * 参数2有 128 位、160 位、256 位等，具体选择取决于应用的安全需求,security_para的长度
     * 应该至少是参数2的两倍。
     */

    pbc_param_init_a_gen(params, 256, security_para);
    pairing_init_pbc_param(pairing, params); // 初始化双线性对

    /* check and generate e(g,g)^a */
    element_t a;
    mpz_set(p, pairing->r);
    element_init_G1(g, pairing);    // g is in G1
    element_init_GT(pp_a, pairing); // result is in GT
    element_init_Zr(a, pairing);    // a is in Zr
    element_random(g);              // 生成群G1的生成元
    element_random(a);              // 随机数a
    element_printf("Generator g for G1: \n%B\n", g);
    element_printf("Generate a: \n%B\n", a);

    element_init_G1(g_a, pairing); // g*a only known by third-party
    element_pow_zn(g_a, g, a);
    pairing_apply(pp_a, g_a, g, pairing);
    element_printf("e(g,g)^a: \n%B\n", pp_a); // 输出e(g^a, g)

    element_init_GT(e_gg, pairing);
    pairing_apply(e_gg, g, g, pairing); // 计算 e(g, g)

    element_init_Zr(b, pairing);
    element_random(b);
    element_init_G1(pp_h, pairing);
    element_pow_zn(pp_h, g, b);

    element_printf("h = g^b: \n%B\n", pp_h); // 输出h = g^b
}

void generate_VID(vector<string> &vid, string att)
{
    if (vid.size())
    {
        vid.push_back(hashMessages(vid[vid.size() - 1], att));
    }
    else
    {
        vid.push_back(hashStringToFixedLength(att));
    }
}

/* generate VID for attribute */
void generate_VID(vector<string> &vid, element_t att)
{
    size_t size = element_length_in_bytes(att);
    vector<unsigned char> byte_array(size);
    element_to_bytes(byte_array.data(), att);
    string tmpstr(byte_array.begin(), byte_array.end());
    // cout << tmpstr << endl;

    generate_VID(vid, tmpstr);
}

void set_index_of_att(int att, int index)
{
    index_of_att[att] = index;
}

void set_pub_param_of_att(int att)
{
    element_t *hashdigest = (element_t *)pbc_malloc(sizeof(element_t));
    string s1 = to_string(att);
    element_init_G1(*hashdigest, pairing);
    element_from_hash(*hashdigest, (void *)s1.data(), s1.size());
    att_table[att] = hashdigest;
}

void creat_index_of_att(vector<vector<int>> input_att)
{
    int pos = 0;
    for (vector<int> v : input_att)
    {
        pos++;
        for (int att : v)
        {
            set_index_of_att(att, pos);
            set_pub_param_of_att(att);
        }
    }
    cout << "creat_index_of_att finish" << endl;
}

/* generate attribute key for each attribute */
void generate_key_for_attribute(int att, element_t g_r, element_t &key1, element_t &key2, vector<string> &vid)
{

    element_t *hashdigest = (element_t *)pbc_malloc(sizeof(element_t));
    if (att_table.find(att) == att_table.end())
    {
        cout << "this attribution not initialized by TTP" << endl;
        return;
    }
    else
    {
        element_init_G1(*hashdigest, pairing);
        element_set(*hashdigest, *att_table[att]);
    }

    element_t r1;
    element_init_Zr(r1, pairing);
    element_random(r1); // choose random value for attribute
    element_init_G1(key1, pairing);
    element_init_G1(key2, pairing);

    element_pow_zn(key1, *hashdigest, r1); // compute g^{r}PA^{r'} for each attribute
    element_mul(key1, g_r, key1);
    element_pow_zn(key2, g, r1); // compute g^{r'} for each attribute

    generate_VID(vid, *hashdigest);
}

void generate_key_for_con_attribute(int att, element_t g_r, element_t &key1, element_t &key2, vector<string> &vid)
{
    element_t *hashdigest = (element_t *)pbc_malloc(sizeof(element_t));
    if (att_table.find(att) == att_table.end())
    {
        cout << "this attribution not initialized by TTP" << endl;
        return;
    }
    else
    {
        element_init_G1(*hashdigest, pairing);
        element_set(*hashdigest, *att_table[att]);
    }

    element_t r1;
    element_init_Zr(r1, pairing);
    element_random(r1); // choose random value for attribute
    element_init_G1(key1, pairing);
    element_init_G1(key2, pairing);

    element_pow_zn(key1, *hashdigest, r1); // compute g^{r}PA^{r'} for each attribute
    element_mul(key1, g_r, key1);
    element_pow_zn(key2, g, r1); // compute g^{r'} for each attribute
}

/**according to the attribute of device, the trust center generate
 *  key for the device, also generate the VID
 */
void generate_key(Device *dev1, vector<element_t *> &key_list, vector<string> &vid)
{
    element_t b_inverse, r, g_r;

    element_init_Zr(b_inverse, pairing);
    element_init_Zr(r, pairing);
    element_init_G1(g_r, pairing);

    element_random(r);
    element_pow_zn(g_r, g, r);

    element_init_G1(test_g_r, pairing);
    element_set(test_g_r, g_r);
    // element_printf("the test_g_r is:\n%B\n", test_g_r);

    element_t *key_d = (element_t *)pbc_malloc(sizeof(element_t));
    element_init_G1(*key_d, pairing);
    element_mul(*key_d, g_r, g_a); // compute g^{a+r}
    element_invert(b_inverse, b);  // compute 1/b

    element_pow_zn(*key_d, *key_d, b_inverse); // compute g^{(a+r)/b} which is the key of device
    key_list.push_back(key_d);
    generate_VID(vid, dev1->id);

    for (int i = 0; i < Discrete_Var_Num; i++) // generate discreate attribute key
    {
        element_t *key_d1 = (element_t *)pbc_malloc(sizeof(element_t));
        element_t *key_d11 = (element_t *)pbc_malloc(sizeof(element_t));
        generate_key_for_attribute(dev1->att_list[i], g_r, *key_d1, *key_d11, vid);
        key_list.push_back(key_d1);
        key_list.push_back(key_d11);
    }
    for (int i = 0; i < Continuous_Var_Num; i++) // generate continuous attribute key
    {
        element_t *key_d1 = (element_t *)pbc_malloc(sizeof(element_t));
        element_t *key_d11 = (element_t *)pbc_malloc(sizeof(element_t));
        generate_key_for_con_attribute(cont_list[i], g_r, *key_d1, *key_d11, vid);
        generate_VID(vid, to_string(dev1->att_list[Discrete_Var_Num + i]));
        key_list.push_back(key_d1);
        key_list.push_back(key_d11);
    }
    // cout << "device " << dev1->id << " generation of key finished" << endl;
}

TreeNode *buildtree1()
{
    TreeNode *root = new TreeNode(0, 1345, 2, 4);
    root->push_back_child(new TreeNode(0, 1346, 1, 2));               // Type1 || Type2
    root->push_back_child(new TreeNode(0, 1353, 2, 2));               // Type3 && Level1
    root->push_back_child(new TreeNode(Production_time, 1351, 1, 0)); // prod_time > give time
    root->children[2]->push_compare_value(1231213);                   // set give time 1231213
    root->push_back_child(new TreeNode(0, 1354, 0, 0));               // not structure

    root->children[0]->push_back_child(new TreeNode(Type1, 1347));
    root->children[0]->push_back_child(new TreeNode(Type2, 1348));

    root->children[1]->push_back_child(new TreeNode(Type3, 1349));
    root->children[1]->push_back_child(new TreeNode(Level1, 1350));

    root->children[3]->push_back_child(new TreeNode(Dep2, 1355)); // add not child structure

    return root;
}

TreeNode *buildtree2()
{
    TreeNode *root = new TreeNode(0, 1345, 2, 4);

    root->children[0] = new TreeNode(0, 1346, 1, 2); // Type1 || Type2
    root->children[0]->children[0] = new TreeNode(Type1, 1347);
    root->children[0]->children[1] = new TreeNode(Type2, 1348);

    root->children[1] = new TreeNode(0, 1353, 2, 2); // Dep1 && Level1
    root->children[1]->children[0] = new TreeNode(Dep1, 1349);
    root->children[1]->children[1] = new TreeNode(Level1, 1350);

    root->children[2] = new TreeNode(Production_time, 1351, 2, 1); // time1 <= production_time < time2
    root->children[2]->push_compare_value(1231211);                // set give time1 1231211
    root->children[2]->push_compare_value(1231213);                // set give time2 1231213

    root->children[3] = new TreeNode(Dep2, 1354, 0, 1);
    return root;
}

/* generate polynomial and calculate the value of children */
void generate_polynomial(element_t s, TreeNode *root)
{
    int t = element_to_si(root->t);
    mpz_t *coef = new mpz_t[t];

    // element_printf("the secret of %d is:\n%B\n", root->node_id, s);
    generatepoly(t, p, coef, state);
    element_to_mpz(coef[t - 1], s);
    // for (size_t i = 0; i < t - 1; i++)
    // {
    //     mpz_set_si(coef[i], 3);
    // }

    for (int i = 0; i < root->children.size(); i++)
    {
        element_t *tmps = (element_t *)pbc_malloc(sizeof(element_t));
        element_init_Zr(*tmps, pairing);
        generateshare(t, root->children[i]->node_id, p, coef, *tmps);
        // element_printf("the secret share of %d is:\n%B\n", root->children[i]->node_id, *tmps);
        generate_tree(*tmps, root->children[i]);
    }
}

void generate_tree_not_struct(TreeNode *root)
{
    if (root->attribute == 0) // non-leaf
    {
        int t = element_to_si(root->t);
        if (t == 0)
        {
            for (size_t i = 0; i < root->children.size(); i++)
            {
                generate_tree_not_struct(root->children[i]);
            }
        }
        else
        {
            for (size_t i = 0; i < root->children.size(); i++)
            {
                generate_tree_not_struct(root->children[i]);
            }
        }
    }
    else // leaf
    {
    }
}

void generate_tree_con_struct(element_t s, TreeNode *root)
{
    element_t *c1 = (element_t *)pbc_malloc(sizeof(element_t));
    element_t *c2 = (element_t *)pbc_malloc(sizeof(element_t));

    element_init_G1(*c1, pairing);
    element_init_G1(*c2, pairing);
    element_pow_zn(*c1, g, s);
    element_pow_zn(*c2, *att_table[root->attribute], s);

    element_t tmp;
    element_init_GT(tmp, pairing);
    pairing_apply(tmp, *c1, test_g_r, pairing);
    // element_printf("the encrypt_node of %d is:\n%B\n", root->node_id, s);
    // element_printf("the encrypt_node of %d is:\n%B\n", root->node_id, tmp);

    root->cdata.push_back(c1); // c1 = g^s
    root->cdata.push_back(c2);
}

void generate_tree(element_t s, TreeNode *root)
{
    if (root->attribute == 0) // non-leaf
    {
        int t = element_to_si(root->t);
        if (t == 0) // NOT structure
        {
            // add cdata
            element_t *c1 = (element_t *)pbc_malloc(sizeof(element_t));
            element_t *c2 = (element_t *)pbc_malloc(sizeof(element_t));
            element_init_G1(*c1, pairing);
            element_init_G1(*c2, pairing);
            element_pow_zn(*c1, g, s);
            int pos = all_att_vector[Discrete_Var_Num][0]; // choose the first Continuous_Var
            element_pow_zn(*c2, *att_table[pos], s);

            // element_t tmp;
            // element_init_GT(tmp, pairing);
            // pairing_apply(tmp, *c1, test_g_r, pairing);
            // element_printf("the encrypt_node of %d is:\n%B\n", root->node_id, tmp);

            root->cdata.push_back(c1); // c1 = g^s
            root->cdata.push_back(c2); // c2 = PA^s---->PA==root->n--->PA是从连续条件中任意选择的一个，保证所有共用一个

            // 不需要添加后续的节点数据
            for (size_t i = 0; i < root->children.size(); i++)
            {
                generate_tree_not_struct(root->children[i]);
            }
        }
        else if (t == 1) // OR structure
        {
            for (size_t i = 0; i < root->children.size(); i++)
            {
                generate_tree(s, root->children[i]);
            }
        }
        else // AND & Treshold structure
        {
            generate_polynomial(s, root);
        }
    }
    else // leaf
    {
        if (index_of_att[root->attribute] > Discrete_Var_Num) // the continuous variable
        {
            generate_tree_con_struct(s, root);
        }
        else
        {
            element_init_G1(root->t, pairing);
            element_init_G1(root->n, pairing);
            element_pow_zn(root->t, g, s);
            // element_t test_e_rs;
            // element_init_GT(test_e_rs, pairing);
            // pairing_apply(test_e_rs, test_g_r, root->t, pairing);
            // element_printf("the encrypt_node of %d is:\n%B\n", root->node_id, test_e_rs);
            element_pow_zn(root->n, *att_table[root->attribute], s);
            // element_printf("the encrypt_node PA of %d is:\n%B\n", root->node_id, *att_table[root->attribute]);
            // element_printf("the encrypt_node s of %d is:\n%B\n", root->node_id, s);
        }
    }
}

TreeNode *generate_access_tree(element_t s)
{
    TreeNode *root = buildtree1();
    generate_tree(s, root);
    cout << "the access control tree generation finished" << endl;
    return root;
}

void encrypt_message(element_t message, element_t s, element_t c1, element_t c2)
{
    element_init_GT(c1, pairing);
    element_pow_zn(c1, pp_a, s);  // e(g,g)^{\alpha s}
    element_mul(c1, c1, message); // Me(g,g)^{\alpha s}

    element_init_G1(c2, pairing);
    element_pow_zn(c2, pp_h, s); // h^s= g^{\beta s}
}

/* for the children of not structure, we only calculate the true or false */
bool decrypt_tree_not_node(TreeNode *root, vector<element_t *> devkeys)
{
    if (root->attribute == 0) // non-leaf
    {
        int t = element_to_si(root->t);
        if (t == 0)
        {
            if (decrypt_tree_not_node(root->children[0], devkeys))
                return false;
            else
                return true;
        }
        else if (t == 1)
        {
            element_t childdata;
            for (size_t i = 0; i < root->children.size(); i++)
            {
                if (decrypt_tree_not_node(root->children[i], devkeys))
                {
                    return true;
                }
            }
            return false;
        }
        else
        {
            int cnt = 0;
            for (size_t i = 0; i < root->children.size(); i++)
            {
                if (decrypt_tree_not_node(root->children[i], devkeys))
                    cnt++;
                if (cnt == t)
                    return true;
            }
            return false;
        }
    }
    else // leaf
    {
        bool ret = dev1->att_list[index_of_att[root->attribute] - 1] == root->attribute;

        tmpConditionTable.push_back(ret);
        tmpConditionTable.push_back(root->attribute);
        if (ret)
            return true;
        else
            return false;
    }
}

bool decrypt_tree_con_node(TreeNode *root, vector<element_t *> devkeys, element_t *nodedata, int keypos)
{
    int t = element_to_si(root->t);
    int n = element_to_si(root->n);
    mpz_t tmpdata, compdata;
    mpz_inits(tmpdata, compdata, nullptr);
    element_to_mpz(compdata, *root->cdata[0]);
    mpz_set_ui(tmpdata, dev1->att_list[keypos - 1]);
    int cmp = mpz_cmp(tmpdata, compdata);
    element_init_GT(*nodedata, pairing);

    int start = element_to_si(root->t); // the start position of c, c'
    element_t c1, c2;
    element_init_GT(c1, pairing);
    element_init_GT(c2, pairing);

    pairing_apply(c1, *devkeys[2 * keypos - 1], *root->cdata[start], pairing); // e(d, c)
    pairing_apply(c2, *devkeys[2 * keypos], *root->cdata[start + 1], pairing); // e(d', c')
    element_div(*nodedata, c1, c2);                                            // e(g,g)^{r,s}
    // element_printf("the decrypt_tree of %d is:\n%B\n", root->node_id, *nodedata);

    tmpConditionTable.push_back(true);
    tmpConditionTable.push_back(dev1->att_list[keypos - 1]);

    bool satisfy = false;
    if (t == 1)
    {

        switch (n)
        {
        case 0:
            if (cmp > 0)
                return true;
            else
                return false;
            break;
        case 1:
            if (cmp < 0)
                return true;
            else
                return false;
            break;
        case 2:
            if (cmp == 0)
                return true;
            else
                return false;
            break;
        default:
            return false;
            break;
        }
    }
    else
    {
        mpz_t compdata1;
        mpz_inits(compdata1);
        element_to_mpz(compdata1, *root->cdata[1]);
        int cmp1 = mpz_cmp(tmpdata, compdata1);

        switch (n)
        {
        case 0:
            if (cmp > 0 && cmp1 < 0)
                satisfy = true;
            else
                satisfy = false;
            break;
        case 1:
            if ((cmp > 0 || cmp == 0) && cmp1 < 0)
                satisfy = true;
            else
                satisfy = false;
            break;
        case 2:
            if (cmp > 0 && (cmp1 < 0 || cmp1 == 0))
                satisfy = true;
            else
                satisfy = false;
            break;
        case 3:
            if ((cmp > 0 || cmp == 0) && (cmp1 < 0 || cmp1 == 0))
                satisfy = true;
            else
                satisfy = false;
            break;
        default:
            break;
        }
    }
    tmpConditionTable[tmpConditionTable.size() - 2] = satisfy;
    return satisfy;
}

void TreeNodeSecretRecover(vector<int> id_list, vector<element_t *> d, element_t *result)
{
    int len = id_list.size();
    mpz_t term, temp, sum;
    mpz_inits(term, temp, sum, NULL);
    element_set0(*result);

    vector<mpz_class> k;
    for (size_t i = 0; i < id_list.size(); i++)
    {
        mpz_class mpz_value(id_list[i]);
        k.push_back(mpz_value);
    }

    element_t term1;
    element_init_GT(term1, pairing);

    for (int i = 0; i < len; i++)
    {
        mpz_set_ui(term, 1);

        for (int j = 0; j < len; j++) // calculate the delta_{i,sx(0)}
        {
            if (j != i)
            {
                mpz_sub(temp, k[j].get_mpz_t(), k[i].get_mpz_t());
                mpz_invert(temp, temp, p); // 求逆元
                mpz_mul(temp, temp, k[j].get_mpz_t());
                mpz_mul(term, term, temp);
                mpz_mod(term, term, p);
            }
        }
        element_pow_mpz(term1, *d[i], term);
        element_mul(*result, term1, *result);
    }
    // element_printf("the result of recover is:\n%B\n", *result);

    mpz_clears(term, temp, sum, NULL);
}

bool decrypt_tree(TreeNode *root, vector<element_t *> devkeys, element_t *nodedata)
{
    element_init_GT(*nodedata, pairing);
    if (root->attribute == 0) // non-leaf
    {
        int t = element_to_si(root->t);
        if (t == 0)
        {
            element_t c1, c2;
            element_init_GT(c1, pairing);
            element_init_GT(c2, pairing);
            int pos = Discrete_Var_Num * 2 + 1;
            pairing_apply(c1, *devkeys[pos], *root->cdata[0], pairing);     // e(d, c)
            pairing_apply(c2, *devkeys[pos + 1], *root->cdata[1], pairing); // e(d', c')
            element_div(*nodedata, c1, c2);                                 // e(g,g)^{r,s}
            // element_printf("the decrypt_tree of %d is:\n%B\n", root->node_id, *nodedata);

            if (decrypt_tree_not_node(root->children[0], devkeys))
                return false;
            else
            {
                return true;
            }
        }
        else if (t == 1)
        {
            element_t *childdata = (element_t *)pbc_malloc(sizeof(element_t));
            for (size_t i = 0; i < root->children.size(); i++)
            {
                if (decrypt_tree(root->children[i], devkeys, childdata))
                {
                    element_set(*nodedata, *childdata);
                    return true;
                }
            }
            return false;
        }
        else
        {
            int cnt = 0;
            vector<int> id_list;
            vector<element_t *> value_list;
            for (size_t i = 0; i < root->children.size(); i++)
            {
                element_t *tmpnodedata = (element_t *)pbc_malloc(sizeof(element_t));
                element_init_GT(*tmpnodedata, pairing);
                if (decrypt_tree(root->children[i], devkeys, tmpnodedata))
                {
                    cnt++;
                    id_list.push_back(root->children[i]->node_id);
                    value_list.push_back(tmpnodedata);
                }
                if (cnt == t)
                {
                    TreeNodeSecretRecover(id_list, value_list, nodedata);
                    return true;
                }
            }
            return false;
        }
    }
    else // leaf
    {
        int keypos = index_of_att[root->attribute];
        bool ret;
        if (keypos > Discrete_Var_Num)
        {
            ret = decrypt_tree_con_node(root, devkeys, nodedata, keypos);
            tmpConditionTable.push_back(ret);
            tmpConditionTable.push_back(dev1->att_list[keypos - 1]);
            return ret;
        }
        else
        {
            ret = (dev1->att_list[keypos - 1] == root->attribute);
            tmpConditionTable.push_back(ret);
            tmpConditionTable.push_back(0);
            if (!ret)
                return false;
            element_t c1, c2;
            element_init_GT(c1, pairing);
            element_init_GT(c2, pairing);
            pairing_apply(c1, *devkeys[2 * keypos - 1], root->t, pairing); // e(d, c)
            pairing_apply(c2, *devkeys[2 * keypos], root->n, pairing);     // e(d', c')
            element_div(*nodedata, c1, c2);                                // e(g,g)^{r,s}
            // element_printf("the decrypt_tree of %d is:\n%B\n", root->node_id, nodedata);
            return true;
        }
    }
}

void decrypt_message(element_t c1, element_t c2, TreeNode *root, vector<element_t *> devkeys, element_t message)
{
    element_t tmp;
    element_init_GT(message, pairing);
    element_init_GT(tmp, pairing);

    element_t *rootkey = (element_t *)pbc_malloc(sizeof(element_t));
    element_init_GT(*rootkey, pairing);

    bool output = decrypt_tree(root, devkeys, rootkey); // decrypt the access control tree to get the root nodedata
    if (output == false)
    {
        cout << "the decrypt tree failed" << endl;
    }
    else
    {
        element_printf("the decrypt rootkey is:\n%B\n", rootkey);
    }

    pairing_apply(tmp, c2, *devkeys[0], pairing); // e(c,d)
    element_div(tmp, tmp, *rootkey);              // e(c,d) / rootkey
    // element_printf("the decrypt e(c,d) / rootkey is:\n%B\n", tmp);
    // element_printf("the decrypt c1 is:\n%B\n", c1);
    element_div(message, c1, tmp); //  c1 / (e(c,d) / rootkey)
    element_printf("the decrypt message is:\n%B\n", message);
}

bool check_VID(int pos, int tmpvalue)
{
    int cmp = vid[pos].compare(hashMessages(vid[pos - 1], to_string(tmpvalue)));
    return cmp == 0;
}

bool check_VID(int pos, element_t att)
{
    size_t size = element_length_in_bytes(att);
    vector<unsigned char> byte_array(size);
    element_to_bytes(byte_array.data(), att);
    string tmpstr(byte_array.begin(), byte_array.end());
    // cout << tmpstr << endl;

    int cmp = vid[pos].compare(hashMessages(vid[pos - 1], tmpstr));
    return cmp == 0;
}

bool check_VID_con_struct(TreeNode *root, int tmppos, vector<int> &tmpcondtab)
{
    bool tmpbool = tmpcondtab[tmp_cond_pos];
    int tmpvalue = tmpcondtab[tmp_cond_pos + 1];
    int t = element_to_si(root->t);
    int n = element_to_si(root->n);
    tmp_cond_pos += 2;

    bool ret = false;
    int cmp_value1 = element_to_si(*root->cdata[0]);
    if (t == 1)
    {
        switch (n)
        {
        case 0:
            if (tmpbool && tmpvalue > cmp_value1)
                ret = check_VID(tmppos, tmpvalue);
            break;
        case 1:
            if (tmpbool && tmpvalue < cmp_value1)
                ret = check_VID(tmppos, tmpvalue);
            break;
        case 2:
            if (tmpbool && tmpvalue < cmp_value1)
                ret = check_VID(tmppos, tmpvalue);
            break;
        default:
            break;
        }
        return ret;
    }
    else
    {
        int cmp_value2 = element_to_si(*root->cdata[0]);
        switch (n)
        {
        case 0:
            if (tmpbool && tmpvalue > cmp_value1 && tmpvalue < cmp_value2)
                ret = check_VID(tmppos, tmpvalue);
            break;
        case 1:
            if (tmpbool && tmpvalue >= cmp_value1 && tmpvalue < cmp_value2)
                ret = check_VID(tmppos, tmpvalue);
            break;
        case 2:
            if (tmpbool && tmpvalue > cmp_value1 && tmpvalue <= cmp_value2)
                ret = check_VID(tmppos, tmpvalue);
            break;
        case 3:
            if (tmpbool && tmpvalue >= cmp_value1 && tmpvalue <= cmp_value2)
                ret = check_VID(tmppos, tmpvalue);
            break;
        default:
            break;
        }
        return ret;
    }
}

bool check_VID_tree(TreeNode *root, vector<int> &tmpcondtab)
{
    if (root->attribute == 0) // non-leaf
    {
        int t = element_to_si(root->t);
        if (t == 0)
        {
            if (check_VID_tree(root->children[0], tmpcondtab))
                return false;
            else
                return true;
        }
        else if (t == 1)
        {
            element_t childdata;
            for (size_t i = 0; i < root->children.size(); i++)
            {
                if (check_VID_tree(root->children[i], tmpcondtab))
                {
                    return true;
                }
            }
            return false;
        }
        else
        {
            int cnt = 0;
            for (size_t i = 0; i < root->children.size(); i++)
            {
                if (check_VID_tree(root->children[i], tmpcondtab))
                {
                    cnt++;
                }
                if (cnt == t)
                {
                    return true;
                }
            }
            return false;
        }
    }
    else // leaf
    {
        int keypos = index_of_att[root->attribute];
        if (keypos > Discrete_Var_Num)
        {
            return check_VID_con_struct(root, keypos, tmpcondtab);
        }
        else
        {
            if (tmpcondtab[tmp_cond_pos] == true)
            {
                tmp_cond_pos += 2;
                return check_VID(keypos, *att_table[root->attribute]);
            }
            else
            {
                tmp_cond_pos += 2;
                return false;
            }
        }
    }
}

void phrase_cut(string name)
{
    cout << endl;

    for (int i = 0; i < 40; i++)
    {
        cout << "=";
    }
    cout << name;
    for (int i = 0; i < 40; i++)
    {
        cout << "=";
    }

    cout << endl;
    cout << endl;
}

bool check_message(element_t m1, element_t m2)
{
    int ret = element_cmp(m1, m2);
    if (ret == 0)
        return true;
    else
        return false;
}

void creat_test_device(int dev_num, vector<Device *> &devlist, int att_num)
{
    int start_num = 12350;
    for (size_t i = 0; i < dev_num; i++)
    {
        Device *dev_tmp;
        string id_tmp = to_string(start_num + i);
        vector<int> dev_att_tmp;
        // for (size_t i = 0; i < 3; i++)
        // {
        //     dev_att_tmp.push_back(all_att_vector[i][getRandomNumber_givenum(2)]);
        // }
        // dev_att_tmp.push_back(1231213);
        for (size_t i = 0; i < att_num; i++)
        {
            dev_att_tmp.push_back(add_att_vector[i][getRandomNumber_givenum(2)]);
        }

        dev_tmp = new Device(id_tmp, dev_att_tmp);
        devlist.push_back(dev_tmp);
    }
}

void test_generate_key()
{
    creat_index_of_att(add_att_vector); // add more att to test

    vector<int> test_dev_num = {200, 400, 600, 800, 1000};
    vector<int> test_att_num = {10, 100};
    for (size_t i = 0; i < test_dev_num.size(); i++)
    {
        for (size_t j = 0; j < test_att_num.size(); j++)
        {
            vector<Device *> devlist;
            creat_test_device(test_dev_num[i], devlist, test_att_num[j]);
            auto start = chrono::high_resolution_clock::now();

            for (size_t k = 0; k < devlist.size(); k++)
            {
                vector<element_t *> key2;
                vector<string> vid2;
                generate_key(devlist[k], key2, vid2);
            }

            auto end = chrono::high_resolution_clock::now();
            chrono::duration<double> elapsed = end - start;
            cout << test_dev_num[i] << " device key with " << test_att_num[j] << " att" << " generation time taken: " << elapsed.count() << " seconds" << endl;
        }
    }
}

TreeNode *creat_test_tree_enc(int child_num, int node_type)
{
    int child_start_id = 1345;
    if (node_type == 1) //(t,n)
    {
        TreeNode *root = new TreeNode(0, child_start_id, child_num, 2 * child_num);
        for (size_t i = 1; i <= 2 * child_num; i++)
        {
            root->push_back_child(new TreeNode(0, child_start_id + i));
        }
        return root;
    }
    else if (node_type == 2) // and
    {
        TreeNode *root = new TreeNode(0, child_start_id, child_num, child_num);
        for (size_t i = 1; i <= child_num; i++)
        {
            root->push_back_child(new TreeNode(0, child_start_id + i));
        }
        return root;
    }
    else if (node_type == 3) // or
    {
        TreeNode *root = new TreeNode(0, child_start_id, 1, child_num);
        for (size_t i = 1; i <= child_num; i++)
        {
            root->push_back_child(new TreeNode(0, child_start_id + i));
        }
        return root;
    }
    else if (node_type == 4) // not & leaf & continuous att
    {
        TreeNode *root = new TreeNode(0, child_start_id, 1, child_num);
        for (size_t i = 1; i <= child_num; i++)
        {
            root->push_back_child(new TreeNode(Type1, child_start_id + i));
        }
        return root;
    }

    else
        return nullptr;
}

void test_single_generate_polynomial(element_t s, TreeNode *root)
{
    int t = element_to_si(root->t);
    mpz_t *coef = new mpz_t[t];

    generatepoly(t, p, coef, state);
    element_to_mpz(coef[t - 1], s);

    for (int i = 0; i < root->children.size(); i++)
    {
        element_t *tmps = (element_t *)pbc_malloc(sizeof(element_t));
        element_init_Zr(*tmps, pairing);
        generateshare(t, root->children[i]->node_id, p, coef, *tmps);

        element_init_G1(root->children[i]->t, pairing);
        element_init_GT(root->children[i]->n, pairing);
        element_pow_zn(root->children[i]->t, g, *tmps);
        pairing_apply(root->children[i]->n, test_g_r, root->children[i]->t, pairing);
    }
}

void test_single_generate_leaf(element_t s, TreeNode *root)
{
    element_init_G1(root->t, pairing);
    element_init_G1(root->n, pairing);
    element_pow_zn(root->t, g, s);
    element_pow_zn(root->n, *att_table[root->attribute], s);
}

void test_generate_leaf(element_t s, TreeNode *root)
{
    for (size_t i = 0; i < root->children.size(); i++)
    {
        test_single_generate_leaf(s, root->children[i]);
    }
}

void test_broadcast_enc()
{
    vector<int> test_child_num = {200, 400, 600, 800, 1000};
    vector<pair<string, int>> test_node_structure = {
        {"threshold", 1},
        {"and", 2},
        {"or", 3},
        {"not/leaf/continuous", 4},
    };
    element_t s;
    element_init_Zr(s, pairing);
    element_random(s);

    for (size_t i = 0; i < test_child_num.size(); i++)
    {
        for (size_t j = 0; j < test_node_structure.size(); j++)
        {
            int test_node_type = test_node_structure[j].second;
            TreeNode *root = creat_test_tree_enc(test_child_num[i], test_node_type);
            auto start = chrono::high_resolution_clock::now();
            switch (test_node_type)
            {
            case 1:
                test_single_generate_polynomial(s, root);
                break;
            case 2:
                test_single_generate_polynomial(s, root);
                break;
            case 4:
                test_generate_leaf(s, root);
                break;
            default:
                break;
            }

            auto end = chrono::high_resolution_clock::now();
            chrono::duration<double> elapsed = end - start;
            printf("%-20s", test_node_structure[j].first.data());
            cout << " with " << test_child_num[i] << " child" << " encryption time taken: " << elapsed.count() << " seconds" << endl;
        }
    }
}

TreeNode *create_test_tree_dec(int child_num, int node_type, element_t s)
{
    int child_start_id = 1345;

    if (node_type == 1) //(t,n)
    {
        TreeNode *root = new TreeNode(0, child_start_id, child_num, 2 * child_num);
        for (size_t i = 1; i <= 2 * child_num; i++)
        {
            root->push_back_child(new TreeNode(0, child_start_id + i));
        }
        test_single_generate_polynomial(s, root);
        return root;
    }
    else if (node_type == 2) // and
    {
        TreeNode *root = new TreeNode(0, child_start_id, child_num, child_num);
        for (size_t i = 1; i <= child_num; i++)
        {
            root->push_back_child(new TreeNode(0, child_start_id + i));
        }
        test_single_generate_polynomial(s, root);
        return root;
    }
    else if (node_type == 3) // or
    {
        TreeNode *root = new TreeNode(0, child_start_id, 1, child_num);
        for (size_t i = 1; i <= child_num; i++)
        {
            root->push_back_child(new TreeNode(0, child_start_id + i));
        }

        element_t tmp_gs;
        element_init_G1(tmp_gs, pairing);
        element_pow_zn(tmp_gs, g, s);
        element_init_GT(root->children[0]->n, pairing);
        pairing_apply(root->children[0]->n, test_g_r, tmp_gs, pairing);

        return root;
    }
    else if (node_type == 4) // not & leaf & continuous att
    {
        TreeNode *root = new TreeNode(0, child_start_id, 1, child_num);
        for (size_t i = 0; i < child_num; i++)
        {
            child_start_id++;
            root->push_back_child(new TreeNode(Type1, child_start_id));
        }
        for (size_t i = 0; i < child_num; i++)
        {
            element_init_G1(root->children[i]->t, pairing);
            element_init_G1(root->children[i]->n, pairing);
            element_pow_zn(root->children[i]->t, g, s);
            element_pow_zn(root->children[i]->n, *att_table[root->children[i]->attribute], s);
        }

        return root;
    }
    else
        return nullptr;
}

void test_single_dec_poly(TreeNode *root)
{
    int t = element_to_si(root->t);
    vector<int> id_list;
    vector<element_t *> value_list;
    for (size_t i = 0; i < t; i++)
    {
        id_list.push_back(root->children[i]->node_id);
        element_t *tmpnodedata = (element_t *)pbc_malloc(sizeof(element_t));
        element_init_GT(*tmpnodedata, pairing);
        element_set(*tmpnodedata, root->children[i]->n);
        value_list.push_back(tmpnodedata);
    }
    element_t *nodedata = (element_t *)pbc_malloc(sizeof(element_t));
    element_init_GT(*nodedata, pairing);
    TreeNodeSecretRecover(id_list, value_list, nodedata);
    // element_printf("the test recover is:\n%B\n", *nodedata);
}

void test_dec_node(TreeNode *root, vector<element_t *> &devkeys)
{

    element_t *nodedata = (element_t *)pbc_malloc(sizeof(element_t));
    element_init_GT(*nodedata, pairing);
    element_t c1, c2;
    element_init_GT(c1, pairing);
    element_init_GT(c2, pairing);
    pairing_apply(c1, *devkeys[0], root->t, pairing); // e(d, c)
    pairing_apply(c2, *devkeys[1], root->n, pairing); // e(d', c')
    element_div(*nodedata, c1, c2);                   // e(g,g)^{r,s}
                                                      // element_printf("the test recover is:\n%B\n", nodedata);
}

void test_single_dec_node(TreeNode *root, vector<element_t *> &devkeys)
{
    for (int i = 0; i < root->children.size(); i++)
    {
        test_dec_node(root->children[i], devkeys);
    }
}

void test_broadcast_dec()
{
    vector<int> test_child_num = {200, 400, 600, 800, 1000};
    vector<pair<string, int>> test_node_structure = {
        {"threshold", 1},
        {"and", 2},
        {"or", 3},
        {"not/leaf/continuous", 4},
    };

    /* initial the secret and the correct ans*/
    element_t s;
    element_init_Zr(s, pairing);
    element_random(s);
    element_t ans, tmp_gs;
    element_init_G1(tmp_gs, pairing);
    element_init_GT(ans, pairing);
    element_pow_zn(tmp_gs, g, s);
    pairing_apply(ans, test_g_r, tmp_gs, pairing);
    // element_printf("the correct recover is:\n%B\n", ans);

    /* initial the att key for the node decryption */
    vector<element_t *> test_dev_key;
    element_t *tmp1 = (element_t *)pbc_malloc(sizeof(element_t));
    element_t *tmp2 = (element_t *)pbc_malloc(sizeof(element_t));
    element_t r_i;
    element_init_Zr(r_i, pairing);
    element_random(r_i);
    element_init_G1(*tmp1, pairing);
    element_init_G1(*tmp2, pairing);

    element_pow_zn(*tmp1, *att_table[Type1], r_i);
    element_mul(*tmp1, *tmp1, test_g_r);
    element_pow_zn(*tmp2, g, r_i);
    test_dev_key.push_back(tmp1);
    test_dev_key.push_back(tmp2);

    for (size_t i = 0; i < test_child_num.size(); i++)
    {
        for (size_t j = 0; j < test_node_structure.size(); j++)
        {
            int test_node_type = test_node_structure[j].second;
            TreeNode *root = create_test_tree_dec(test_child_num[i], test_node_type, s);

            auto start = chrono::high_resolution_clock::now();
            switch (test_node_type)
            {
            case 1:
                test_single_dec_poly(root);
                break;
            case 2:
                test_single_dec_poly(root);
                break;
            case 4:
                test_single_dec_node(root, test_dev_key);
                break;
            default:
                break;
            }

            auto end = chrono::high_resolution_clock::now();
            chrono::duration<double> elapsed = end - start;
            printf("%-20s", test_node_structure[j].first.data());
            cout << " with " << test_child_num[i] << " child" << " decrypt time taken: " << elapsed.count() << " seconds" << endl;
        }
    }
}

TreeNode *create_checkatt_tree(int node_type, int layer)
{
    int child_start_id = 1345;
    int child_num = 10;
    queue<TreeNode *> tmpq;

    layer--;
    if (node_type == 1) //(t,n)
    {
        TreeNode *root = new TreeNode(0, child_start_id, child_num, 2 * child_num);
        tmpq.push(root);
        while (layer > 0)
        {
            queue<TreeNode *> tmpq1;
            while (!tmpq.empty())
            {
                tmpq1.push(tmpq.front());
                tmpq.pop();
            }
            while (!tmpq1.empty())
            {
                TreeNode *tmproot = tmpq1.front();
                tmpq1.pop();
                for (size_t i = 1; i <= 2 * child_num; i++)
                {
                    child_start_id++;
                    tmproot->push_back_child(new TreeNode(0, child_start_id, child_num, 2 * child_num));
                    tmpq.push(tmproot->children[i - 1]);
                }
            }
            layer--;
        }
        while (!tmpq.empty())
        {
            TreeNode *tmproot = tmpq.front();
            tmpq.pop();
            for (size_t i = 1; i <= 2 * child_num; i++)
            {
                child_start_id++;
                tmproot->push_back_child(new TreeNode(Type1, child_start_id));
            }
        }

        return root;
    }
    else if (node_type == 2) // and
    {
        TreeNode *root = new TreeNode(0, child_start_id, child_num, child_num);
        tmpq.push(root);
        layer--;
        while (layer > 0)
        {
            queue<TreeNode *> tmpq1;
            while (!tmpq.empty())
            {
                tmpq1.push(tmpq.front());
                tmpq.pop();
            }
            while (!tmpq1.empty())
            {
                TreeNode *tmproot = tmpq1.front();
                tmpq1.pop();
                for (size_t i = 1; i <= child_num; i++)
                {
                    child_start_id++;
                    tmproot->push_back_child(new TreeNode(0, child_start_id, child_num, child_num));
                    tmpq.push(tmproot->children[i - 1]);
                }
            }
            layer--;
        }
        while (!tmpq.empty())
        {
            TreeNode *tmproot = tmpq.front();
            tmpq.pop();
            for (size_t i = 1; i <= child_num; i++)
            {
                child_start_id++;
                tmproot->push_back_child(new TreeNode(Type1, child_start_id));
            }
        }

        return root;
    }
    else if (node_type == 3) // continuous att
    {
        TreeNode *root = new TreeNode(0, child_start_id, child_num, child_num);
        tmpq.push(root);
        layer--;
        while (layer > 0)
        {
            queue<TreeNode *> tmpq1;
            while (!tmpq.empty())
            {
                tmpq1.push(tmpq.front());
                tmpq.pop();
            }
            while (!tmpq1.empty())
            {
                TreeNode *tmproot = tmpq1.front();
                tmpq1.pop();
                for (size_t i = 1; i <= child_num; i++)
                {
                    child_start_id++;
                    tmproot->push_back_child(new TreeNode(0, child_start_id, child_num, child_num));
                    tmpq.push(tmproot->children[i - 1]);
                }
            }
            layer--;
        }
        while (!tmpq.empty())
        {
            TreeNode *tmproot = tmpq.front();
            tmpq.pop();
            for (size_t i = 1; i <= child_num; i++)
            {
                child_start_id++;
                tmproot->push_back_child(new TreeNode(Production_time, child_start_id, 1, 0));
                tmproot->children[i - 1]->push_compare_value(1231213);
            }
        }

        return root;
    }
    else
        return nullptr;
}

void traversal_tree(TreeNode *root, vector<int> &ret)
{
    int t = element_to_si(root->t);
    int n = element_to_si(root->n);
    if (root->children[0]->attribute == 0)
    {
        if (t == n)
        {
            for (size_t i = 0; i < n; i++)
            {
                traversal_tree(root->children[i], ret);
            }
        }
        else
        {
            int end = t / 2;
            for (int i = 0; i < end; i++)
            {
                traversal_tree(root->children[i], ret);
            }
            end = t / 2 * 3;
            for (int i = t / 2; i < end; i++)
            {
                traversal_tree(root->children[i], ret);
            }
        }
    }
    else
    {
        if (root->children[0]->attribute == Type1)
        {
            if (t == n)
            {
                for (int i = 0; i < n; i++)
                {
                    ret.push_back(true);
                    ret.push_back(0);
                }
            }
            else
            {
                for (int i = t / 2; i < t; i++)
                {
                    ret.push_back(false);
                    ret.push_back(0);
                }
                for (int i = 0; i < t; i++)
                {
                    ret.push_back(true);
                    ret.push_back(0);
                }
            }
        }
        else if (root->children[0]->attribute == Production_time)
        {
            for (size_t i = 0; i < n; i++)
            {
                ret.push_back(true);
                ret.push_back(1231214);
            }
        }
    }
}

vector<int> create_tmp_condition_table(TreeNode *root)
{
    vector<int> ret;
    traversal_tree(root, ret);
    return ret;
}

void test_check_att()
{
    vector<int> test_tree_layer = {1, 2, 3, 4, 5};
    vector<pair<string, int>> test_node_structure = {
        {"threshold", 1},
        {"and", 2},
        {"continuous", 3}};

    for (size_t i = 0; i < test_tree_layer.size(); i++)
    {
        for (size_t j = 0; j < test_node_structure.size(); j++)
        {
            int test_node_type = test_node_structure[j].second;
            TreeNode *root = create_checkatt_tree(test_node_type, test_tree_layer[i]);
            vector<int> tmpcontab = create_tmp_condition_table(root);
            bool turnout = false;

            tmp_cond_pos = 0;
            auto start = chrono::high_resolution_clock::now();
            switch (test_node_type)
            {
            case 1:
                turnout = check_VID_tree(root, tmpcontab);
                break;
            case 2:
                turnout = check_VID_tree(root, tmpcontab);
                break;
            case 3:
                turnout = check_VID_tree(root, tmpcontab);
                break;
            default:
                break;
            }

            auto end = chrono::high_resolution_clock::now();
            chrono::duration<double> elapsed = end - start;
            printf("%-15s", test_node_structure[j].first.data());
            cout << turnout << " with " << test_tree_layer[i] << " layer tree" << " decrypt time taken: " << elapsed.count() << " seconds" << endl;
        }
    }
}

int main(int argc, char const *argv[])
{
    gmp_randinit_default(state);
    gmp_randseed_ui(state, seed);

    cont_list.insert(cont_list.end(), {Production_time}); // the initialization of continuous attribute list

    generate_PP();
    phrase_cut("initialization");
    creat_index_of_att(all_att_vector); // simulate generation of keys for all devices which create a index table

    // test_generate_key();

    dev1 = new Device("12311", vector<int>{Type1, Level1, Dep2, 1231214}); // device key generation
    vector<element_t *> key1;
    generate_key(dev1, key1, vid);

    phrase_cut("key generation");

    element_t message, s;
    element_init_GT(message, pairing);
    element_init_Zr(s, pairing);
    element_random(message);
    element_random(s);
    element_printf("Broadcast message is:\n%B\n", message);
    element_printf("secret is:\n%B\n", s);

    element_t c1, c2;
    encrypt_message(message, s, c1, c2);
    TreeNode *root = generate_access_tree(s);

    // test_broadcast_enc();

    phrase_cut("encryption");

    // test_broadcast_dec();
    element_t message_d;
    decrypt_message(c1, c2, root, key1, message_d);
    phrase_cut("decryption");

    bool check = check_message(message, message_d);
    if (check)
    {
        cout << "success, the device decrypt the message" << endl;
    }
    else
    {
        cout << "wrong, the device not decrypt the message" << endl;
    }

    // test_check_att();

    tmp_cond_pos = 0;
    check = check_VID_tree(root, tmpConditionTable);
    if (check)
    {
        cout << "success, the device satisfy the condition of joinning group" << endl;
    }
    else
    {
        cout << "wrong, the device not satisfy the condition of joinning group" << endl;
    }

    return 0;
}
