/*
 * @Author: tomchenkang chenkang20122302@hotmail.com
 * @Date: 2023-10-13 01:08:31
 * @LastEditors: ck
 * @LastEditTime: 2023-12-25 00:56:26
 * @FilePath: /test/polycalculation.cpp
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */

#include <stdio.h>
#include <time.h>
#include <math.h>

clock_t start, stop;
double duration;  // 记录被测函数运行的时间，以秒为单位
#define MAXN 1000 // 多项式最大项数，最大项数加1
#define MAXK 1e4  // 被测函数最大重复调用次数

using namespace std;
double Polynomial_1(int n, double a[], double x)
{
    int i;
    double sum = 0;
    for (i = 0; i < n; i++)
        sum += a[i] * pow(x, i);
    return sum;
}

double Polynomial_2(int n, double a[], double x)
{
    int i;
    double sum = 0;
    for (i = n; i > 0; i--)
        sum = a[i - 1] + x * sum;
    return sum;
}

double Polynomial_3(int n, double a[], double x)
{
    int i;
    double sum = 0, tmp = 1;
    for (i = 0; i < n; i++)
    {
        sum += a[i] * tmp;
        tmp = tmp * x;
    }

    return sum;
}

/* 使用并行的方式来加速 */
double Polynomial_4(int n, double a[], double x)
{
    int i;
    double sum = 0, tmp = 1, tmp2 = x, tmp3 = x * x,tmp4 = x * x*x;
    int tmp1 = n - 1;

    for (i = 0; i < tmp1; i += 2)
    {
        sum += a[i] * tmp;
        sum += a[i + 1] * tmp2;
        // sum += a[i + 2] * tmp3;
        // sum += a[i + 3] * tmp4;
        tmp = tmp * x;
        tmp2 = tmp2 * x;
        // tmp3 = tmp3 * x;
        // tmp4 = tmp4 * x;
    }
    if (i < n)
    {
        sum += a[i] * tmp;
        i++;
    }
    // if (i < n)
    // {
    //     sum += a[i] * tmp2;
    //     i++;
    // }
    // if (i < n)
    // {
    //     sum += a[i] * tmp3;
    //     i++;
    // }

    return sum;
}

void run(double (*f)(int, double *, double), double a[], int case_n)
{
    // 此函数用于测试被测函数(*f)的运行时间，并且根据case_n输出相应的结果
    // case_n是输出的函数编号，1代表Polynomial_1, 2代表Polynomial_2
    int i;
    start = clock();           // 开始计时
    for (i = 0; i < MAXK; i++) // 重复调用函数已获得充分多的时钟打点数
        (*f)(MAXN, a, 1.1);
    stop = clock();                                       // 结束计时
    duration = ((double)(stop - start)) / CLOCKS_PER_SEC; // 计算运行时间
    printf("ticks %d = %f\n", case_n, (double)(stop - start));
    printf("duration 1 = %6.2e\n", duration);
}

int main()
{
    int i;
    double a[MAXN];
    for (i = 0; i < MAXN; i++) // 设置多项式的各项系数
        a[i] = (double)i;

    run(Polynomial_1, a, 1);
    run(Polynomial_2, a, 2);
    run(Polynomial_3, a, 3);
    run(Polynomial_4, a, 4);
    return 0;
}
