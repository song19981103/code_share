#include <iostream>
#include <openssl/bn.h>
#include <openssl/sha.h>
#include <openssl/evp.h>
#include <openssl/aes.h>
#include <string>
#include <cstring>
#include <vector>
#include <sstream>
#include <iomanip>
#include <gmpxx.h>

using namespace std;

/**
 * @description: 字符串转16进制字符串
 * @param {unsigned char} *byteArra， 原始字符串
 * @param {size_t} length，字符串长度
 * @return {*}
 */
string stringToHex(const unsigned char *byteArray, size_t length)
{
    stringstream hexStream;

    for (size_t i = 0; i < length; ++i)
    {
        hexStream << hex << setw(2) << setfill('0') << static_cast<int>(byteArray[i]);
    }

    return hexStream.str();
}

string hexToString(const string &hex)
{
    string result;
    for (size_t i = 0; i < hex.length(); i += 2)
    {
        // 从十六进制字符串中提取两个字符
        string byteString = hex.substr(i, 2);

        // 将提取的字符转换为整数
        unsigned char byte = static_cast<unsigned char>(stoi(byteString, nullptr, 16));

        // 将整数转换为字符并追加到结果字符串
        result.push_back(static_cast<char>(byte));
    }
    return result;
}


// vector<unsigned char> to hex
string uchar_to_hex_string(const vector<unsigned char>& data) {
    ostringstream oss;
    oss << hex << setfill('0');
    for (unsigned char c : data) {
        oss << setw(2) << static_cast<unsigned>(c);
    }
    return oss.str();
}

vector<unsigned char> mpz_to_uchar_vector(mpz_t num) {
    // 计算所需字节数
    size_t size = (mpz_sizeinbase(num, 2) + 7) / 8; // 二进制位数转为字节数
    vector<unsigned char> vec(size);

    // 导出到字节数组
    mpz_export(vec.data(), &size, 1, 1, 0, 0, num); // 大端序，1 字节单元
    vec.resize(size); // 调整大小，因为可能有前导零被省略

    return vec;
}

// vector<unsigned char> to mpz_t
void uchar_vector_to_mpz_hex(const vector<unsigned char>& data, mpz_t result) {
    string hex_str = uchar_to_hex_string(data);
    mpz_set_str(result, hex_str.c_str(), 16); // 基数 16 表示十六进制
}

vector<unsigned char> mpz_to_hash(mpz_t num) {
    size_t size = (mpz_sizeinbase(num, 2) + 7) / 8;
    unsigned char *buffer = (unsigned char *)malloc(size);
    mpz_export(buffer, &size, 1, 1, 0, 0, num);
    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256(buffer, size, hash);
    free(buffer);
    vector<unsigned char> vec(hash, hash + SHA256_DIGEST_LENGTH);
    return vec;
}

vector<unsigned char> encrypt_long_data(const vector<unsigned char>& plaintext,
                                            const vector<unsigned char>& key,
                                            const vector<unsigned char>& iv,
                                            vector<unsigned char>& tag) {
    EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new();
    vector<unsigned char> ciphertext(plaintext.size() + AES_BLOCK_SIZE); // 预留空间
    int len = 0, ciphertext_len = 0;

    // 初始化 AES-256-GCM
    if (!EVP_EncryptInit_ex(ctx, EVP_aes_256_gcm(), nullptr, nullptr, nullptr)) {
        throw runtime_error("Encryption init failed");
    }

    // 设置密钥和 IV
    if (!EVP_EncryptInit_ex(ctx, nullptr, nullptr, key.data(), iv.data())) {
        EVP_CIPHER_CTX_free(ctx);
        throw runtime_error("Key/IV setup failed");
    }

    // 加密数据
    if (!EVP_EncryptUpdate(ctx, ciphertext.data(), &len, plaintext.data(), plaintext.size())) {
        EVP_CIPHER_CTX_free(ctx);
        throw runtime_error("Encrypt update failed");
    }
    ciphertext_len = len;

    // 完成加密
    if (!EVP_EncryptFinal_ex(ctx, ciphertext.data() + len, &len)) {
        EVP_CIPHER_CTX_free(ctx);
        throw runtime_error("Encrypt final failed");
    }
    ciphertext_len += len;

    // 获取认证标签
    if (!EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_GET_TAG, 16, tag.data())) {
        EVP_CIPHER_CTX_free(ctx);
        throw runtime_error("Get tag failed");
    }

    EVP_CIPHER_CTX_free(ctx);
    ciphertext.resize(ciphertext_len); // 调整密文大小
    return ciphertext;
}

// 解密函数
vector<unsigned char> decrypt_long_data(const vector<unsigned char>& ciphertext,
                                            const vector<unsigned char>& key,
                                            const vector<unsigned char>& iv,
                                            const vector<unsigned char>& tag) {
    EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new();
    vector<unsigned char> plaintext(ciphertext.size());
    int len = 0, plaintext_len = 0;

    // 初始化 AES-256-GCM
    if (!EVP_DecryptInit_ex(ctx, EVP_aes_256_gcm(), nullptr, nullptr, nullptr)) {
        throw runtime_error("Decryption init failed");
    }

    // 设置密钥和 IV
    if (!EVP_DecryptInit_ex(ctx, nullptr, nullptr, key.data(), iv.data())) {
        EVP_CIPHER_CTX_free(ctx);
        throw runtime_error("Key/IV setup failed");
    }

    // 解密数据
    if (!EVP_DecryptUpdate(ctx, plaintext.data(), &len, ciphertext.data(), ciphertext.size())) {
        EVP_CIPHER_CTX_free(ctx);
        throw runtime_error("Decrypt update failed");
    }
    plaintext_len = len;

    // 设置认证标签
    if (!EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_TAG, 16, (void*)tag.data())) {
        EVP_CIPHER_CTX_free(ctx);
        throw runtime_error("Set tag failed");
    }

    // 验证并完成解密
    if (EVP_DecryptFinal_ex(ctx, plaintext.data() + len, &len) <= 0) {
        EVP_CIPHER_CTX_free(ctx);
        throw runtime_error("Decrypt final failed (authentication error)");
    }
    plaintext_len += len;

    EVP_CIPHER_CTX_free(ctx);
    plaintext.resize(plaintext_len); // 调整明文大小
    return plaintext;
}

// 辅助函数：打印十六进制
void print_hex(const string& label, const vector<unsigned char>& data, size_t max_len = 32) {
    cout << label << ": ";
    cout << hex << setfill('0');
    for (size_t i = 0; i < data.size() && i < max_len; i++) {
        cout << setw(2) << static_cast<unsigned>(data[i]);
    }
    cout << dec << "\n";
}



/**
 * @description: 选用256位的密钥加密明文（内部加密算法以及密钥位数可以调整，但要对应上）
 * @param {char} *key 密钥字符串
 * @param {int} keyLength 密钥长度
 * @param {char} *plaintext 明文字符串
 * @param {int} plaintextLength 明文长度
 * @param {unsigned char} **ciphertext 存储密文的位置
 * @param {int} *ciphertextLength 存储密文长度的位置
 * @return {*} 返回加密成功与否
 */
bool anyLengthKeyEnc(string key, int keyLength, string plaintext, int plaintextLength, unsigned char **ciphertext, int *ciphertextLength)
{
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();

    // 选择加密算法和模式
    const EVP_CIPHER *cipher = EVP_aes_256_cbc(); // 选择AES-256-CBC加密算法
    int blockSize = EVP_CIPHER_block_size(cipher);

    // 初始化加密上下文
    EVP_EncryptInit_ex(ctx, cipher, NULL, (const unsigned char *)key.data(), NULL);

    // 分配足够的内存来保存加密后的数据
    *ciphertext = new unsigned char[plaintextLength + blockSize];
    memset(*ciphertext, 0, plaintextLength + blockSize);

    // 执行加密
    int updateLength = 0;
    EVP_EncryptUpdate(ctx, *ciphertext, &updateLength, (const unsigned char *)plaintext.data(), plaintextLength);
    *ciphertextLength = updateLength;

    // 结束加密
    int finalLength = 0;
    EVP_EncryptFinal_ex(ctx, *ciphertext + updateLength, &finalLength);
    *ciphertextLength += finalLength;

    EVP_CIPHER_CTX_free(ctx);

    return true;
}

/**
 * @description: 选用256位的密钥解密密文与 anyLengthKeyEnc函数对应
 * @param {char} *key 密钥字符串
 * @param {int} keyLength 密钥长度
 * @param {char} *ciphertext 密文字符串
 * @param {int} ciphertextLength 密文长度
 * @param {unsigned char} **ciphertext 存储明文的位置
 * @param {int} *plaintextLength 存储明文长度的位置
 * @return {*}
 */
bool anyLengthKeyDec(const char *key, int keyLength, const char *ciphertext, int ciphertextLength, unsigned char **plaintext, int *plaintextLength)
{
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();

    // 选择解密算法和模式
    const EVP_CIPHER *cipher = EVP_aes_256_cbc(); // 选择AES-256-CBC解密算法
    int blockSize = EVP_CIPHER_block_size(cipher);

    // 初始化解密上下文
    EVP_DecryptInit_ex(ctx, cipher, NULL, (const unsigned char *)key, NULL);

    // 分配足够的内存来保存解密后的数据
    *plaintext = new unsigned char[ciphertextLength];
    memset(*plaintext, 0, ciphertextLength);

    // 执行解密
    int updateLength = 0;
    EVP_DecryptUpdate(ctx, *plaintext, &updateLength, (const unsigned char *)ciphertext, ciphertextLength);
    *plaintextLength = updateLength;

    // 结束解密
    int finalLength = 0;
    EVP_DecryptFinal_ex(ctx, *plaintext + updateLength, &finalLength);
    *plaintextLength += finalLength;

    EVP_CIPHER_CTX_free(ctx);

    return true;
}

string hashStringToFixedLength(const string input)
{
    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256_CTX sha256;
    SHA256_Init(&sha256);
    SHA256_Update(&sha256, input.c_str(), input.size());
    SHA256_Final(hash, &sha256);

    return stringToHex(hash, SHA256_DIGEST_LENGTH);
}

string hashStringToFixedLength(mpz_t num,unsigned char* hash_output){
    size_t size = (mpz_sizeinbase(num, 2) + 7) / 8; // 转换为字节长度
    unsigned char *buffer = (unsigned char *)malloc(size);

    if (!buffer) {
        fprintf(stderr, "Memory allocation failed\n");
        return nullptr;
    }

    mpz_export(buffer, &size, 1, 1, 0, 0, num); // 大端序，1字节单位
    SHA256(buffer, size, hash_output);

    free(buffer);
    return "nullptr";
}

string hashStringToFixedLength(mpz_t key1)
{
    char *str = mpz_get_str(NULL, 16, key1);
    return hashStringToFixedLength(str);
}

string hashStringToFixedLength(int key1)
{
    string str = to_string(key1);
    return hashStringToFixedLength(str);
}

string hashMessages(string m1, string m2){
    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256_CTX sha256;
    SHA256_Init(&sha256);
    SHA256_Update(&sha256, m1.c_str(), m1.size());
    SHA256_Update(&sha256, m2.c_str(), m2.size());
    SHA256_Final(hash, &sha256);

    return stringToHex(hash, SHA256_DIGEST_LENGTH);
}

void hashMessages(const char *m1, size_t m1_len, const char *m2, size_t m2_len, unsigned char *digest) {
    SHA256_CTX ctx;
    SHA256_Init(&ctx);
    SHA256_Update(&ctx, m1, m1_len);
    SHA256_Update(&ctx, m2, m2_len);
    SHA256_Final(digest, &ctx);
}

/*
 * 随机生成一个t-1阶多项式，p为大素数，coef为多项式系数列表[a_{t-1}, ..., a_1, a_0]
 * 多项式为f(x) = a_{t-1}x^{t-1} + ... + a_1x + a_0
 */
void generatepoly(int t, mpz_t p, mpz_t *coef, gmp_randstate_t state)
{
    for (size_t i = 0; i < t; i++)
    {
        mpz_init(coef[i]);
        mpz_urandomm(coef[i], state, p);
    }
}

/*
 * 根据多项式的系数列表coef，大素数p，代入值x，生成对应的多项式的值，也即是子秘密
 */
void generateshare(int t, mpz_t x, mpz_t p, mpz_t *coef, mpz_t ret)
{
    mpz_init_set_ui(ret, 0);

    for (size_t i = 0; i < t; i++)
    {   
        // f(x) = a_0  + a_1*x + ... + a_{t-1}*x^{t-1}
        mpz_mul(ret, ret, x);
        mpz_add(ret, coef[i], ret);
        mpz_mod(ret, ret, p);
        // mpz_mul(tmp, x, tmp);
        // mpz_mul(tmp1, tmp, coef[i]);
        // mpz_add(ret, ret, tmp1);
        // mpz_mod(ret, ret, p);
    }
}

void generateshare(int t, int x, mpz_t p, mpz_t *coef, element_t ret){
    mpz_t tmpx, tmpret;
    mpz_inits(tmpx,tmpret,NULL);
    
    mpz_set_ui(tmpx, x);    
    generateshare(t, tmpx, p, coef, tmpret);
    element_set_mpz(ret, tmpret);
}