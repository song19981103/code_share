#include <stdio.h>
#include <time.h>
#include <string.h>
#include <iostream>
#include <vector>

#include "miracl/miracl.h"
#include "miracl/mirdef.h"
using namespace std;

class device
{
private:
public:
    int tresh;              // 群组的门限值
    int member;             // 群组的成员数量
    int rand_size;          // 随机数的位数
    int p_size;             // 大素数的位数
    int port;               // 设备的通信地址（本demo中以端口号表示）
    big sharedata;          // 设备分享的数据
    big ownshare;           // 本设备的总秘密份额
    big groupsecret;        // 整个群组所有设备拥有的秘密值之和
    vector<big> coef;       // 存放多项式系数
    big p;                  // 群组的初始的大素数
    vector<big> key, value; // d存放的是随机数，k存放的是对应d中随机数代入多项式得到的值，
                            // 也即是分割后的子秘密份额（只作为验证使用）
    big datapiece;// 经过局部计算后的分片值
    big Deviceid; // 设备id，在群组中具有唯一性

    device(){};

    device(big deviceid) // 构造函数
    {
        Deviceid = deviceid;
    };
    void initial(int t, int n);
    void setid(); // demo随机生成id，真实设备可用设备的唯一id号
    void setrandsize(int rsize);
    void setpsize(int psize);
    void setprime(big p);

    void generatebigprime();
    void generatepoly();
    void secretsum(big subsecret);
    void totalsecretsum(big subsecret);

    void secretsub(big subsecret);
    void totalsecretsub(big subsecret);
    void getdatapiece(big c);
    big generateshare(big x);
    big reconstruct();
    big secretreconstruct(vector<big> secret, vector<big> id);
    big datashare(big data, big totalsecret);
    ~device();
};

/*  */
/**
 * @description: 根据消息的头将消息分类，设备收到不同的消息采取不同的动作
 * @param {string} str: 消息
 * @return {pair<int, int>}: 返回数对(a,b)，a为消息在action_map中的类别，
 * 				b为消息类别头的长度+1
 *
 */
/**
 * @description: 进行数据分片，返回的是分片值
 * @param {big} data：要进行分片的数据
 * @param {big} totalsecret：群组中的密钥值
 * @return {big}：返回分片值
 * @example: data = totalsecret * c, 返回c值
 */
big device::datashare(big data, big totalsecret)
{
    big one = mirvar(1), ret = mirvar(0);

    add(ret, totalsecret, ret);        // ret = totalsecret + 0
    xgcd(ret, this->p, ret, ret, ret); // ret =
    multiply(ret, data, ret);          // ret = ret * data = data * [(1/totalsecret) mod p]
    powmod(ret, one, this->p, ret);    // ret = ret mod p
    return ret;
}

/**
 * @description: 生成一个p_size位的大素数，并将其设置为参数
 * @return {*}
 */
void device::generatebigprime()
{
    big tmp = mirvar(0); // 初始化临时变量tmp=0
    do
    {
        bigdig(this->p_size, 10, tmp); // 随机生成一个p_size位十进制随机数
    } while (!isprime(tmp));           // 判断生成的随机数是不是素数
    this->p = tmp;                     // 设置参数为该大素数
}

/**
 * @description: 设备设置id，此处为随机生成，也可以可用设备本身的标识（群组中的设备不能有相同id）
 * @return {*}
 */
void device::setid()
{
    this->Deviceid = mirvar(0);
    bigdig(this->rand_size, 10, this->Deviceid); // 这将生成一个rand_size位十进制随机数
}

/**
 * @description: 设备设置随机数位数
 * @param {int} rsize
 * @return {*}
 */
void device::setrandsize(int rsize)
{
    this->rand_size = rsize;
}

/**
 * @description: 设备设置大素数位数
 * @param {int} psize
 * @return {*}
 */
void device::setpsize(int psize)
{
    this->p_size = psize;
}

/**
 * @description: 设备设置大素数
 * @param {big} p
 * @return {*}
 */
void device::setprime(big p)
{
    this->p = p;
}

/*  */
/**
 * @description: 设备初始化，设置门限值t，群组的成员数量为n，
 *               初始化自己的总秘密份额，群组秘密,分享的数据为0
 * @param {int} t：门限值
 * @param {int} n：群组成员数
 * @return {*}
 */
void device::initial(int t, int n)
{
    this->tresh = t;
    this->member = n;
    this->ownshare = mirvar(0);
    this->groupsecret = mirvar(0);
    this->sharedata = mirvar(0);
}

/**
 * @description: 设备生成多项式 f(x) = a_{t-1} * x^{t-1} +... + a_{1} * x^{1} + a_0,
 *                  将系数{a_{t-1} ,... ,a_{1}, a_0}存到系数列表中
 * @return {*}
 */
void device::generatepoly()
{
    big one = mirvar(1); // 初始化常数1
    this->coef.clear();  // 将系数列表清空
    for (size_t i = 0; i < this->tresh; i++)
    {
        big tmp = mirvar(0);              // 初始化临时变量为0
        bigdig(this->rand_size, 10, tmp); // 这将生成一个rand_size位十进制随机数
        powmod(tmp, one, this->p, tmp);   // 模p，tmp = tmp mod p
        this->coef.push_back(tmp);        // 将系数存在系数列表中
    }
}

/**
 * @description: 设备加入时，秘密份额添加
 * @param {big} subsecret: 新加入的设备计算的子秘密份额
 * @return {*}
 */
void device::secretsum(big subsecret)
{
    big one = mirvar(1); // 初始化单位值1
    // cotnum(this->ownshare, stdout);
    /* 将秘密份额加到总秘密份额中 ownshare = ownshare + subsecret */
    add(this->ownshare, subsecret, this->ownshare);
    powmod(this->ownshare, one, this->p, this->ownshare); // ownshare = ownshare mod p
}

/**
 * @description: 设备离开时，秘密份额移除
 * @param {big} subsecret: 离开设备的子秘密份额
 * @return {*}
 */
void device::secretsub(big subsecret)
{
    big one = mirvar(1); // 初始化单位值1
    /* 将秘密份额加到总秘密份额中 ownshare = ownshare - subsecret */
    subtract(this->ownshare, subsecret, this->ownshare);
    powmod(this->ownshare, one, this->p, this->ownshare); // ownshare = ownshare mod p
}

/**
 * @description: 设备加入时，群组的密钥发生变化
 * @param {big} subsecret: 新加入设备的秘密值
 * @return {*}
 */
void device::totalsecretsum(big subsecret)
{
    big one = mirvar(1); // 初始化单位值1
    /* groupsecret += subsecret,新设备加入时，更新群组的密钥 */
    add(this->groupsecret, subsecret, this->groupsecret);
    powmod(this->groupsecret, one, this->p, this->groupsecret); // groupsecret = groupsecret mod p
}

/**
 * @description: 设备离开时，群组的密钥发生变化
 * @param {big} subsecret: 离开设备的秘密值
 * @return {*}
 */
void device::totalsecretsub(big subsecret)
{
    big one = mirvar(1); // 初始化单位值1
    /* groupsecret -= subsecret,设备离开时，更新群组的密钥 */
    subtract(this->groupsecret, subsecret, this->groupsecret);
    powmod(this->groupsecret, one, this->p, this->groupsecret); // 取模 groupsecret = groupsecret mod p
}

/**
 * @description: 根据多项式的系数列表coef，大素数p，代入值x，生成对应的多项式的值，也即是子秘密
 * @param {big} x：设备的id值
 * @return {big}：返回计算出来的子秘密值
 */
big device::generateshare(big x)
{
    big ret = mirvar(0); // 初始化返回值为0
    big one = mirvar(1); // 初始化单位值1

    /**
     * 以(...((a_{t-1} * x + a_{t-2}) * x  + a_{t-3})+ ...a_0)计算方式计算
     * 或者以 a_0 + a_1*x + ... + a_{t-1}*x^{t-1} 计算方式计算（要反过来循环，
     * 因为系数列表按照指数高位到地位设置，最低位为设备的秘密值）
     */
    for (size_t i = 0; i < this->tresh; i++)
    {
        // f(x) = a_{t-1} * x^{t-1} +... + a_{1} * x^{1} + a_0

        multiply(ret, x, ret);        // ret = ret * x
        add(ret, this->coef[i], ret); // ret += coef[i]

        // tmp = mirvar(i);
        // powmod(x, tmp, p, tmp1);
        // multiply(tmp1, coef[i], tmp1);
        // add(ret, tmp1, ret);
    }
    powmod(ret, one, this->p, ret); // ret = ret mode p
    return ret;
}

/**
 * @description: 根据收集到的子秘密，进行重构，通过拉格朗日插值定理求解
 *                  根据多个秘密使用拉格朗日插值公式重构秘密
 *                  详细公式见 ./include/miracl/fumula.md文档
 *
 * @param {vector<big>} secret：各个设备的总的秘密份额（恢复数据时可以是设备的数据分片计算后的局部值）
 * @param {vector<big>} id：各个设备的id值 (secret和id列表一一对应关系)
 * @return {big}：返回计算出来的密钥值或者数据
 */
big device::secretreconstruct(vector<big> secret, vector<big> id)
{
    big ret = mirvar(0), one = mirvar(1), tmp, tmp1 = mirvar(0);

    for (size_t i = 0; i < secret.size(); i++)
    {
        tmp = mirvar(1);
        for (size_t j = 0; j < secret.size(); j++)
        {
            if (i == j)
                continue;
            subtract(id[j], id[i], tmp1);
            xgcd(tmp1, this->p, tmp1, tmp1, tmp1); // tmp1 = (1/tmp1) mod p

            multiply(tmp1, id[j], tmp1);
            multiply(tmp, tmp1, tmp);
            powmod(tmp, one, this->p, tmp); // 取模
        }

        multiply(tmp, secret[i], tmp);
        add(ret, tmp, ret);
    }
    powmod(ret, one, p, ret); // 取模
    return ret;
}

/**
 * @description: 与secretreconstruct类似，只用作验证使用，可以删除该段代码
 * @return {*}
 */
big device::reconstruct()
{
    big ret = mirvar(0), one = mirvar(1), tmp, tmp1 = mirvar(0);

    for (size_t i = 0; i < this->tresh; i++)
    {
        tmp = mirvar(1);
        for (size_t j = 0; j < this->tresh; j++)
        {
            if (i == j)
                continue;
            subtract(this->value[j], this->value[i], tmp1);
            xgcd(tmp1, this->p, tmp1, tmp1, tmp1);

            multiply(tmp1, this->value[j], tmp1);
            multiply(tmp, tmp1, tmp);
            powmod(tmp, one, this->p, tmp);
        }

        multiply(tmp, this->key[i], tmp);
        add(ret, tmp, ret);
    }
    powmod(ret, one, p, ret);
    return ret;
}

/**
 * @description: 根据收到的数据分片计算局部的数据份额
 * @param {big} c：数据分片值
 * @return {*}
 */
void device::getdatapiece(big c)
{
    big one = mirvar(1); // 初始化单位值1
    this->datapiece = mirvar(0);// 初始化数据分片值为0
    multiply(this->ownshare, c, this->datapiece);// ownshare *= c
    powmod(this->datapiece, one, this->p, this->datapiece);// 取模得到局部值
}

/**
 * @description: 设备构造函数
 * @return {*}
 */
device::~device()
{
}