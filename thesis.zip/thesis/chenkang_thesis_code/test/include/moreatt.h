/*
 * @Author: ck
 * @Date: 2025-02-08 04:55:18
 * @LastEditors: ck
 * @LastEditTime: 2025-02-12 01:47:16
 * @FilePath: /test/include/moreatt.h
 * @Description:
 *
 * Copyright (c) 2025 by ${git_name_email}, All Rights Reserved.
 */
#include <random>
#include <iostream>
#define ATT_NUM 100
#define VALUE_NUM 3

using namespace std;
enum Device_att1
{
att1_1 = 65472383,
att1_2 = 82807366,
att1_3 = 36767312
};
enum Device_att2
{
att2_1 = 62159080,
att2_2 = 51574087,
att2_3 = 32070798
};
enum Device_att3
{
att3_1 = 38945566,
att3_2 = 83126732,
att3_3 = 12796965
};
enum Device_att4
{
att4_1 = 10818888,
att4_2 = 21266431,
att4_3 = 84136868
};
enum Device_att5
{
att5_1 = 69662044,
att5_2 = 93378529,
att5_3 = 45999659
};
enum Device_att6
{
att6_1 = 68010854,
att6_2 = 95578851,
att6_3 = 78930066
};
enum Device_att7
{
att7_1 = 38595808,
att7_2 = 35744870,
att7_3 = 91525442
};
enum Device_att8
{
att8_1 = 35731277,
att8_2 = 39627914,
att8_3 = 15489974
};
enum Device_att9
{
att9_1 = 70037504,
att9_2 = 16856373,
att9_3 = 90433949
};
enum Device_att10
{
att10_1 = 29609081,
att10_2 = 62390439,
att10_3 = 66155766
};
enum Device_att11
{
att11_1 = 51858932,
att11_2 = 86583555,
att11_3 = 79286400
};
enum Device_att12
{
att12_1 = 79004394,
att12_2 = 80045994,
att12_3 = 87182734
};
enum Device_att13
{
att13_1 = 32613973,
att13_2 = 41929958,
att13_3 = 18647165
};
enum Device_att14
{
att14_1 = 82320781,
att14_2 = 15452356,
att14_3 = 86266755
};
enum Device_att15
{
att15_1 = 33903516,
att15_2 = 57082647,
att15_3 = 52348993
};
enum Device_att16
{
att16_1 = 39312323,
att16_2 = 44779226,
att16_3 = 36110719
};
enum Device_att17
{
att17_1 = 48459232,
att17_2 = 21744159,
att17_3 = 66642015
};
enum Device_att18
{
att18_1 = 10146167,
att18_2 = 25061000,
att18_3 = 13292139
};
enum Device_att19
{
att19_1 = 30960991,
att19_2 = 50616729,
att19_3 = 28277091
};
enum Device_att20
{
att20_1 = 12409254,
att20_2 = 50753121,
att20_3 = 41261667
};
enum Device_att21
{
att21_1 = 90723235,
att21_2 = 68318015,
att21_3 = 95503200
};
enum Device_att22
{
att22_1 = 58921876,
att22_2 = 50479739,
att22_3 = 39406629
};
enum Device_att23
{
att23_1 = 85925287,
att23_2 = 36237672,
att23_3 = 48096070
};
enum Device_att24
{
att24_1 = 59206223,
att24_2 = 12677694,
att24_3 = 82743781
};
enum Device_att25
{
att25_1 = 60335041,
att25_2 = 39632207,
att25_3 = 75557981
};
enum Device_att26
{
att26_1 = 59229512,
att26_2 = 32611731,
att26_3 = 92741534
};
enum Device_att27
{
att27_1 = 10565585,
att27_2 = 13305785,
att27_3 = 72447638
};
enum Device_att28
{
att28_1 = 89805783,
att28_2 = 30102732,
att28_3 = 41437971
};
enum Device_att29
{
att29_1 = 61016506,
att29_2 = 88735208,
att29_3 = 45553591
};
enum Device_att30
{
att30_1 = 47136914,
att30_2 = 57396841,
att30_3 = 71077260
};
enum Device_att31
{
att31_1 = 20881308,
att31_2 = 85502460,
att31_3 = 39188202
};
enum Device_att32
{
att32_1 = 57586597,
att32_2 = 48343888,
att32_3 = 23147676
};
enum Device_att33
{
att33_1 = 91807971,
att33_2 = 20223623,
att33_3 = 72147378
};
enum Device_att34
{
att34_1 = 53090816,
att34_2 = 80579921,
att34_3 = 39068489
};
enum Device_att35
{
att35_1 = 75481257,
att35_2 = 60917763,
att35_3 = 44437200
};
enum Device_att36
{
att36_1 = 83587719,
att36_2 = 46529386,
att36_3 = 33428815
};
enum Device_att37
{
att37_1 = 61589446,
att37_2 = 56696453,
att37_3 = 64870552
};
enum Device_att38
{
att38_1 = 93898088,
att38_2 = 62301312,
att38_3 = 11089316
};
enum Device_att39
{
att39_1 = 89547718,
att39_2 = 78061090,
att39_3 = 98661174
};
enum Device_att40
{
att40_1 = 86237069,
att40_2 = 87853159,
att40_3 = 51627215
};
enum Device_att41
{
att41_1 = 98180925,
att41_2 = 51733977,
att41_3 = 43519855
};
enum Device_att42
{
att42_1 = 89602000,
att42_2 = 76877335,
att42_3 = 70577671
};
enum Device_att43
{
att43_1 = 56052594,
att43_2 = 66011476,
att43_3 = 16272202
};
enum Device_att44
{
att44_1 = 86259880,
att44_2 = 78633624,
att44_3 = 60408192
};
enum Device_att45
{
att45_1 = 29177513,
att45_2 = 31112372,
att45_3 = 38575380
};
enum Device_att46
{
att46_1 = 32422855,
att46_2 = 66797466,
att46_3 = 55660103
};
enum Device_att47
{
att47_1 = 62112629,
att47_2 = 66022866,
att47_3 = 56039793
};
enum Device_att48
{
att48_1 = 76817436,
att48_2 = 31986192,
att48_3 = 80186391
};
enum Device_att49
{
att49_1 = 23298977,
att49_2 = 17481652,
att49_3 = 30667917
};
enum Device_att50
{
att50_1 = 83414891,
att50_2 = 74895434,
att50_3 = 21482403
};
enum Device_att51
{
att51_1 = 50260811,
att51_2 = 21060533,
att51_3 = 37544724
};
enum Device_att52
{
att52_1 = 84686216,
att52_2 = 14812985,
att52_3 = 66389343
};
enum Device_att53
{
att53_1 = 22709869,
att53_2 = 51767833,
att53_3 = 77464862
};
enum Device_att54
{
att54_1 = 29768988,
att54_2 = 10416097,
att54_3 = 63923879
};
enum Device_att55
{
att55_1 = 61667015,
att55_2 = 87459799,
att55_3 = 75426426
};
enum Device_att56
{
att56_1 = 58315316,
att56_2 = 57992818,
att56_3 = 68062711
};
enum Device_att57
{
att57_1 = 59700748,
att57_2 = 83406942,
att57_3 = 23991585
};
enum Device_att58
{
att58_1 = 97839157,
att58_2 = 40343354,
att58_3 = 68946680
};
enum Device_att59
{
att59_1 = 25420236,
att59_2 = 76768566,
att59_3 = 14316753
};
enum Device_att60
{
att60_1 = 98977409,
att60_2 = 97804455,
att60_3 = 83184225
};
enum Device_att61
{
att61_1 = 82838249,
att61_2 = 87989573,
att61_3 = 32348825
};
enum Device_att62
{
att62_1 = 71685211,
att62_2 = 25862509,
att62_3 = 62132306
};
enum Device_att63
{
att63_1 = 40957890,
att63_2 = 96157034,
att63_3 = 20774430
};
enum Device_att64
{
att64_1 = 73253299,
att64_2 = 74229391,
att64_3 = 67466717
};
enum Device_att65
{
att65_1 = 71245444,
att65_2 = 49338322,
att65_3 = 22486359
};
enum Device_att66
{
att66_1 = 89643470,
att66_2 = 25718744,
att66_3 = 74797283
};
enum Device_att67
{
att67_1 = 38824826,
att67_2 = 11575208,
att67_3 = 67594073
};
enum Device_att68
{
att68_1 = 69119467,
att68_2 = 31245016,
att68_3 = 72680464
};
enum Device_att69
{
att69_1 = 25613135,
att69_2 = 87564343,
att69_3 = 40012644
};
enum Device_att70
{
att70_1 = 70562619,
att70_2 = 79332763,
att70_3 = 40449554
};
enum Device_att71
{
att71_1 = 39095121,
att71_2 = 84530009,
att71_3 = 19532195
};
enum Device_att72
{
att72_1 = 37159015,
att72_2 = 31294636,
att72_3 = 52311926
};
enum Device_att73
{
att73_1 = 64262620,
att73_2 = 61944182,
att73_3 = 24205830
};
enum Device_att74
{
att74_1 = 60627517,
att74_2 = 33365034,
att74_3 = 83549998
};
enum Device_att75
{
att75_1 = 93341559,
att75_2 = 28949132,
att75_3 = 14552883
};
enum Device_att76
{
att76_1 = 70308347,
att76_2 = 86114929,
att76_3 = 58856431
};
enum Device_att77
{
att77_1 = 97455874,
att77_2 = 40621132,
att77_3 = 19163039
};
enum Device_att78
{
att78_1 = 70508435,
att78_2 = 88091404,
att78_3 = 48960718
};
enum Device_att79
{
att79_1 = 56963996,
att79_2 = 39287026,
att79_3 = 27754098
};
enum Device_att80
{
att80_1 = 26289939,
att80_2 = 12403529,
att80_3 = 88329365
};
enum Device_att81
{
att81_1 = 64789999,
att81_2 = 89340434,
att81_3 = 83277182
};
enum Device_att82
{
att82_1 = 31876107,
att82_2 = 22632859,
att82_3 = 27493099
};
enum Device_att83
{
att83_1 = 90441572,
att83_2 = 41722491,
att83_3 = 96687312
};
enum Device_att84
{
att84_1 = 68590817,
att84_2 = 68241191,
att84_3 = 13084550
};
enum Device_att85
{
att85_1 = 37237035,
att85_2 = 73266147,
att85_3 = 13569993
};
enum Device_att86
{
att86_1 = 55821639,
att86_2 = 96904163,
att86_3 = 49031337
};
enum Device_att87
{
att87_1 = 57508431,
att87_2 = 30256293,
att87_3 = 46327400
};
enum Device_att88
{
att88_1 = 35128305,
att88_2 = 89841050,
att88_3 = 87232441
};
enum Device_att89
{
att89_1 = 85054620,
att89_2 = 19953639,
att89_3 = 80263253
};
enum Device_att90
{
att90_1 = 69430331,
att90_2 = 63054757,
att90_3 = 82463906
};
enum Device_att91
{
att91_1 = 89130150,
att91_2 = 38672924,
att91_3 = 63950657
};
enum Device_att92
{
att92_1 = 14952631,
att92_2 = 21702814,
att92_3 = 42199056
};
enum Device_att93
{
att93_1 = 11858431,
att93_2 = 72181866,
att93_3 = 62836166
};
enum Device_att94
{
att94_1 = 49424437,
att94_2 = 41795847,
att94_3 = 69738296
};
enum Device_att95
{
att95_1 = 99780994,
att95_2 = 63255107,
att95_3 = 46205056
};
enum Device_att96
{
att96_1 = 22502032,
att96_2 = 87235437,
att96_3 = 69853243
};
enum Device_att97
{
att97_1 = 89000055,
att97_2 = 98985388,
att97_3 = 13886986
};
enum Device_att98
{
att98_1 = 66138918,
att98_2 = 83134135,
att98_3 = 13790636
};
enum Device_att99
{
att99_1 = 37312887,
att99_2 = 37653912,
att99_3 = 21583885
};
enum Device_att100
{
att100_1 = 94318630,
att100_2 = 72503870,
att100_3 = 67555297
};
vector<vector<int>> add_att_vector = {
{att1_1,att1_2,att1_3},
{att2_1,att2_2,att2_3},
{att3_1,att3_2,att3_3},
{att4_1,att4_2,att4_3},
{att5_1,att5_2,att5_3},
{att6_1,att6_2,att6_3},
{att7_1,att7_2,att7_3},
{att8_1,att8_2,att8_3},
{att9_1,att9_2,att9_3},
{att10_1,att10_2,att10_3},
{att11_1,att11_2,att11_3},
{att12_1,att12_2,att12_3},
{att13_1,att13_2,att13_3},
{att14_1,att14_2,att14_3},
{att15_1,att15_2,att15_3},
{att16_1,att16_2,att16_3},
{att17_1,att17_2,att17_3},
{att18_1,att18_2,att18_3},
{att19_1,att19_2,att19_3},
{att20_1,att20_2,att20_3},
{att21_1,att21_2,att21_3},
{att22_1,att22_2,att22_3},
{att23_1,att23_2,att23_3},
{att24_1,att24_2,att24_3},
{att25_1,att25_2,att25_3},
{att26_1,att26_2,att26_3},
{att27_1,att27_2,att27_3},
{att28_1,att28_2,att28_3},
{att29_1,att29_2,att29_3},
{att30_1,att30_2,att30_3},
{att31_1,att31_2,att31_3},
{att32_1,att32_2,att32_3},
{att33_1,att33_2,att33_3},
{att34_1,att34_2,att34_3},
{att35_1,att35_2,att35_3},
{att36_1,att36_2,att36_3},
{att37_1,att37_2,att37_3},
{att38_1,att38_2,att38_3},
{att39_1,att39_2,att39_3},
{att40_1,att40_2,att40_3},
{att41_1,att41_2,att41_3},
{att42_1,att42_2,att42_3},
{att43_1,att43_2,att43_3},
{att44_1,att44_2,att44_3},
{att45_1,att45_2,att45_3},
{att46_1,att46_2,att46_3},
{att47_1,att47_2,att47_3},
{att48_1,att48_2,att48_3},
{att49_1,att49_2,att49_3},
{att50_1,att50_2,att50_3},
{att51_1,att51_2,att51_3},
{att52_1,att52_2,att52_3},
{att53_1,att53_2,att53_3},
{att54_1,att54_2,att54_3},
{att55_1,att55_2,att55_3},
{att56_1,att56_2,att56_3},
{att57_1,att57_2,att57_3},
{att58_1,att58_2,att58_3},
{att59_1,att59_2,att59_3},
{att60_1,att60_2,att60_3},
{att61_1,att61_2,att61_3},
{att62_1,att62_2,att62_3},
{att63_1,att63_2,att63_3},
{att64_1,att64_2,att64_3},
{att65_1,att65_2,att65_3},
{att66_1,att66_2,att66_3},
{att67_1,att67_2,att67_3},
{att68_1,att68_2,att68_3},
{att69_1,att69_2,att69_3},
{att70_1,att70_2,att70_3},
{att71_1,att71_2,att71_3},
{att72_1,att72_2,att72_3},
{att73_1,att73_2,att73_3},
{att74_1,att74_2,att74_3},
{att75_1,att75_2,att75_3},
{att76_1,att76_2,att76_3},
{att77_1,att77_2,att77_3},
{att78_1,att78_2,att78_3},
{att79_1,att79_2,att79_3},
{att80_1,att80_2,att80_3},
{att81_1,att81_2,att81_3},
{att82_1,att82_2,att82_3},
{att83_1,att83_2,att83_3},
{att84_1,att84_2,att84_3},
{att85_1,att85_2,att85_3},
{att86_1,att86_2,att86_3},
{att87_1,att87_2,att87_3},
{att88_1,att88_2,att88_3},
{att89_1,att89_2,att89_3},
{att90_1,att90_2,att90_3},
{att91_1,att91_2,att91_3},
{att92_1,att92_2,att92_3},
{att93_1,att93_2,att93_3},
{att94_1,att94_2,att94_3},
{att95_1,att95_2,att95_3},
{att96_1,att96_2,att96_3},
{att97_1,att97_2,att97_3},
{att98_1,att98_2,att98_3},
{att99_1,att99_2,att99_3},
{att100_1,att100_2,att100_3}
};

int getRandomNumber()
{
    static random_device rd;                                       // Seed
    static mt19937 gen(rd());                                      // Random number generator
    static uniform_int_distribution<int> dist(10000000, 99999999); // Range: 8-digit number

    return dist(gen); // Generate a random number
}

int getRandomNumber_givenum(int k) {
    static std::random_device rd; // Random seed
    static std::mt19937 gen(rd()); // Mersenne Twister engine
    static std::uniform_int_distribution<int> dist(0, k); // Range: [0, 2]

    return dist(gen);
}

void generate_all_att_vector()
{
    cout << "vector<vector<int>> add_att_vector = {" << endl;
    for (size_t i = 1; i <= ATT_NUM; i++)
    {
        cout << "{";
        for (size_t j = 1; j <= VALUE_NUM; j++)
        {
            cout << "att" << i << "_" << j;
            if (j != VALUE_NUM)
                cout << ",";
        }

        cout << "}";
        if (i != ATT_NUM)
        {
            cout << ",";
        }
        cout << endl;
    }

    cout << "};" << endl;
}

void generate_enum_att()
{
    for (size_t i = 1; i <= ATT_NUM; i++)
    {
        cout << "enum Device_att" << i << endl;
        cout << "{" << endl;
        for (size_t j = 1; j <= VALUE_NUM; j++)
        {
            cout << "att" << i << "_" << j << " = " << getRandomNumber();
            if (j != VALUE_NUM)
                cout << ",";
            cout << endl;
        }

        cout << "};" << endl;
    }
}