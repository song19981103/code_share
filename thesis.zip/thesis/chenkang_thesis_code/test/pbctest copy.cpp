/*
 * @Author: ck
 * @Date: 2023-10-13 02:59:59
 * @LastEditors: ck
 * @LastEditTime: 2024-08-22 01:42:45
 * @FilePath: /test/pbctest copy.cpp
 * @Description:
 *
 * Copyright (c) 2023 by ${git_name_email}, All Rights Reserved.
 */
#include <iostream>
#include <pbc/pbc.h>
#include <chrono>
#include <cstdio>
#include <cstdint>

using namespace std;

void program_run_timing(int run_times, void (*func)(element_t, element_t, element_t),
                        element_t a, element_t b, element_t c)
{
    auto start_time = chrono::high_resolution_clock::now();
    // 执行群操作，例如加法
    func(c, a, b);
    auto end_time = chrono::high_resolution_clock::now();
    auto elapsed_time = chrono::duration_cast<chrono::duration<long long, micro>>(end_time - start_time);
    std::cout << "运行时间: " << elapsed_time.count() << " 微秒" << std::endl;
}

void program_run_timing(int run_times, void (*func)(element_t, element_t, element_t, pairing_t),
                        element_t a, element_t b, element_t c, pairing_t d)
{
    auto start_time = chrono::high_resolution_clock::now();
    // 执行群操作，例如加法
    func(c, a, b, d);
    auto end_time = chrono::high_resolution_clock::now();
    auto elapsed_time = chrono::duration_cast<chrono::duration<long long, micro>>(end_time - start_time);
    std::cout << "运行时间: " << elapsed_time.count() << " 微秒" << std::endl;
}

int main()
{
    int len;

    // 初始化PBC库
    pbc_param_t params;
    pbc_param_init_a_gen(params, 160, 512);
    pairing_t pairing;
    pairing_init_pbc_param(pairing, params);

    /* *********************************************
                        单群加法运算
    ************************************************/
    element_t g, h, result;
    element_init_G1(g, pairing); // 创建一个G1群元素
    element_init_G1(h, pairing);
    element_init_G1(result, pairing);

    // 在G1群中随机生成两个元素
    element_random(g);
    element_random(h);

    printf("加法运行时间：");
    program_run_timing(1, element_add, g, h, result);

    char buffer[1024]; // 定义一个足够大的缓冲区来存储字符串
    len = element_snprint(buffer, sizeof(buffer), g);
    printf("Formatted G1 element g: %s\n", buffer);

    len = element_snprint(buffer, sizeof(buffer), h);
    printf("Formatted G1 element h: %s\n", buffer);

    len = element_snprint(buffer, sizeof(buffer), result);
    printf("Formatted G1 element result: %s\n", buffer);

    /* *********************************************
                        多群指数运算
    ************************************************/
    element_t g1, g2;
    element_t pk, sk;
    element_t tmp1, tmp2;
    element_t sig;

    element_init_G2(pk, pairing); // 创建一个G2群元素
    element_init_G2(g2, pairing);

    element_init_G1(g1, pairing); // 创建一个G1群元素
    element_init_G1(sig, pairing);

    element_init_GT(tmp1, pairing); // 创建一个GT群元素
    element_init_GT(tmp2, pairing);
    element_init_Zr(sk, pairing);

    element_random(sk);
    element_random(g2);
    element_pow_zn(pk, g2, sk); // pk = g2 ^ {sk}

    element_random(g1);
    program_run_timing(1, element_pow_zn, g1, sk, sig); // sig = g1 ^ {sk}

    program_run_timing(1, pairing_apply, sig, g2, tmp1, pairing); // sig = g1 ^ {sk}
    std::cout << "双线性映射运行时间: " << std::endl;

    pairing_apply(tmp2, g1, pk, pairing);
    if (!element_cmp(tmp1, tmp2))
    {
        printf("signature verifies\n");
    }
    else
    {
        printf("signature does not verify\n");
    }

    // 释放资源
    element_clear(g1);
    element_clear(g2);
    element_clear(sk);
    element_clear(pk);
    element_clear(tmp1);
    element_clear(tmp2);
    element_clear(sig);

    // 释放资源
    element_clear(g);
    element_clear(h);
    element_clear(result);
    pairing_clear(pairing);
    pbc_param_clear(params);

    return 0;
}
