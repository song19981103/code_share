/*
 * @Author: ck
 * @Date: 2024-08-18 19:25:44
 * @LastEditors: ck
 * @LastEditTime: 2025-04-22 00:07:06
 * @FilePath: /test/test.cpp
 * @Description:
 *
 * Copyright (c) 2024 by ${git_name_email}, All Rights Reserved.
 */
#include <pbc/pbc.h>
#include <iostream>
#include <gmpxx.h>
#include <stdio.h>
#include <dlfcn.h>
#include <cctype>
#include <chrono>
#include <openssl/rand.h>

#include "mysup.h"
#include "miracl/miracl.h"
#include "miracl/mirdef.h"
#define MaxDevice 20
#define Treshold 10
#define security_para 512
#define choose_pairing 0

using namespace std;
int pairing_params[3][2] = {{160, 512}, {256, 640}, {512, 1536}}; //type A双线性映射的选型
mpz_t p, ele_g, c_p;
element_t g, commit_g;
unsigned long int seed = 43; // 种子值
gmp_randstate_t state;
pairing_t pairing;
mpz_t sig_rand_merge;
mpz_t c_mpz, z_merge; // 聚合签名
element_t pk_sig;     // 签名验证公钥
mpz_t sk_merge_tmp;
mpz_t subshare[MaxDevice], idlist[MaxDevice], omega_list[MaxDevice];
mpz_t dkg_subshare[MaxDevice][MaxDevice], merge_subshare[MaxDevice];
element_t dkg_subpk[MaxDevice][MaxDevice], dkg_publickey[MaxDevice], poly_commit1[MaxDevice], poly_commit2[MaxDevice];
mpz_t sig_random[MaxDevice], delta[MaxDevice];
mpz_t pre_compute_delta[MaxDevice];

vector<unsigned char> iv(12);  // random vector for key manangement key encrytion
vector<unsigned char> tag(16); // for the key management key decryption check

void Setup(int k);
mpz_t *KeySplit(mpz_t key, int part);
string KeyEnc(mpz_t key1, mpz_t key2);
string KeyDec(string c1, string c2);
string maskpara(mpz_t key, mpz_t text);
string maskpara(string key, string text, int n);
void SecretShare(string secret, int n);
void SecretRecover(mpz_t *k, mpz_t *d, mpz_t result);
void test_key_management();
void test_secret_recover();
void polycommitment(mpz_t *coef, mpz_t omega, mpz_t omega1, mpz_t omega2);
void sig_setup(int deviceNo);
void DKG();
void optimize_delta();
void ThreshSig(string message);
void SigVerify(string message, mpz_t c, mpz_t z);
void test_signature();
void maskpara(mpz_t key, mpz_t text, mpz_t result);

void test_authentication();

int main(int argc, char const *argv[])
{
    // 初始化随机值
    gmp_randinit_default(state);
    gmp_randseed_ui(state, seed);

    Setup(security_para); // 初始化

    test_key_management();

    /*****************************************************
                签名
     *******************************************************/
    // test_signature();
    // test_authentication();
    // 释放资源
    gmp_randclear(state);
    return 0;
}

void Setup(int k)
{
    mpz_init(p);
    mpz_urandomb(p, state, k); // 生成一个随机的位数为 bits 的数
    mpz_nextprime(p, p);       // 找到大于 prime 的下一个素数

    // 打印生成的大素数
    gmp_printf("Generated prime: %Zd\n", p);

    for (size_t i = 0; i < MaxDevice; i++) // 生成device list
    {
        mpz_init(idlist[i]);
        mpz_urandomm(idlist[i], state, p);
    }

    cout << "setup finish" << endl;
}

mpz_t *KeySplit(mpz_t key, int part)
{
    part = 2; // 默认为两部分
    mpz_t *ret = new mpz_t[part];
    for (size_t i = 0; i < part; i++)
    {
        mpz_init(ret[i]);
    }

    // 生成一个小于 k 的随机数
    mpz_urandomm(ret[0], state, key);

    // 打印生成的随机数
    // gmp_printf("Generated random number less than %Zd: %Zd\n", key, ret[0]);
    mpz_sub(ret[1], key, ret[0]);
    cout << "keysplit finish" << endl;
    return ret;
}

void KeyEnc1(mpz_t key1, mpz_t key2, mpz_t result)
{
    vector<unsigned char> hash = mpz_to_hash(key1); // mpz_t tranfer to hash as the encryption key
    string key2str = mpz_get_str(nullptr, 10, key2);

    vector<unsigned char> plaintext(key2str.begin(), key2str.end());
    vector<unsigned char> ciphertext = encrypt_long_data(plaintext, hash, iv, tag);
    uchar_vector_to_mpz_hex(ciphertext, result);
}

string KeyEnc(mpz_t key1, mpz_t key2)
{
    unsigned char *ciphertext = nullptr;
    int ciphertextLength;

    string enckey = hashStringToFixedLength(key1);
    enckey = stringToHex((const unsigned char *)enckey.data(), enckey.size());
    string key2str = mpz_get_str(NULL, 16, key2);

    anyLengthKeyEnc(enckey, enckey.size(), key2str, key2str.size(), &ciphertext, &ciphertextLength);
    string ciphertext1 = stringToHex(ciphertext, strlen((const char *)ciphertext));
    cout << "key encryption successful" << endl;
    return ciphertext1;
}

void KeyDec1(mpz_t cipher1, mpz_t cipher2, mpz_t result)
{
    mpz_t key1;
    mpz_init(key1);
    maskpara(cipher1, cipher2, key1);
    // gmp_printf("recover key1: %Zd\n", key1);
    vector<unsigned char> key = mpz_to_hash(key1);
    vector<unsigned char> ciphertext = mpz_to_uchar_vector(cipher1);

    vector<unsigned char> plaintext = decrypt_long_data(ciphertext, key, iv, tag);
    string plainstr(plaintext.begin(), plaintext.end());
    mpz_set_str(result, plainstr.c_str(), 10);
    // gmp_printf("recover key2: %Zd\n", result);
    mpz_add(result, result, key1);
}

string KeyDec(string c1, string c2)
{
    unsigned char *plaintext = nullptr;
    int plaintextLength;
    string key1_recover = maskpara(c1, c2, 16);
    string keystr = hashStringToFixedLength(key1_recover); // key1生成密钥
    keystr = stringToHex((const unsigned char *)keystr.data(), keystr.size());
    string cipher = hexToString(c1);
    anyLengthKeyDec(keystr.data(), keystr.size(), cipher.data(), cipher.size(), &plaintext, &plaintextLength);

    mpz_t tmp1, tmp2;
    mpz_inits(tmp1, tmp2, NULL);
    string plaintext1 = string(reinterpret_cast<char *>(plaintext), plaintextLength);
    string plaintext2 = "";
    for (size_t i = 0; i < plaintext1.size(); i++)
    {
        if (isalnum(plaintext1[i]))
        {
            plaintext2.push_back(plaintext1[i]);
        }
        else
            break;
    }

    mpz_set_str(tmp2, key1_recover.data(), 16);
    gmp_printf("key2: %Zd\n", tmp2);
    mpz_set_str(tmp1, plaintext2.data(), 16);
    gmp_printf("key1: %Zd\n", tmp1);
    mpz_add(tmp2, tmp1, tmp2);

    string ret = mpz_get_str(NULL, 10, tmp2);
    return ret;
}

string maskpara(string key, string text, int n)
{
    mpz_t tmp1, tmp2;
    mpz_inits(tmp1, tmp2, nullptr);
    mpz_set_str(tmp1, key.data(), n);
    mpz_set_str(tmp2, text.data(), n);
    return maskpara(tmp1, tmp2);
}

void maskpara(mpz_t key, mpz_t text, mpz_t result)
{
    __gmpz_xor(result, key, text);
}

string maskpara(mpz_t key, mpz_t text)
{
    mpz_t tmp;
    mpz_init(tmp);
    __gmpz_xor(tmp, key, text);

    string ret = mpz_get_str(NULL, 16, tmp);
    return ret;
}

void SecretShare(mpz_t secret)
{
    mpz_t *coef = new mpz_t[Treshold];

    generatepoly(Treshold, p, coef, state);
    mpz_set(coef[Treshold - 1], secret);
    for (size_t i = 0; i < MaxDevice; i++)
    {
        generateshare(Treshold, idlist[i], p, coef, subshare[i]);
    }
    cout << "secret share finish" << endl;
}

void SecretShare(string secret, int n)
{
    mpz_t *coef = new mpz_t[Treshold];

    generatepoly(Treshold, p, coef, state);
    mpz_set_str(coef[Treshold - 1], secret.data(), n);
    for (size_t i = 0; i < MaxDevice; i++)
    {
        generateshare(Treshold, idlist[i], p, coef, subshare[i]);
    }
    cout << "secret share finish" << endl;
}

void SecretRecover1(mpz_t *d)
{
    mpz_t term, temp;
    mpz_inits(term, temp, NULL);

    for (int i = 0; i < Treshold; i++)
    {
        mpz_set_ui(term, 1);

        for (int j = 0; j < Treshold; j++)
        {
            if (j != i)
            {
                mpz_sub(temp, d[j], d[i]);
                mpz_invert(temp, temp, p); // 求逆元
                mpz_mul(temp, temp, d[j]);
                mpz_mul(term, term, temp);
                mpz_mod(term, term, p);
            }
        }
        mpz_set(pre_compute_delta[i], term);
    }

    mpz_clears(term, temp, NULL);
}

void SecretRecover2(mpz_t *k, mpz_t result)
{
    mpz_t term, sum;
    mpz_inits(term, sum, NULL);

    mpz_set_ui(result, 0);

    for (int i = 0; i < Treshold; i++)
    {
        mpz_set(term, pre_compute_delta[i]);
        mpz_mul(term, term, k[i]);
        mpz_mod(term, term, p);
        mpz_add(sum, result, term);
        mpz_mod(result, sum, p);
    }

    mpz_clears(term, sum, NULL);
}

void SecretRecover(mpz_t *k, mpz_t *d, mpz_t result)
{
    mpz_t term, temp, sum;
    mpz_inits(term, temp, sum, NULL);

    mpz_set_ui(result, 0);

    for (int i = 0; i < Treshold; i++)
    {
        mpz_set_ui(term, 1);

        for (int j = 0; j < Treshold; j++)
        {
            if (j != i)
            {
                mpz_sub(temp, d[j], d[i]);
                mpz_invert(temp, temp, p); // 求逆元
                mpz_mul(temp, temp, d[j]);
                mpz_mul(term, term, temp);
                mpz_mod(term, term, p);
            }
        }

        mpz_mul(term, term, k[i]);
        mpz_mod(term, term, p);
        mpz_add(sum, result, term);
        mpz_mod(result, sum, p);
    }

    mpz_clears(term, temp, sum, NULL);
}

void test_key_management()
{
    mpz_t key;
    mpz_t *keypart;
    int part = 2;
    mpz_init(key);
    mpz_urandomb(key, state, security_para / 4); // 由于使用了256对称加密，security_para需要比较大，否则分享的秘密值超过了p
    // mpz_urandomm(key, state, p);
    gmp_printf("Generated key: %Zd\n", key);
    keypart = KeySplit(key, part); // 生成密钥以及拆分

    mpz_t tmp;
    mpz_init(tmp);
    mpz_add(tmp, keypart[0], keypart[1]);
    gmp_printf("key1: %Zd\nkey2: %Zd\n", keypart[0], keypart[1]);
    int check = mpz_cmp(tmp, key);
    if (!check)
        cout << "key split right" << endl;
    else
        cout << "key split wrong" << endl; // 检查keysplit正确性

    // prepare for the secret share
    RAND_bytes(iv.data(), iv.size());
    mpz_t c1, c2;
    mpz_inits(c1, c2, NULL);
    KeyEnc1(keypart[0], keypart[1], c1);
    maskpara(c1, keypart[0], c2);
    gmp_printf("ciphertext1: %Zd\n", c1);
    gmp_printf("ciphertext2: %Zd\n", c2);

    // secret share
    auto start = chrono::high_resolution_clock::now();
    SecretShare(c2);
    auto end = chrono::high_resolution_clock::now();
    chrono::duration<double> elapsed = end - start;
    cout << MaxDevice << " node" << " secret share time taken: " << elapsed.count() << " seconds" << endl;

    // secret recovery
    mpz_t result1;
    mpz_init(result1);
    SecretRecover1(idlist); // pre compute of the delta to decrease the compute time

    start = chrono::high_resolution_clock::now();
    SecretRecover2(subshare, result1);
    mpz_t fullkey1;
    mpz_init(fullkey1);
    KeyDec1(c1, c2, fullkey1);
    end = chrono::high_resolution_clock::now();
    elapsed = end - start;
    cout << MaxDevice << " node" << "full secret recover_pre time taken: " << elapsed.count() << " seconds" << endl;

    // secret recovery  ++++++++  no pre compute of the delta
    start = chrono::high_resolution_clock::now();
    mpz_t result;
    mpz_init(result);
    SecretRecover(subshare, idlist, result);

    mpz_t fullkey;
    mpz_init(fullkey);
    KeyDec1(c1, result1, fullkey);
    end = chrono::high_resolution_clock::now();
    elapsed = end - start;
    cout << MaxDevice << " node" << "full secret recover time taken: " << elapsed.count() << " seconds" << endl;

    check = mpz_cmp(key, fullkey);
    if (!check)
        cout << "fullkey recover right" << endl;
    else
        cout << "fullkey recover wrong" << endl;
}

void test_secret_recover()
{
    mpz_t result;
    mpz_init(result);

    mpz_t *coef = new mpz_t[Treshold];
    mpz_inits(coef[0], coef[1], coef[2], NULL);
    mpz_set_str(coef[0], "4", 10);
    mpz_set_str(coef[1], "2", 10);
    mpz_set_str(coef[2], "5", 10);
    gmp_printf(" %Zd,%Zd,%Zd,\n", coef[0], coef[1], coef[2]);
    mpz_set_str(idlist[0], "1", 10);
    mpz_set_str(idlist[1], "2", 10);
    mpz_set_str(idlist[2], "3", 10);
    mpz_set_str(idlist[3], "4", 10);
    mpz_set_str(idlist[4], "5", 10);
    for (size_t i = 0; i < MaxDevice; i++)
    {
        generateshare(Treshold, idlist[i], p, coef, subshare[i]);
        gmp_printf("id: %Zd,subshare: %Zd\n", idlist[i], subshare[i]);
    }
    SecretRecover(subshare, idlist, result);
    gmp_printf("recover result: %Zd\n", result);
}

/* 根据omega 及多项式coef来计算omega2 =g^f(omega),omega1 =g^(omega)  */
void polycommitment(mpz_t *coef, mpz_t omega, element_t omega1, element_t omega2)
{
    mpz_t tmp1;
    mpz_init(tmp1);
    generateshare(Treshold, omega, p, coef, tmp1);
    element_pow_mpz(omega1, commit_g, omega);
    element_pow_mpz(omega2, commit_g, tmp1);
}

void sig_setup(int deviceNo)
{
    mpz_t *coef = new mpz_t[Treshold];
    generatepoly(Treshold, p, coef, state); // 生成设备的多项式f(x)
    /**
     * 秘密值之和小于 p, 否则g^ sum(coef[Treshold - 1]) !=  prod(g^ coef[Treshold - 1]),
     * 费马小定理a^(p−1) = 1 mod p
     */
    mpz_urandomm(coef[Treshold - 1], state, p);
    mpz_add(sk_merge_tmp, sk_merge_tmp, coef[Treshold - 1]);
    mpz_mod(sk_merge_tmp, sk_merge_tmp, p); // 秘密值之和,用于验证

    for (size_t j = 0; j < MaxDevice; j++)
    {
        generateshare(Treshold, idlist[j], p, coef, dkg_subshare[deviceNo][j]); // 生成秘密份额 f(id)
        element_init_G1(dkg_subpk[deviceNo][j], pairing);
        element_pow_mpz(dkg_subpk[deviceNo][j], commit_g, dkg_subshare[deviceNo][j]); // 生成秘密份额的证明g^{f(id)}
    }
    element_init_G1(dkg_publickey[deviceNo], pairing);
    element_pow_mpz(dkg_publickey[deviceNo], commit_g, coef[Treshold - 1]); // 生成g^pk

    element_init_G1(poly_commit1[deviceNo], pairing);
    element_init_G1(poly_commit2[deviceNo], pairing);
    polycommitment(coef, omega_list[deviceNo], poly_commit1[deviceNo], poly_commit2[deviceNo]); // 多项式承诺，计算g^{\tau}, g^{f(\tau)}
}

/* pay attention g^{a+b mod (p-1)} mod p == g^{a}*g^{b} mod p*/
void DKG()
{
    // 初始化poly commitment
    mpz_init(sk_merge_tmp);
    mpz_set_ui(sk_merge_tmp, 0);

    for (size_t i = 0; i < MaxDevice; i++)
    {
        mpz_inits(omega_list[i], merge_subshare[i], NULL);
        mpz_set_ui(merge_subshare[i], 0);
    }

    for (size_t i = 0; i < MaxDevice; i++) // 生成和聚合秘密份额
    {
        mpz_urandomm(omega_list[i], state, p); // 选择\tau
        sig_setup(i);
        for (size_t j = 0; j < MaxDevice; j++)
        {
            mpz_add(merge_subshare[j], merge_subshare[j], dkg_subshare[i][j]);
            mpz_mod(merge_subshare[j], merge_subshare[j], p); // 累加得到总的秘密份额
        }
    }
    // gmp_printf("secret: %Zd\n", sk_merge_tmp); // 用于测试,不用计算

    element_init_G1(pk_sig, pairing);
    element_set1(pk_sig);
    for (size_t i = 0; i < MaxDevice; i++) // 计算总的pk
    {
        element_mul(pk_sig, pk_sig, dkg_publickey[i]);
    }
    element_printf("the signature public key is:\n%B\n", pk_sig);
}

void optimize_delta()
{
    mpz_t term, temp;
    mpz_inits(term, temp, NULL);

    for (int i = 0; i < MaxDevice; i++)
    {
        mpz_set_ui(term, 1);

        for (int j = 0; j < Treshold; j++)
        {
            if (j != i)
            {
                mpz_sub(temp, idlist[j], idlist[i]);
                mpz_invert(temp, temp, p); // 求逆元
                mpz_mul(temp, temp, idlist[j]);
                mpz_mul(term, term, temp);
                mpz_mod(term, term, p);
            }
        }
        mpz_set(delta[i], term);
    }

    mpz_clears(term, temp, NULL);
}

void ThreshSig(string message)
{
    mpz_t tmp, tmp2;
    element_t rand_exp_arr[Treshold];
    mpz_inits(tmp, tmp2, c_mpz, z_merge, NULL);
    mpz_set_ui(tmp, 0);

    for (size_t i = 0; i < Treshold; i++) // 随机数生成
    {
        mpz_init(sig_random[i]);
        mpz_urandomm(sig_random[i], state, p); // 生成随机r_i
        element_init_G1(rand_exp_arr[i], pairing);
        element_pow_mpz(rand_exp_arr[i], commit_g, sig_random[i]); // 生成g^{r_i}
    }

    element_t rand_agg;
    element_init_G1(rand_agg, pairing);
    element_set1(rand_agg);
    for (size_t i = 0; i < Treshold; i++)
    {
        element_mul(rand_agg, rand_agg, rand_exp_arr[i]);
    }
    // element_printf("the aggregate random num exp is:\n%B\n", rand_agg);

    char *buffer = (char *)malloc(4096);
    element_snprintf(buffer, sizeof(buffer), "%B", rand_agg);
    string R_str(buffer);

    unsigned char digest[SHA256_DIGEST_LENGTH];                                       // 计算哈希值
    hashMessages(message.data(), message.size(), R_str.data(), R_str.size(), digest); // hash(m, R)

    mpz_import(c_mpz, SHA256_DIGEST_LENGTH, 1, 1, 0, 0, digest);
    mpz_mod(c_mpz, c_mpz, p);

    mpz_t z[Treshold]; // 签名份额计算
    for (size_t i = 0; i < Treshold; i++)
    {
        mpz_init(z[i]);
        mpz_set_ui(z[i], 0);
        mpz_mul(tmp, c_mpz, merge_subshare[i]);
        mpz_mod(tmp, tmp, p);
        mpz_mul(tmp, tmp, delta[i]);
        mpz_mod(tmp, tmp, p);
        mpz_add(z[i], sig_random[i], tmp);
    }

    mpz_set_ui(z_merge, 0); // 签名聚合
    for (size_t i = 0; i < Treshold; i++)
    {
        mpz_add(z_merge, z[i], z_merge);
        mpz_mod(z_merge, z_merge, p);
    }
}

void SigVerify(string message, mpz_t c, mpz_t z)
{
    element_t g_z, pk_invert_c, pk_c;
    element_init_G1(g_z, pairing);
    element_init_G1(pk_invert_c, pairing);
    element_init_G1(pk_c, pairing);
    element_pow_mpz(g_z, commit_g, z); // g^z
    element_pow_mpz(pk_c, pk_sig, c);
    element_invert(pk_invert_c, pk_c); // pk^-c

    element_t compute_R;
    element_init_G1(compute_R, pairing);
    element_mul(compute_R, pk_invert_c, g_z); // compute R

    char *buffer = (char *)malloc(4096);
    element_snprintf(buffer, sizeof(buffer), "%B", compute_R);
    string R_str(buffer);

    unsigned char digest[SHA256_DIGEST_LENGTH];                                       // 计算哈希值
    hashMessages(message.data(), message.size(), R_str.data(), R_str.size(), digest); // hash(m, R)
    mpz_t compute_c;
    mpz_init(compute_c);
    mpz_import(compute_c, SHA256_DIGEST_LENGTH, 1, 1, 0, 0, digest);
    mpz_mod(compute_c, compute_c, p);

    int check = mpz_cmp(compute_c, c_mpz); // 校验签名准确性
    if (!check)
    {
        cout << "verify success" << endl;
    }
    else
        cout << "verify failed" << endl;
}

void test_signature()
{
    pbc_param_t params;
    /**
     * 参数2有 128 位、160 位、256 位等，具体选择取决于应用的安全需求,security_para的长度
     * 应该至少是参数2的两倍。
     */

    pbc_param_init_a_gen(params, pairing_params[choose_pairing][0], pairing_params[choose_pairing][1]);
    pairing_init_pbc_param(pairing, params); // 初始化双线性对
    element_init_G1(commit_g, pairing);
    element_random(commit_g);
    element_init_Zr(g, pairing);
    element_random(g); // 生成群G1的生成元
    element_printf("Generator g for G1: \n%B\n", g);

    mpz_set(p, pairing->r); // 获取双线性对中的素数阶
    gmp_printf("reset prime:\n%Zd\n", p);

    for (size_t i = 0; i < MaxDevice; i++) // 重新生成device list
    {
        mpz_init(idlist[i]);
        mpz_urandomm(idlist[i], state, p);
    }

    auto start = chrono::high_resolution_clock::now();
    DKG();
    auto end = chrono::high_resolution_clock::now();
    chrono::duration<double> elapsed = end - start;
    // cout << MaxDevice << " node" << " DKG time taken: " << elapsed.count() << " seconds" << endl;

    optimize_delta(); // delta 可以加速计算
    string message = "123123";
    start = chrono::high_resolution_clock::now();
    ThreshSig(message);
    end = chrono::high_resolution_clock::now();
    elapsed = end - start;
    cout << MaxDevice << " node" << " Signature time taken: " << elapsed.count() << " seconds" << endl;


    gmp_printf("c: %Zd\n", c_mpz);
    gmp_printf("z: %Zd\n", z_merge);
    SigVerify(message, c_mpz, z_merge);
}

/* (omega2 / subpk)^(1/{tau - deviceid}), omega2 = g^f{tau}, subpk = g^f(deviceid) */
void auth_commitment(element_t omega2, element_t subpk, mpz_t tau, mpz_t deviceid, element_t result)
{
    element_t tmp1, tmp2;
    element_init_G1(tmp1, pairing);
    element_init_G1(tmp2, pairing);

    element_invert(tmp1, subpk);
    element_mul(tmp1, tmp1, omega2);

    mpz_t mpztmp1;
    mpz_init(mpztmp1);

    mpz_sub(mpztmp1, tau, deviceid);
    mpz_invert(mpztmp1, mpztmp1, p);
    element_pow_mpz(result, tmp1, mpztmp1);
}

void authentication(int device1, int device2)
{
    element_t commit_auth;
    element_init_G1(commit_auth, pairing);

    auth_commitment(poly_commit2[device1], dkg_subpk[device1][device2], omega_list[device1], idlist[device2], commit_auth); // pi_ij

    element_t eletmp1, eletmp2, eletmp3, eletmp4;
    element_init_G1(eletmp1, pairing);
    element_init_G1(eletmp2, pairing);
    element_init_GT(eletmp3, pairing);
    element_init_GT(eletmp4, pairing);

    element_invert(eletmp1, dkg_subpk[device1][device2]);
    element_mul(eletmp1, eletmp1, poly_commit2[device1]);

    pairing_apply(eletmp3, eletmp1, commit_g, pairing);
    // element_printf("authentication data: %B\n", eletmp3);

    element_pow_mpz(eletmp1, commit_g, idlist[device2]);
    element_invert(eletmp2, eletmp1);
    element_mul(eletmp2, eletmp2, poly_commit1[device1]);

    pairing_apply(eletmp4, commit_auth, eletmp2, pairing); 

    int check = element_cmp(eletmp3, eletmp4);
    if (check == 0)
    {
        printf("authentication success\n");
    }
    else
    {
        printf("authentication failed\n");
    }
}

void test_authentication()
{
    for (size_t i = 0; i < Treshold; i++)
    {
        authentication(Treshold, i);
    }
}