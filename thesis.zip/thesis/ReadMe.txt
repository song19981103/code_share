chenkang_thesis_code  	论文代码
hithesis-master1 		论文latex文件
论文visio图  		论文中图的visio文件